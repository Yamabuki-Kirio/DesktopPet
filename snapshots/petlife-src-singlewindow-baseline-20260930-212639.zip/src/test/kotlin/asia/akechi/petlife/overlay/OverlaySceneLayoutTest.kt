package asia.akechi.petlife.overlay

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 单窗口场景求解的回归测试（Phase 4C-6B-2 架构验证包）。
 *
 * 核心不变式：**菜单开关不改变人物的屏幕矩形**。
 * 这条一旦不成立，真机上就表现为"点击桌宠后人物抽动/消失"。
 */
class OverlaySceneLayoutTest {

    /** 人物屏幕矩形：162×162（非正方形尺寸也必须原样保留）。 */
    private val pet = OverlayRect(left = 300, top = 500, right = 462, bottom = 662)

    // --- (a) 关闭态 --------------------------------------------------------

    @Test
    fun `closed：窗口等于人物矩形，人物层在 (0,0)`() {
        val scene = OverlaySceneSolver.closed(pet)

        assertEquals(pet, scene.windowRect)
        assertEquals(OverlayRect(0, 0, pet.width, pet.height), scene.petRectInWindow)
        assertNull("菜单关闭时没有菜单层", scene.menuRectInWindow)
        assertEquals(pet, scene.petScreenRect)
        assertFalse(scene.menuOpen)
        assertTrue(scene.assertConsistent())
    }

    // --- (b) 打开态：人物屏幕矩形完全不变 ------------------------------------

    @Test
    fun `open：人物屏幕矩形与输入完全相等`() {
        val menu = OverlayRect(left = 600, top = 300, right = 1100, bottom = 800)
        val scene = OverlaySceneSolver.open(pet, menu)

        assertEquals("人物屏幕矩形必须一个像素都不变", pet, scene.petScreenRect)
        assertTrue(scene.menuOpen)
        assertTrue(scene.assertConsistent())
    }

    // --- (c) 人物层在容器内的位置 -------------------------------------------

    @Test
    fun `人物层在容器内的位置 = 人物屏幕矩形减窗口原点，且尺寸不变`() {
        val menu = OverlayRect(left = 0, top = 0, right = 1000, bottom = 400)
        val scene = OverlaySceneSolver.open(pet, menu)
        val origin = scene.windowRect

        assertEquals(
            OverlayRect(
                left = pet.left - origin.left,
                top = pet.top - origin.top,
                right = pet.right - origin.left,
                bottom = pet.bottom - origin.top,
            ),
            scene.petRectInWindow,
        )
        assertEquals(pet.width, scene.petRectInWindow.width)
        assertEquals(pet.height, scene.petRectInWindow.height)
    }

    // --- (d) 菜单层在容器内的位置 -------------------------------------------

    @Test
    fun `菜单层在容器内的位置 = 菜单屏幕矩形减窗口原点`() {
        val menu = OverlayRect(left = 0, top = 0, right = 1000, bottom = 400)
        val scene = OverlaySceneSolver.open(pet, menu)
        val origin = scene.windowRect
        val rect = scene.menuRectInWindow!!

        assertEquals(
            OverlayRect(
                left = menu.left - origin.left,
                top = menu.top - origin.top,
                right = menu.right - origin.left,
                bottom = menu.bottom - origin.top,
            ),
            rect,
        )
        assertEquals(menu.width, rect.width)
        assertEquals(menu.height, rect.height)
    }

    // --- (e) 并集：菜单在人物的右/下/左/上四个方向 ---------------------------

    @Test
    fun `并集正确：菜单在人物右侧`() {
        val menu = OverlayRect(left = 500, top = 400, right = 1000, bottom = 900)
        val scene = OverlaySceneSolver.open(pet, menu)

        assertEquals(OverlayRect(300, 400, 1000, 900), scene.windowRect)
        // 窗口左/上边界还是人物的左/上边界 → 人物偏移只可能在 (0,0)
        assertEquals(0, scene.petRectInWindow.left)
        assertEquals(100, scene.petRectInWindow.top)
    }

    @Test
    fun `并集正确：菜单在人物左侧`() {
        val menu = OverlayRect(left = 0, top = 600, right = 200, bottom = 1000)
        val scene = OverlaySceneSolver.open(pet, menu)

        assertEquals(OverlayRect(0, 500, 462, 1000), scene.windowRect)
        assertEquals(300, scene.petRectInWindow.left)
        assertEquals(0, scene.petRectInWindow.top)
    }

    @Test
    fun `并集正确：菜单在人物上方`() {
        val menu = OverlayRect(left = 350, top = 100, right = 700, bottom = 400)
        val scene = OverlaySceneSolver.open(pet, menu)

        assertEquals(OverlayRect(300, 100, 700, 662), scene.windowRect)
        assertEquals(0, scene.petRectInWindow.left)
        assertEquals(400, scene.petRectInWindow.top)
    }

    @Test
    fun `并集正确：菜单在人物下方`() {
        val menu = OverlayRect(left = 350, top = 700, right = 700, bottom = 1100)
        val scene = OverlaySceneSolver.open(pet, menu)

        assertEquals(OverlayRect(300, 500, 700, 1100), scene.windowRect)
        assertEquals(0, scene.petRectInWindow.left)
        assertEquals(0, scene.petRectInWindow.top)
    }

    @Test
    fun `并集正确：菜单完全包住人物（人物在容器正中）`() {
        val menu = OverlayRect(left = 100, top = 200, right = 900, bottom = 1000)
        val scene = OverlaySceneSolver.open(pet, menu)

        assertEquals(menu, scene.windowRect)
        assertEquals(200, scene.petRectInWindow.left)
        assertEquals(300, scene.petRectInWindow.top)
        assertEquals(pet, scene.petScreenRect)
    }

    // --- (f) 往返：窗口原点 + 人物层偏移 == 人物屏幕矩形 ----------------------

    @Test
    fun `往返：窗口原点加人物层偏移仍等于人物屏幕矩形`() {
        val menus = listOf(
            OverlayRect(600, 300, 1100, 800),
            OverlayRect(0, 0, 200, 200),
            OverlayRect(100, 200, 900, 1000),
            OverlayRect(350, 700, 700, 1100),
        )
        menus.forEach { menu ->
            val scene = OverlaySceneSolver.open(pet, menu)
            val origin = scene.windowRect
            val back = scene.petRectInWindow.translate(origin.left, origin.top)
            assertEquals("菜单=$menu 时往返必须还原人物屏幕矩形", pet, back)
            assertTrue(scene.assertConsistent())
        }
    }

    // --- 自检函数本身 -------------------------------------------------------

    @Test
    fun `自检：人为写错的偏移会被判为不一致`() {
        val consistent = OverlaySceneSolver.open(pet, OverlayRect(600, 300, 1100, 800))
        assertTrue(consistent.assertConsistent())

        val broken = consistent.copy(
            petRectInWindow = consistent.petRectInWindow.translate(1, 0),
        )
        assertFalse("人物层偏移被改 1px 必须自检失败", broken.assertConsistent())
    }
}
