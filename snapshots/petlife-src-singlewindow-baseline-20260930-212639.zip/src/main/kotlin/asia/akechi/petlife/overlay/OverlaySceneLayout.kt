package asia.akechi.petlife.overlay

/**
 * 单窗口"场景"布局（Phase 4C-6B-2 架构验证包）。
 *
 * 背景：此前桌宠与轮盘菜单是两个 `WindowManager` 窗口，菜单窗口在上层，
 * 只能靠 `PorterDuff.CLEAR` 在人物区域"打洞"才能露出桌宠 —— 真机上人物仍会消失。
 * 现在两者合并到**同一个透明窗口**：根容器 = 既有的 `PetOverlayView`，
 * 容器内 `index 0 = 菜单层`、`index 1 = 人物层`，人物天然画在菜单**之上**。
 *
 * 本类只做一件事：给定人物与菜单的**屏幕**矩形，求解窗口矩形与两层在容器内的位置。
 * 纯 Kotlin、无任何 `android.*` 依赖，因此可以被 JVM 单测逐条打靶。
 */
internal data class OverlaySceneLayout(
    /** 根窗口的屏幕矩形。 */
    val windowRect: OverlayRect,
    /** 人物层在根容器内的位置（尺寸 = 人物尺寸）。 */
    val petRectInWindow: OverlayRect,
    /** 菜单层在根容器内的位置；菜单关闭时为 null。 */
    val menuRectInWindow: OverlayRect?,
    /** 人物屏幕矩形。不变式：菜单开关前后**完全相等**。 */
    val petScreenRect: OverlayRect,
    val menuOpen: Boolean,
) {
    /**
     * 自检：两层都落在窗口内、尺寸与屏幕矩形一致、窗口原点 + 层内偏移 == 屏幕矩形。
     *
     * 这是"菜单开关不改变人物屏幕位置"这条不变式的可执行形式（单测直接打靶）。
     */
    fun assertConsistent(): Boolean {
        if (!windowRect.isUsable) return false
        if (petRectInWindow.width != petScreenRect.width) return false
        if (petRectInWindow.height != petScreenRect.height) return false
        if (windowRect.left + petRectInWindow.left != petScreenRect.left) return false
        if (windowRect.top + petRectInWindow.top != petScreenRect.top) return false
        if (!insideWindow(petRectInWindow)) return false
        val menu = menuRectInWindow
        if (menuOpen != (menu != null)) return false
        return menu == null || insideWindow(menu)
    }

    private fun insideWindow(rect: OverlayRect): Boolean =
        rect.left >= 0 && rect.top >= 0 &&
            rect.left + rect.width <= windowRect.width &&
            rect.top + rect.height <= windowRect.height
}

/**
 * 场景求解器（**纯函数**）。
 *
 * 唯一的硬不变式：**人物屏幕矩形在菜单开关前后完全相等** ——
 * 打开菜单只是把窗口向外扩成"人物 ∪ 菜单"的并集，人物层在容器内反向平移同样的量，
 * 因此人物在屏幕上的绝对位置一个像素都不动（这是"开菜单桌宠不抽动"的结构性保证）。
 */
internal object OverlaySceneSolver {

    /** 菜单关闭：窗口 == 人物矩形，人物层在 (0,0)。 */
    fun closed(petScreenRect: OverlayRect): OverlaySceneLayout = OverlaySceneLayout(
        windowRect = petScreenRect,
        petRectInWindow = OverlayRect(0, 0, petScreenRect.width, petScreenRect.height),
        menuRectInWindow = null,
        petScreenRect = petScreenRect,
        menuOpen = false,
    )

    /** 菜单打开：窗口 = 人物 ∪ 菜单 的并集；人物屏幕矩形**保持不变**，反算其在容器内的偏移。 */
    fun open(petScreenRect: OverlayRect, menuScreenRect: OverlayRect): OverlaySceneLayout {
        val windowRect = petScreenRect.union(menuScreenRect)
        return OverlaySceneLayout(
            windowRect = windowRect,
            // 尺寸不变，只平移（`translate` 保宽高）。
            petRectInWindow = petScreenRect.translate(-windowRect.left, -windowRect.top),
            menuRectInWindow = menuScreenRect.translate(-windowRect.left, -windowRect.top),
            petScreenRect = petScreenRect,
            menuOpen = true,
        )
    }
}
