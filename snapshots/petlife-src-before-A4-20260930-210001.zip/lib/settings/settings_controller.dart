import 'package:flutter/foundation.dart';

import '../core/logger.dart';
import '../state_engine/system_state.dart';
import 'app_settings.dart';
import 'settings_repository.dart';

/// 设置的内存视图 + 持久化协调者。
///
/// UI 只与它交互；它负责写入 [SettingsRepository]，并在每次变更后通知监听者
/// （窗口控制器据此实时应用置顶 / 透明度等）。
class SettingsController extends ChangeNotifier {
  SettingsController({required SettingsRepository repository, required String ownerId})
      : _repository = repository,
        _ownerId = ownerId;

  final SettingsRepository _repository;
  final String _ownerId;

  AppSettings _settings = const AppSettings();
  bool _loaded = false;

  AppSettings get settings => _settings;

  bool get isLoaded => _loaded;

  Future<void> load() async {
    _settings = (await _repository.load(_ownerId)).normalized();
    _loaded = true;
    Loggers.settings.info(
      '设置加载完成: 置顶=${_settings.alwaysOnTop} 穿透=${_settings.ignoreMouseEvents} '
      '锁定=${_settings.lockPosition} 缩放=${_settings.scale}x '
      '平滑=${_settings.smoothScaling} 透明度=${_settings.opacity} '
      '淡入淡出=${_settings.crossFadeMs}ms 循环=${_settings.loopAnimation} '
      '位置=(${_settings.windowX}, ${_settings.windowY})',
    );
    notifyListeners();
  }

  /// 原子更新：传入一个变更函数，自动持久化并通知。
  Future<void> update(AppSettings Function(AppSettings current) mutate) async {
    final AppSettings next = mutate(_settings).normalized();
    if (mapEquals(next.toKeyValues(), _settings.toKeyValues())) return;
    _settings = next;
    notifyListeners();
    await _repository.patch(_ownerId, next.toKeyValues());
  }

  Future<void> setAlwaysOnTop(bool value) =>
      update((AppSettings s) => s.copyWith(alwaysOnTop: value));

  Future<void> setIgnoreMouseEvents(bool value) =>
      update((AppSettings s) => s.copyWith(ignoreMouseEvents: value));

  Future<void> setLockPosition(bool value) =>
      update((AppSettings s) => s.copyWith(lockPosition: value));

  Future<void> setScale(double value) => update((AppSettings s) => s.copyWith(scale: value));

  Future<void> setSmoothScaling(bool value) =>
      update((AppSettings s) => s.copyWith(smoothScaling: value));

  Future<void> setOpacity(double value) => update((AppSettings s) => s.copyWith(opacity: value));

  Future<void> setCrossFadeMs(int value) =>
      update((AppSettings s) => s.copyWith(crossFadeMs: value));

  Future<void> setLoopAnimation(bool value) =>
      update((AppSettings s) => s.copyWith(loopAnimation: value));

  Future<void> setDefaultCharacter(String? characterId) =>
      update((AppSettings s) => s.copyWith(defaultCharacterId: characterId));

  Future<void> setDefaultAsset(String? assetId) =>
      update((AppSettings s) => s.copyWith(defaultAssetId: assetId));

  Future<void> setHideOnFullscreen(bool value) =>
      update((AppSettings s) => s.copyWith(hideOnFullscreen: value));

  Future<void> setLaunchAtStartup(bool value) =>
      update((AppSettings s) => s.copyWith(launchAtStartup: value));

  /// 记住「使用统计」页停留的子页（本机 / 云端）。
  Future<void> setUsageStatsTab(String value) => update(
        (AppSettings s) => s.copyWith(
          usageStatsTab: value == AppSettings.usageStatsTabCloud
              ? AppSettings.usageStatsTabCloud
              : AppSettings.usageStatsTabLocal,
        ),
      );

  /// Phase 4C-6A：「根据当前应用自动切换桌宠状态」总开关。
  ///
  /// 只影响**自动换素材**；前台识别与使用时长采集不受影响（需求 §9）。
  Future<void> setOverlayAutomaticState(bool value) =>
      update((AppSettings s) => s.copyWith(overlayAutomaticState: value));

  /// 记忆窗口位置（拖动结束后调用，避免拖动过程中高频写库）。
  Future<void> rememberWindowPosition(double x, double y) =>
      update((AppSettings s) => s.copyWith(windowX: x, windowY: y));

  /// 记忆当前角色与表情，供下次启动恢复。
  Future<void> rememberSelection({
    String? characterId,
    SystemState? state,
    String? assetId,
    String? manualAssetId,
  }) =>
      update((AppSettings s) => s.copyWith(
            lastCharacterId: characterId,
            lastState: state,
            lastAssetId: assetId,
            manualAssetId: manualAssetId,
          ));

  Future<void> resetToDefaults() async {
    await _repository.reset(_ownerId);
    _settings = const AppSettings();
    notifyListeners();
    Loggers.settings.info('设置已恢复默认');
  }
}
