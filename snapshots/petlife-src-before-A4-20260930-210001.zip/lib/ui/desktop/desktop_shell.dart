import 'dart:async';

import 'package:flutter/material.dart';

import '../../app/app_scope.dart';
import '../../core/error_handler.dart';
import '../../core/logger.dart';
import '../../desktop_window/tray_host.dart';
import '../pet/pet_view_wrapper.dart';
import 'control_panel.dart';

/// 桌面窗口模式。
enum WindowMode {
  /// 桌宠模式：窗口只有立绘大小，透明、无边框、置顶。
  pet,

  /// 控制面板模式：窗口放大为一个普通窗口，显示素材库 / 映射 / 调试器 / 设置。
  panel,
}

/// 桌面外壳（Windows）：负责在「桌宠窗口」与「控制面板」两种形态之间切换。
///
/// 为什么用同一个窗口而不是两个原生窗口：
/// Flutter 桌面的多窗口支持仍是实验性的，而阶段 0 的验收只要求
/// 「至少提供以下页面或面板」——用一个可切换形态的窗口即可满足，
/// 且能避免多窗口带来的焦点、置顶、托盘联动等一堆边界问题。
///
/// Phase 4A：Android 使用 `ui/mobile/mobile_shell.dart`，两者由
/// `app/app_shell.dart` 按平台能力选择。
class DesktopShell extends StatefulWidget {
  const DesktopShell({super.key, required this.services});

  final AppServices services;

  /// 控制面板窗口尺寸（逻辑像素）。
  static const Size panelSize = Size(1180, 760);

  @override
  State<DesktopShell> createState() => _DesktopShellState();
}

class _DesktopShellState extends State<DesktopShell> {
  WindowMode _mode = WindowMode.pet;
  Future<void>? _pendingSwitch;
  final GlobalKey<ControlPanelState> _panelKey = GlobalKey<ControlPanelState>();

  AppServices get _s => widget.services;

  @override
  void initState() {
    super.initState();
    _bootstrapAsync();
  }

  Future<void> _bootstrapAsync() async {
    try {
      await _s.initializeTray();

      // 把托盘与 UI 之间的动作接上。
      AppServices.panelToggleHook = () async => togglePanel();
      AppServices.exitHook = () async => _exitApp();
      AppServices.toggleTrackingHook = () async => toggleTracking();
      AppServices.usageStatsHook = () async => openUsageStats();

      // 让托盘回调能定位到本 State。
      _shellRef = this;

      // 恢复上次的角色与表情（验收第 18 项）。
      final String? lastCharacter = _s.settings.settings.lastCharacterId;
      final String? defaultCharacter = _s.settings.settings.defaultCharacterId;
      final String? characterId = lastCharacter ?? defaultCharacter;

      if (characterId != null) {
        await _s.stateEngine.start(ownerId: _s.ownerId, characterId: characterId);
        final String? manualAsset = _s.settings.settings.manualAssetId;
        if (manualAsset != null) {
          await _s.stateEngine.lockManual(
            assetId: manualAsset,
            reason: '恢复上次的 manual 锁定',
          );
        }
      } else {
        Loggers.app.info('尚无角色配置，等待用户导入素材');
      }

      await _s.presenter.start();
      await _applyMode(WindowMode.pet, force: true);

      // 阶段 1：启动 Windows 活动采集（在状态引擎绑定角色之后）。
      // 失败不会影响桌宠，采集器内部已有降级路径。
      await _s.startActivityTracking();
      _s.activityTracker.addListener(_onTrackingChanged);
      _syncTrayTrackingState();

      // Phase 2：启动后台同步引擎（未登录时不做任何网络请求）。
      // 放在采集之后：采集必须先于同步可用，否则会给人"同步好了但没数据"的错觉。
      await _s.startSync();
    } catch (e, st) {
      ErrorHandler.record('DesktopShell.bootstrap', e, st);
    }
  }

  @override
  void dispose() {
    _s.activityTracker.removeListener(_onTrackingChanged);
    super.dispose();
  }

  void _onTrackingChanged() {
    _syncTrayTrackingState();
  }

  /// 同步托盘「暂停 / 恢复记录」文案与提示。
  ///
  /// 只在暂停状态变化时重建菜单；提示文案按应用变化更新，避免高频调用原生 API。
  /// 没有托盘时（理论上不会走到这里）直接返回。
  void _syncTrayTrackingState() {
    final TrayHost? tray = _s.trayHost;
    if (tray == null) return;
    final bool paused = _s.activityTracker.isPaused;
    unawaited(tray.refreshTrackingState(paused));

    final String? app = _s.activityTracker.currentAppDisplayName;
    final String tip = paused
        ? 'PetLife 桌宠 · 已暂停记录'
        : (app == null ? 'PetLife 桌宠' : 'PetLife 桌宠 · 当前：$app');
    if (tip != _lastTrayTip) {
      _lastTrayTip = tip;
      unawaited(tray.setTooltipText(tip));
    }
  }

  String? _lastTrayTip;

  /// 暂停 / 恢复记录（托盘与桌宠右键菜单共用）。
  Future<void> toggleTracking() async {
    final bool paused = _s.activityTracker.isPaused;
    await _s.saveTrackingSettings(_s.activityTracker.settings.copyWith(paused: !paused));
    _syncTrayTrackingState();
  }

  /// 打开控制面板并定位到「使用统计」。
  Future<void> openUsageStats() async {
    await openPanel();
    _panelKey.currentState?.selectTab(ControlPanel.usageStatsTabIndex);
  }

  static _DesktopShellState? _shellRef;

  /// 供托盘调用：切换控制面板。
  static Future<void> togglePanel() async {
    final _DesktopShellState? state = _shellRef;
    if (state == null) return;
    if (state._mode == WindowMode.panel) {
      await state.closePanel();
    } else {
      await state.openPanel();
    }
  }

  Future<void> openPanel() async {
    if (_mode == WindowMode.panel) return;
    await _applyMode(WindowMode.panel);
  }

  Future<void> closePanel() async {
    if (_mode == WindowMode.pet) return;
    await _applyMode(WindowMode.pet);
  }

  Future<void> _applyMode(WindowMode mode, {bool force = false}) async {
    // 串行化切换，避免快速点击造成窗口尺寸抖动。
    final Future<void>? pending = _pendingSwitch;
    if (pending != null) await pending;

    final Completer<void> completer = Completer<void>();
    _pendingSwitch = completer.future;

    try {
      final ({double x, double y})? pos = await _s.windowController.position();

      if (mode == WindowMode.panel) {
        await _s.windowController.applySettings(
          _s.settings.settings.copyWith(ignoreMouseEvents: false, lockPosition: false),
        );
        await _s.windowController.setResizable(true);
        await _s.windowController.resizeTo(DesktopShell.panelSize);
        // 面板窗口靠近屏幕左上角更符合直觉。
        if (pos != null) await _s.windowController.moveTo(pos.x, pos.y);
        Loggers.window.info('切换到控制面板模式 ${DesktopShell.panelSize.width.toInt()}x'
            '${DesktopShell.panelSize.height.toInt()}');
      } else {
        await _s.windowController.setResizable(false);
        // 尺寸会在 PetView 首次布局时按素材尺寸校正。
        await _s.windowController.applySettings(_s.settings.settings);
        Loggers.window.info('切换到桌宠模式');
      }

      if (!mounted) return;
      setState(() {
        _mode = mode;
      });
      if (force) {
        await _s.windowController.setVisible(true);
      }
    } catch (e, st) {
      ErrorHandler.record('DesktopShell._applyMode', e, st);
    } finally {
      completer.complete();
      _pendingSwitch = null;
    }
  }

  Future<void> _exitApp() async {
    try {
      await _s.windowController.setPreventClose(false);
      await _s.shutdown();
    } catch (e, st) {
      ErrorHandler.record('exit', e, st);
    }
    // destroy 必须在 shutdown 之后，否则窗口先没了。
    await _s.windowController.destroy();
  }

  @override
  Widget build(BuildContext context) {
    if (_mode == WindowMode.pet) {
      return _PetWindowMode(
        services: _s,
        onOpenPanel: openPanel,
        onExit: _exitApp,
        onToggleTracking: toggleTracking,
        onOpenUsageStats: openUsageStats,
      );
    }
    return ControlPanel(
      key: _panelKey,
      services: _s,
      onClose: closePanel,
      onExit: _exitApp,
    );
  }
}

/// 桌宠模式：整个窗口只有立绘。
class _PetWindowMode extends StatelessWidget {
  const _PetWindowMode({
    required this.services,
    required this.onOpenPanel,
    required this.onExit,
    required this.onToggleTracking,
    required this.onOpenUsageStats,
  });

  final AppServices services;
  final Future<void> Function() onOpenPanel;
  final Future<void> Function() onExit;
  final Future<void> Function() onToggleTracking;
  final Future<void> Function() onOpenUsageStats;

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: PetViewWrapper(
        services: services,
        onOpenPanel: onOpenPanel,
        onExit: onExit,
        onToggleTracking: onToggleTracking,
        onOpenUsageStats: onOpenUsageStats,
      ),
    );
  }
}
