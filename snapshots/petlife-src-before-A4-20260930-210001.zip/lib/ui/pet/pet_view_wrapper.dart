import 'package:flutter/material.dart';

import '../../activity_tracking/models/usage_stats.dart';
import '../../app/app_scope.dart';
import '../../state_engine/state_snapshot.dart';
import 'pet_view.dart';

/// 桌宠视图包装器。
///
/// 把三处变化汇总到同一个重建点：
/// - 设置变化（缩放 / 透明度 / 平滑 / 锁定位置）
/// - 状态引擎快照变化（当前角色、状态、素材）
/// 因此 [PetView] 本身可以保持无状态化，只负责画。
class PetViewWrapper extends StatelessWidget {
  const PetViewWrapper({
    super.key,
    required this.services,
    required this.onOpenPanel,
    required this.onExit,
    this.onToggleTracking,
    this.onOpenUsageStats,
    this.manageWindowSize = true,
  });

  final AppServices services;
  final Future<void> Function() onOpenPanel;
  final Future<void> Function() onExit;

  /// 暂停 / 恢复记录；为 null 时不显示该菜单项。
  final Future<void> Function()? onToggleTracking;

  /// 打开使用统计；为 null 时不显示该菜单项。
  final Future<void> Function()? onOpenUsageStats;

  final bool manageWindowSize;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: services.settings,
      builder: (BuildContext context, Widget? _) {
        return ValueListenableBuilder<StateSnapshot>(
          valueListenable: services.stateEngineSnapshot,
          builder: (BuildContext context, StateSnapshot snapshot, Widget? __) {
            return PetView(
              renderer: services.renderer,
              scale: services.settings.settings.scale,
              smoothScaling: services.settings.settings.smoothScaling,
              opacity: services.settings.settings.opacity,
              lockPosition: services.settings.settings.lockPosition,
              manageWindowSize: manageWindowSize,
              // 宿主由平台装配决定：Windows = window_manager；Android = no-op。
              host: services.petHost,
              // 双击桌宠直接打开控制面板——这是桌宠最自然的入口。
              onDoubleTap: () => onOpenPanel(),
              onRightClick: () => _showPetContextMenu(context),
            );
          },
        );
      },
    );
  }

  Future<void> _showPetContextMenu(BuildContext context) async {
    final RenderBox overlay = Overlay.of(context).context.findRenderObject()! as RenderBox;
    final Size size = overlay.size;
    final String state = services.stateEngineSnapshot.value.state.wireName;

    // 右键菜单打开时读一次实时数据。查询走内存计数与已载入的应用库，
    // 不做任何数据库全表查询，因此绝不会阻塞桌宠动画。
    final tracker = services.activityTracker;
    final String currentApp = tracker.currentAppDisplayName ?? '—';
    final String todayActive = formatDurationZh(tracker.todayActiveSeconds);

    await showMenu<String>(
      context: context,
      position: RelativeRect.fromLTRB(size.width, size.height, 0, 0),
      items: <PopupMenuEntry<String>>[
        PopupMenuItem<String>(
          enabled: false,
          child: Text('当前状态：$state', style: const TextStyle(fontSize: 12)),
        ),
        PopupMenuItem<String>(
          enabled: false,
          child: Text('当前应用：$currentApp', style: const TextStyle(fontSize: 12)),
        ),
        PopupMenuItem<String>(
          enabled: false,
          child: Text('今日活跃：$todayActive', style: const TextStyle(fontSize: 12)),
        ),
        const PopupMenuDivider(),
        const PopupMenuItem<String>(value: 'panel', child: Text('打开控制面板')),
        if (onOpenUsageStats != null)
          const PopupMenuItem<String>(value: 'stats', child: Text('打开使用统计')),
        if (onToggleTracking != null)
          PopupMenuItem<String>(
            value: 'toggleTracking',
            child: Text(tracker.isPaused ? '恢复记录' : '暂停记录'),
          ),
        const PopupMenuItem<String>(value: 'toggleMouse', child: Text('切换鼠标穿透')),
        const PopupMenuItem<String>(value: 'release', child: Text('解除表情锁定')),
        const PopupMenuDivider(),
        const PopupMenuItem<String>(value: 'exit', child: Text('退出 PetLife')),
      ],
    ).then((String? value) async {
      switch (value) {
        case 'panel':
          await onOpenPanel();
        case 'stats':
          await onOpenUsageStats?.call();
        case 'toggleTracking':
          await onToggleTracking?.call();
        case 'toggleMouse':
          await services.settings.setIgnoreMouseEvents(
            !services.settings.settings.ignoreMouseEvents,
          );
          await services.windowController.applySettings(services.settings.settings);
        case 'release':
          await services.stateEngine.releaseManual();
        case 'exit':
          await onExit();
        default:
          break;
      }
    });
  }
}
