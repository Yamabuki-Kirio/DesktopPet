import 'package:flutter/material.dart';

import '../../character/pet_renderer.dart';
import 'pet_frame_controller.dart';
import 'pet_host.dart';

/// 桌宠绘制控件。
///
/// 只做两件事：把 [PetRenderer] 的图层画出来、把拖动事件交给 [PetHost]。
/// 缩放、透明度、淡入淡出全部由外部传入，便于换宿主时复用。
///
/// 平台差异全部藏在 [PetHost] 后面：Windows 由 window_manager 拖动窗口，
/// Android 是应用内页面（`NoopPetHost`，不拖动、不改窗口尺寸）。
class PetView extends StatefulWidget {
  const PetView({
    super.key,
    required this.renderer,
    required this.scale,
    required this.smoothScaling,
    required this.opacity,
    required this.lockPosition,
    this.manageWindowSize = true,
    this.host,
    this.onDoubleTap,
    this.onRightClick,
  });

  final PetRenderer renderer;

  /// 整数倍缩放（1×~4×）。
  final double scale;

  /// false = 最近邻（像素画默认），true = 平滑插值。
  final bool smoothScaling;

  /// 整体不透明度。
  final double opacity;

  /// 锁定位置时禁用拖动。
  final bool lockPosition;

  /// 是否由本控件负责把宿主尺寸同步为素材尺寸。
  ///
  /// 控制面板里的「实时预览」必须传 false，否则会和桌宠窗口本身互相打架。
  final bool manageWindowSize;

  /// 宿主（窗口级能力）。为 null 时既不拖动也不同步尺寸。
  final PetHost? host;

  final VoidCallback? onDoubleTap;

  final VoidCallback? onRightClick;

  @override
  State<PetView> createState() => _PetViewState();
}

class _PetViewState extends State<PetView> {
  double? _lastAppliedW;
  double? _lastAppliedH;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.renderer,
      builder: (BuildContext context, Widget? _) {
        final Size content = widget.renderer.contentSize ?? BuiltinPlaceholder.size;
        final double w = content.width * widget.scale;
        final double h = content.height * widget.scale;

        // 桌面窗口尺寸必须跟随素材尺寸 × 缩放，否则素材会被裁切。
        if (widget.manageWindowSize) _scheduleWindowResize(w, h);

        return Opacity(
          opacity: widget.opacity.clamp(0.0, 1.0),
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onDoubleTap: widget.onDoubleTap,
            onSecondaryTap: widget.onRightClick,
            // 无边框窗口没有系统标题栏，拖动必须显式交给宿主。
            onPanStart: (widget.lockPosition || widget.host == null)
                ? null
                : (DragStartDetails _) => _startDrag(),
            child: MouseRegion(
              cursor: widget.lockPosition ? SystemMouseCursors.basic : SystemMouseCursors.grab,
              child: SizedBox(
                width: w,
                height: h,
                child: CustomPaint(
                  size: Size(w, h),
                  painter: PetLayerPainter(
                    layers: widget.renderer.layers,
                    smooth: widget.smoothScaling,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _startDrag() async {
    try {
      await widget.host?.beginDrag();
    } catch (_) {
      // 拖动失败（例如窗口已锁定）不影响显示。
    }
  }

  /// 只在尺寸真的变化时才调用宿主，避免每帧触发窗口 API。
  void _scheduleWindowResize(double w, double h) {
    final PetHost? host = widget.host;
    if (host == null) return;
    if (_lastAppliedW == w && _lastAppliedH == h) return;
    _lastAppliedW = w;
    _lastAppliedH = h;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      try {
        await host.resizeForPet(width: w, height: h);
      } catch (_) {
        // 忽略。
      }
    });
  }
}

/// 把所有图层按顺序画出来。
///
/// 公开（而不是 `_` 私有）是为了让单元测试能够直接构造两个 Painter 并调用
/// [shouldRepaint] 验证「动画帧变化一定会触发重绘」。
class PetLayerPainter extends CustomPainter {
  const PetLayerPainter({required this.layers, required this.smooth});

  final List<PetRenderLayer> layers;
  final bool smooth;

  @override
  void paint(Canvas canvas, Size size) {
    for (final PetRenderLayer layer in layers) {
      if (layer.opacity <= 0.001) continue;

      if (layer.isPlaceholder) {
        _withOpacity(canvas, size, layer.opacity, () => BuiltinPlaceholder.paint(canvas, size));
        continue;
      }

      if (layer is AnimationRenderLayer) {
        final image = layer.image;
        final Paint paint = Paint()
          // 像素画默认最近邻，避免 2×/3×/4× 放大后发虚（验收第 9 项）。
          ..filterQuality = smooth ? FilterQuality.medium : FilterQuality.none
          ..isAntiAlias = smooth;
        _withOpacity(canvas, size, layer.opacity, () {
          canvas.drawImageRect(
            image,
            Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
            Offset.zero & size,
            paint,
          );
        });
      }
    }
  }

  /// 用 saveLayer 的 alpha 实现整层不透明度（占位图有多次绘制，不能靠 paint.color）。
  void _withOpacity(Canvas canvas, Size size, double opacity, VoidCallback draw) {
    if (opacity >= 0.999) {
      draw();
      return;
    }
    canvas.saveLayer(
      Offset.zero & size,
      Paint()..color = const Color(0xFFFFFFFF).withValues(alpha: opacity),
    );
    draw();
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant PetLayerPainter oldDelegate) {
    if (oldDelegate.smooth != smooth) return true;
    if (oldDelegate.layers.length != layers.length) return true;

    // 动画图层持有的是同一个可变 DecodedAnimation，image / frameIndex 都是实时
    // getter，旧 Painter 与新 Painter 读取到的是同一份「当前状态」，因此
    // identical(image) 永远成立，无法感知帧变化（缺陷：动态 WebP 不重绘）。
    //
    // 只要存在动画图层就一律重绘：帧定时器只在 advance() 真正推进成功后才会
    // notifyListeners()，静态图（frameCount == 1）根本不会启动定时器，因此
    // 这里返回 true 不会造成静态图持续重绘；淡入淡出期间的每步 tick 本身
    // 也确实需要重绘。
    if (layers.any((PetRenderLayer layer) => layer is AnimationRenderLayer)) {
      return true;
    }

    // 无动画图层时（纯占位图 / 空图层）继续细粒度比较。
    for (int i = 0; i < layers.length; i++) {
      final PetRenderLayer a = oldDelegate.layers[i];
      final PetRenderLayer b = layers[i];
      if (a.opacity != b.opacity) return true;
      if (a.isPlaceholder != b.isPlaceholder) return true;
    }
    return false;
  }
}
