import 'dart:ui' show Size;

import 'package:window_manager/window_manager.dart';

import '../../ui/pet/pet_host.dart';

/// Windows 桌宠宿主：把拖动与尺寸同步交给 `window_manager`。
///
/// 行为与阶段 0/1 完全一致（原实现直接写在 `ui/pet/pet_view.dart` 里），
/// 只是搬到了平台层，让 `PetView` 不再 import `window_manager`。
class WindowsPetHost implements PetHost {
  const WindowsPetHost();

  @override
  Future<void> beginDrag() => windowManager.startDragging();

  @override
  Future<void> resizeForPet({required double width, required double height}) =>
      windowManager.setSize(Size(width, height));
}
