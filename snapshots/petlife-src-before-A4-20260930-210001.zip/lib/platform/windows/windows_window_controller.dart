import 'dart:io';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:window_manager/window_manager.dart';

import '../../core/logger.dart';
import '../../settings/app_settings.dart';
import 'display_topology.dart';
import '../../desktop_window/window_controller.dart';

/// Windows 桌宠窗口控制器。
///
/// 用到的原生能力全部来自 `window_manager`（它底层是 Win32 API 的 Dart 封装）：
/// 透明背景、无边框、始终置顶、鼠标穿透、跳过任务栏、位置读写。
/// 因此阶段 0 不需要自己写 C++ 插件——需求只要求「Windows 原生能力使用 C++ 插件**或** Dart FFI」，
/// `window_manager` 走的正是 FFI 路线。
class WindowsWindowController with WindowListener implements WindowController {
  WindowsWindowController();

  DisplayTopology _displays = DisplayTopology.empty();

  void Function(double x, double y)? _onPositionCommitted;
  void Function()? _onCloseRequested;

  /// 上一帧的尺寸，用于在窗口尺寸变化时重新夹取位置。
  double _contentWidth = 256;
  double _contentHeight = 192;

  bool _initialized = false;

  @override
  Future<void> initialize({required AppSettings settings}) async {
    if (_initialized) return;

    await windowManager.ensureInitialized();
    _displays = await DisplayTopology.load();

    final Size initialSize = Size(_contentWidth * settings.scale, _contentHeight * settings.scale);

    final WindowOptions options = WindowOptions(
      size: initialSize,
      center: false,
      backgroundColor: const Color(0x00000000),
      skipTaskbar: false,
      titleBarStyle: TitleBarStyle.hidden,
      alwaysOnTop: settings.alwaysOnTop,
      title: 'PetLife',
    );

    await windowManager.waitUntilReadyToShow(options, () async {
      await windowManager.setAsFrameless();
      await windowManager.setResizable(false);
      await windowManager.setHasShadow(false);
      await windowManager.setPreventClose(true);
      await windowManager.show();
    });

    windowManager.addListener(this);
    _initialized = true;
    Loggers.window.info('桌宠窗口初始化完成: size=${initialSize.width.toInt()}x${initialSize.height.toInt()}');

    await applySettings(settings);
  }

  @override
  Future<void> applySettings(AppSettings settings) async {
    if (!_initialized) return;

    await _try('setAlwaysOnTop', () => windowManager.setAlwaysOnTop(settings.alwaysOnTop));

    // 鼠标穿透：forward: true 让点击落到下层窗口，桌宠变成纯装饰。
    await _try(
      'setIgnoreMouseEvents',
      () => windowManager.setIgnoreMouseEvents(settings.ignoreMouseEvents, forward: true),
    );

    // 「锁定位置」不调用 setMovable —— 这是一个真机踩到的坑：
    // window_manager 的 Dart 侧暴露了 setMovable/isMovable，但 Windows 原生插件
    // (windows/window_manager_plugin.cpp) 并未注册这两个方法，调用会抛
    // MissingPluginException 并中断整个启动流程。
    // 锁定实际上完全由 Dart 侧负责：PetView 依据 settings.lockPosition 决定是否挂
    // onPanStart（唯一的拖动入口），并同步切换光标。
    // 因此去掉这次原生调用不损失任何功能，见 docs/06。

    await resizeForContent(contentWidth: _contentWidth, contentHeight: _contentHeight);

    // 恢复上次位置（若存在），并做多屏可见性夹取。
    final double? x = settings.windowX;
    final double? y = settings.windowY;
    if (x != null && y != null) {
      await moveTo(x, y);
    } else {
      await _moveToDefaultCorner(settings);
    }

    Loggers.window.info(
      '窗口设置已应用: 置顶=${settings.alwaysOnTop} 穿透=${settings.ignoreMouseEvents} '
      '锁定位置=${settings.lockPosition}（Dart 侧生效）缩放=${settings.scale}',
    );
  }

  /// 单个窗口设置失败不应中断启动流程。
  ///
  /// 某些平台会缺失个别方法（见上面 setMovable 的说明），
  /// 这类失败只降级、不致命——否则一个装饰性开关会让桌宠完全起不来。
  Future<void> _try(String label, Future<void> Function() op) async {
    try {
      await op();
    } catch (e, st) {
      Loggers.window.warning('窗口操作 $label 失败（已忽略，功能降级）', e, st);
    }
  }

  @override
  Future<void> resizeForContent({
    required double contentWidth,
    required double contentHeight,
  }) async {
    _contentWidth = contentWidth;
    _contentHeight = contentHeight;
    if (!_initialized) return;
    final Size size = Size(contentWidth, contentHeight);
    await windowManager.setSize(size);
  }

  @override
  Future<void> resizeTo(Size size) async {
    if (!_initialized) return;
    await windowManager.setSize(size);
  }

  @override
  Future<void> setResizable(bool resizable) async {
    if (!_initialized) return;
    await windowManager.setResizable(resizable);
  }

  @override
  Future<void> moveTo(double x, double y) async {
    if (!_initialized) return;
    final ({double x, double y}) safe = _displays.clamp(
      x,
      y,
      windowWidth: _contentWidth,
      windowHeight: _contentHeight,
    );
    await windowManager.setPosition(Offset(safe.x, safe.y));
  }

  @override
  Future<({double x, double y})?> position() async {
    if (!_initialized) return null;
    try {
      final Offset offset = await windowManager.getPosition();
      return (x: offset.dx, y: offset.dy);
    } catch (e, st) {
      Loggers.window.warning('读取窗口位置失败', e, st);
      return null;
    }
  }

  @override
  Future<void> setVisible(bool visible) async {
    if (!_initialized) return;
    if (visible) {
      await windowManager.show();
      await windowManager.focus();
    } else {
      await windowManager.hide();
    }
    Loggers.window.info('桌宠${visible ? '显示' : '隐藏'}');
  }

  @override
  Future<bool> isVisible() async {
    if (!_initialized) return false;
    try {
      return await windowManager.isVisible();
    } catch (_) {
      return false;
    }
  }

  @override
  Future<void> setPreventClose(bool prevent) async {
    if (!_initialized) return;
    await windowManager.setPreventClose(prevent);
  }

  @override
  Future<void> destroy() async {
    if (!_initialized) return;
    try {
      windowManager.removeListener(this);
      await windowManager.setPreventClose(false);
      await windowManager.destroy();
      Loggers.window.info('桌宠窗口已销毁');
    } catch (e, st) {
      Loggers.window.warning('销毁窗口失败', e, st);
    }
    _initialized = false;
  }

  @override
  void onPositionCommitted(void Function(double x, double y) callback) {
    _onPositionCommitted = callback;
  }

  @override
  void onCloseRequested(void Function() callback) {
    _onCloseRequested = callback;
  }

  // ---------------------------------------------------------------------------
  // WindowListener
  // ---------------------------------------------------------------------------

  @override
  void onWindowMoved() {
    // 拖动结束：记忆位置。
    _commitPosition();
  }

  @override
  void onWindowResized() {
    _commitPosition();
  }

  @override
  void onWindowClose() {
    // setPreventClose(true) 时点关闭按钮走到这里：隐藏到托盘而不是退出。
    Loggers.window.info('收到窗口关闭请求，隐藏到系统托盘');
    _onCloseRequested?.call();
  }

  @override
  void onWindowFocus() {
    Loggers.window.fine('窗口获得焦点');
  }

  @override
  void onWindowBlur() {
    Loggers.window.fine('窗口失去焦点');
  }

  Future<void> _commitPosition() async {
    final ({double x, double y})? pos = await position();
    if (pos == null) return;
    _onPositionCommitted?.call(pos.x, pos.y);
  }

  Future<void> _moveToDefaultCorner(AppSettings settings) async {
    final double scale = settings.scale;
    final double w = _contentWidth * scale;
    final double h = _contentHeight * scale;
    final DisplayTopology topology = _displays.displays.isEmpty
        ? (await DisplayTopology.load())
        : _displays;
    _displays = topology;
    if (topology.displays.isEmpty) {
      await windowManager.center();
      return;
    }
    final DisplayBounds primary = topology.displays.firstWhere(
      (DisplayBounds d) => d.isPrimary,
      orElse: () => topology.displays.first,
    );
    await moveTo(primary.right - w - 32, primary.bottom - h - 96);
  }

  /// 供 UI 层使用：当前是否处于 Windows 桌面环境。
  static bool get isSupportedPlatform =>
      !kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS);

  @override
  Future<void> dispose() async {
    _onPositionCommitted = null;
    _onCloseRequested = null;
  }
}
