package asia.akechi.petlife.overlay

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.util.Locale

/** 每帧耗时统计（需求 §15 的调试指标）。 */
internal data class WheelFrameStats(
    var frames: Long = 0L,
    var totalMs: Double = 0.0,
    var maxMs: Double = 0.0,
    var dropped: Long = 0L,
) {
    val averageMs: Double get() = if (frames == 0L) 0.0 else totalMs / frames

    fun reset() {
        frames = 0
        totalMs = 0.0
        maxMs = 0.0
        dropped = 0
    }
}

/**
 * 轮盘菜单窗口的根 View（Phase 4C-6B-1）。
 *
 * 它同时承担三件事，且**只有这三件**：
 * 1. 持有交互状态机 [WheelMenuStateMachine]（层级 / 选中 / 阶段 / 方向）；
 * 2. 用 [WheelMenuGestureController] 解释触摸（点击 / 圆弧滑选 / 取消 / 空白关闭）；
 * 3. 用 [WheelMenuRenderer] 逐帧重绘（**窗口尺寸在整个打开期间不变**）。
 *
 * 与桌宠窗口的关系（沿用 4C-3B 真机结论，**不要改成单窗口**）：
 * 桌宠窗口的 `LayoutParams` 在开/关菜单时**一个字段都不改**，
 * 轮盘画在独立的菜单窗口里；菜单窗口只在菜单打开期间存在，
 * 关闭动画结束即 `removeView`。这样"桌宠不抽动"是结构性保证。
 *
 * 手势互斥（需求 §12）：轮盘窗口**永远不覆盖桌宠抓取区**
 * （由 [WheelMenuGeometry] 的硬约束保证），因此"按在桌宠上拖动"这件事
 * 天然仍归桌宠窗口 —— 两条手势链在窗口层面就分开了，不会互相抢。
 */
internal class WheelMenuView(context: Context) : View(context) {

    /** 某个条目被确认（点击或滑选松手）—— 由 manager 决定"进入子菜单 / 执行 / 只高亮"。 */
    var entryListener: ((WheelMenuEntry, Int) -> Unit)? = null

    /** 空白处松手 → 关闭整个菜单（需求 §5）。 */
    var closeListener: (() -> Unit)? = null

    /**
     * 中央桌宠区域的拖动转发（需求 §3）。
     *
     * 参数是**菜单窗口内**的原始坐标；菜单窗口现在在上层，
     * 因此"按在人物身上拖动"必须由这里转发给 manager 去移动桌宠窗口，
     * 而不是依赖窗口触摸穿透。
     */
    var petDragListener: ((x: Float, y: Float, phase: WheelPetDragPhase) -> Unit)? = null

    /** 一次动画播完（manager 据此同步窗口级状态机与诊断）。 */
    var animationListener: ((WheelAnimationKind) -> Unit)? = null

    /** 选中项实时信息（只读快照；由 manager 在选中变化时提供，**不在 onDraw 里算**）。 */
    var infoProvider: ((WheelMenuEntry) -> String?)? = null

    /** 触觉反馈开关（需求 §16 持久化，缺省开启）。 */
    var hapticsEnabled: Boolean = true

    /** 诊断模式：画出窗口与环带边界。 */
    var debugBounds: Boolean = false

    val state = WheelMenuStateMachine()

    private val renderer = WheelMenuRenderer()
    private val gesture = WheelMenuGestureController.fromDensity(resources.displayMetrics.density)

    private var theme: WheelMenuTheme = WheelMenuThemes.default()
    private var envelope: WheelMenuEnvelope? = null
    private var layout: WheelMenuLayout? = null
    /** 打开时的尺寸参数快照：换层时用它复算几何（**窗口不变**）。 */
    private var spec: WheelMenuSpec? = null
    private var run: WheelAnimationRun? = null
    private var pressRun: WheelAnimationRun? = null

    private var frame = hiddenFrame()
    private var liveSelection: Float? = null
    private var infoText: String? = null
    private var infoKey: String? = null

    private var tickerRunning = false
    private var lastTickUptime = 0L

    /** 拖动桌宠期间抑制绘制（View 仍 VISIBLE，触摸流不断）。 */
    private var suppressed = false

    /** 最近一次触摸的原始坐标（转发拖动要用）。 */
    private var lastTouchRawX = 0f
    private var lastTouchRawY = 0f
    private val frameStats = WheelFrameStats()

    private val ticker = object : Runnable {
        override fun run() {
            if (!tickerRunning) return
            tick()
            if (tickerRunning) postOnAnimation(this)
        }
    }

    // ------------------------------------------------------------------
    // 对外只读诊断
    // ------------------------------------------------------------------

    val phaseName: String get() = state.phase.name

    val levelIdName: String get() = state.levelId ?: "none"

    val activeIndexNow: Int get() = state.activeIndex

    val directionName: String get() = state.direction.name

    val gestureOwnerName: String get() = gesture.ownerName

    val animationName: String get() = run?.kind?.name ?: "idle"

    val windowRectNow: OverlayRect? get() = envelope?.windowRect

    val isAnimating: Boolean get() = run != null

    fun frameStatsSnapshot(): WheelFrameStats = frameStats

    fun currentLayout(): WheelMenuLayout? = layout

    fun currentTheme(): WheelMenuTheme = theme

    fun levelTitleZh(): String = state.currentLevel?.titleZh ?: ""

    // ------------------------------------------------------------------
    // 生命周期 / 配置
    // ------------------------------------------------------------------

    override fun onDetachedFromWindow() {
        // 需求 §15：菜单收起或窗口移除后**必须**停止动画时钟，不留 Timer/Animator。
        stopTicker()
        super.onDetachedFromWindow()
    }

    /**
     * 配置一次打开：信封（窗口 + 中心 + 环带半径）在此**一次性**确定，之后不再变化。
     */
    fun present(
        envelope: WheelMenuEnvelope,
        level: WheelMenuLevel,
        layout: WheelMenuLayout,
        theme: WheelMenuTheme,
        direction: WheelExpandDirection,
        spec: WheelMenuSpec,
    ) {
        this.envelope = envelope
        this.theme = theme
        this.layout = layout
        this.spec = spec
        state.open(direction)
        bindLayout(layout)
        liveSelection = null
        pressRun = null
        suppressed = false
        frame = hiddenFrame().copy(
            mirrorProgress = mirrorOf(direction),
            buttonProgress = List(layout.itemCount) { 0f },
        )
        refreshInfo(force = true)
        contentDescription = "轮盘菜单：${level.titleZh}"
        frameStats.reset()
        invalidate()
    }

    /** 主题即时预览（需求 §13.3：修改后立即生效，不重开菜单）。 */
    fun applyTheme(theme: WheelMenuTheme) {
        this.theme = theme
        invalidate()
    }

    fun updateInfoProvider(provider: ((WheelMenuEntry) -> String?)?) {
        infoProvider = provider
        refreshInfo(force = true)
        invalidate()
    }

    // ------------------------------------------------------------------
    // 动画驱动
    // ------------------------------------------------------------------

    fun startOpenAnimation() {
        val current = layout ?: return
        startRun(WheelAnimationKind.open, from = 0f, to = 0f, count = current.itemCount)
    }

    fun startCloseAnimation() {
        val current = layout ?: return
        state.beginClosing()
        startRun(
            WheelAnimationKind.close,
            from = frame.selectionPosition,
            to = frame.selectionPosition,
            count = current.itemCount,
        )
    }

    /**
     * 进入子菜单：层级**立即**切换，动画只做过渡。
     *
     * **窗口不动**：新层级只是在既有信封里重新算一遍内部几何（需求 §14）。
     */
    fun enterLayer(level: WheelMenuLevel): Boolean {
        // 先算几何再动栈：算不出来就**完全不改变状态**（绝不会留下"栈进了、画不出来"）。
        val next = computeLayout(level) ?: return false
        if (!state.enterLayer(level.id)) return false
        layout = next
        bindLayout(next)
        clearPress()
        refreshInfo(force = true)
        startRun(WheelAnimationKind.enterLayer, from = 0f, to = 0f, count = next.itemCount)
        return true
    }

    /** 返回上一层：同样只做过渡动画，窗口不动。 */
    fun exitLayer(): Boolean {
        val path = state.path()
        if (path.size < 2) return false
        val target = WheelMenuCatalog.level(path[path.size - 2]) ?: return false
        val next = computeLayout(target) ?: return false
        if (!state.exitLayer()) return false
        layout = next
        bindLayout(next)
        clearPress()
        refreshInfo(force = true)
        startRun(WheelAnimationKind.exitLayer, from = 0f, to = 0f, count = next.itemCount)
        return true
    }

    private fun computeLayout(level: WheelMenuLevel): WheelMenuLayout? {
        val env = envelope ?: return null
        val sizes = spec ?: return null
        return WheelMenuGeometry.layoutFor(env, level, sizes)
    }

    /**
     * 根选项切换（沿弧线滑动，需求 §10.2）。
     *
     * 用于"点了条目但不导航"的情况（业务占位项）：高亮、扇区与标题都要**连续平移**过去。
     */
    fun animateSelectionTo(index: Int) {
        val current = layout ?: return
        if (index !in 0 until current.itemCount) return
        val from = liveSelection ?: frame.selectionPosition
        liveSelection = null
        state.setPreview(null)
        state.beginSwitch(index)
        startRun(
            WheelAnimationKind.selectionSwitch,
            from = from,
            to = index.toFloat(),
            count = current.itemCount,
        )
        state.finishSwitch(index)
        refreshInfo(force = true)
    }

    /** 拖动桌宠期间**不显示轮盘**（需求 §13）。
     *
     * View 仍保持 `VISIBLE` —— 这是关键：一旦不可见/被摘掉，这一轮触摸事件就断了，
     * 转发也就没法继续。因此这里只停止时钟与绘制。
     */
    fun hideForPetDrag() {
        freeze()
        suppressed = true
        invalidate()
    }

    /** 立即停止一切动画并把当前帧定格（隐藏 / 停止 / 几何变化等外力打断）。 */
    fun freeze() {
        run?.let { active ->
            frame = WheelAnimationClock.frame(active, SystemClock.uptimeMillis())
        }
        run = null
        pressRun = null
        stopTicker()
        gesture.reset()
        liveSelection = null
        state.settleAfterInterruption()
    }

    private fun startRun(kind: WheelAnimationKind, from: Float, to: Float, count: Int) {
        val mirror = mirrorOf(state.direction)
        // 新动画**接管**旧动画：先按旧动画当前帧收敛，避免位置误差累积（需求 §18.4）。
        run?.let { previous ->
            frame = WheelAnimationClock.frame(previous, SystemClock.uptimeMillis()).copy(
                mirrorProgress = mirror,
            )
        }
        run = WheelAnimationRun(
            kind = kind,
            startedAtMs = SystemClock.uptimeMillis(),
            fromSelection = from,
            toSelection = to,
            itemCount = count,
            mirrorProgress = mirror,
        )
        startTicker()
        invalidate()
    }

    private fun startTicker() {
        if (tickerRunning) return
        tickerRunning = true
        lastTickUptime = SystemClock.uptimeMillis()
        postOnAnimation(ticker)
    }

    private fun stopTicker() {
        if (!tickerRunning) return
        tickerRunning = false
        removeCallbacks(ticker)
    }

    private fun tick() {
        val now = SystemClock.uptimeMillis()
        recordFrame((now - lastTickUptime).coerceAtLeast(0L))
        lastTickUptime = now

        var next = run?.let { if (WheelAnimationClock.isFinished(it, now)) frame else WheelAnimationClock.frame(it, now) }
            ?: frame
        pressRun?.let { press ->
            val pressFrame = WheelAnimationClock.frame(press, now)
            next = next.copy(pressIndex = press.pressIndex, pressProgress = pressFrame.pressProgress)
            if (WheelAnimationClock.isFinished(press, now)) pressRun = null
        }
        liveSelection?.let { next = next.copy(selectionPosition = it) }
        frame = next

        run?.let { active ->
            if (WheelAnimationClock.isFinished(active, now)) {
                run = null
                finishRun(active)
            }
        }
        if (run == null && pressRun == null) stopTicker()
        invalidate()
    }

    private fun finishRun(active: WheelAnimationRun) {
        when (active.kind) {
            WheelAnimationKind.open -> state.markOpened()
            WheelAnimationKind.close -> state.markClosed()
            WheelAnimationKind.selectionSwitch -> state.finishSwitch(active.toSelection.toInt())
            WheelAnimationKind.enterLayer,
            WheelAnimationKind.exitLayer,
            -> state.finishLayerTransition()
            WheelAnimationKind.press -> Unit
        }
        animationListener?.invoke(active.kind)
    }

    private fun recordFrame(elapsedMs: Long) {
        if (elapsedMs <= 0L) return
        frameStats.frames += 1
        frameStats.totalMs += elapsedMs
        frameStats.maxMs = maxOf(frameStats.maxMs, elapsedMs.toDouble())
        // 超过两个 60Hz 帧视为掉帧（需求 §15 的调试指标之一）。
        if (elapsedMs > 33L) frameStats.dropped += 1
    }

    // ------------------------------------------------------------------
    // 触摸
    // ------------------------------------------------------------------

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val current = layout ?: return false
        // 展开 / 收起动画期间不接受输入：避免"还没张开就被点掉"（需求 §18.2 快速重复开关）。
        if (state.phase == WheelMenuPhase.opening || state.phase == WheelMenuPhase.closing) {
            return true
        }
        val time = event.eventTime
        lastTouchRawX = event.x
        lastTouchRawY = event.y
        val outcome = when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> gesture.onDown(event.x, event.y, time, event.pointerCount)
            MotionEvent.ACTION_MOVE -> gesture.onMove(event.x, event.y, time, event.pointerCount)
            MotionEvent.ACTION_POINTER_DOWN -> gesture.onDown(event.x, event.y, time, 2)
            MotionEvent.ACTION_POINTER_UP -> gesture.onUp(event.x, event.y, time, 2)
            MotionEvent.ACTION_UP -> gesture.onUp(event.x, event.y, time, event.pointerCount)
            MotionEvent.ACTION_CANCEL -> gesture.onCancel()
            else -> WheelGestureOutcome(WheelGestureEffect.none)
        }
        handleOutcome(current, outcome)
        return true
    }

    private fun handleOutcome(current: WheelMenuLayout, outcome: WheelGestureOutcome) {
        when (outcome.effect) {
            WheelGestureEffect.none -> Unit

            WheelGestureEffect.press -> {
                val index = outcome.index ?: return
                pressRun = WheelAnimationRun(
                    kind = WheelAnimationKind.press,
                    startedAtMs = SystemClock.uptimeMillis(),
                    fromSelection = frame.selectionPosition,
                    toSelection = frame.selectionPosition,
                    itemCount = current.itemCount,
                    pressIndex = index,
                    mirrorProgress = mirrorOf(current.direction),
                )
                startTicker()
                invalidate()
            }

            WheelGestureEffect.swipeStart,
            WheelGestureEffect.highlight,
            -> {
                val index = outcome.index ?: return
                state.setPreview(index)
                liveSelection = index.toFloat()
                frame = frame.copy(
                    selectionPosition = index.toFloat(),
                    mirrorProgress = mirrorOf(current.direction),
                )
                if (outcome.haptic) performHaptic()
                refreshInfo(force = false)
                invalidate()
            }

            WheelGestureEffect.confirm -> {
                val index = outcome.index ?: return
                state.setPreview(index)
                val entry = state.confirmSelection() ?: return
                liveSelection = null
                clearPress()
                refreshInfo(force = true)
                invalidate()
                entryListener?.invoke(entry, index)
            }

            WheelGestureEffect.cancel -> {
                // 取消：高亮弹回已确认项，不执行任何动作（需求 §11.2 / §11.4）。
                state.setPreview(null)
                liveSelection = null
                clearPress()
                refreshInfo(force = true)
                startRun(
                    WheelAnimationKind.selectionSwitch,
                    from = frame.selectionPosition,
                    to = state.selectedIndex.toFloat(),
                    count = current.itemCount,
                )
            }

            WheelGestureEffect.outsideTap -> closeListener?.invoke()

            WheelGestureEffect.petDragStart -> {
                // 中央桌宠区域开始拖动：先隐藏轮盘，再把后续位移转发给桌宠窗口（需求 §3 / §13）。
                hideForPetDrag()
                petDragListener?.invoke(lastTouchRawX, lastTouchRawY, WheelPetDragPhase.start)
            }

            WheelGestureEffect.petDragMove ->
                petDragListener?.invoke(lastTouchRawX, lastTouchRawY, WheelPetDragPhase.move)

            WheelGestureEffect.petDragEnd ->
                petDragListener?.invoke(lastTouchRawX, lastTouchRawY, WheelPetDragPhase.end)
        }
    }

    private fun clearPress() {
        pressRun = null
        if (frame.pressIndex >= 0) {
            frame = frame.copy(pressIndex = -1, pressProgress = 0f)
        }
    }

    private fun performHaptic() {
        if (!hapticsEnabled) return
        // 轻触觉（"每跨一个槽位一次"，需求 §11.2）；失败不影响手势。
        runCatching { performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
    }

    private fun bindLayout(layout: WheelMenuLayout) {
        gesture.layout = layout
        gesture.selectedIndex = state.selectedIndex
    }

    private fun refreshInfo(force: Boolean) {
        val provider = infoProvider
        val entry = state.activeEntry
        if (provider == null || entry == null) {
            infoText = null
            infoKey = null
            return
        }
        val key = "${entry.id}#${state.activeIndex}"
        if (!force && key == infoKey) return
        infoKey = key
        infoText = runCatching { provider(entry) }.getOrNull()
    }

    // ------------------------------------------------------------------
    // 绘制
    // ------------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // 拖动桌宠期间不画轮盘（View 仍是 VISIBLE，触摸流不断）。
        if (suppressed) return
        val current = layout ?: return
        val level = state.currentLevel ?: return
        renderer.draw(
            canvas,
            WheelRenderParams(
                layout = current,
                level = level,
                frame = frame,
                activeIndex = state.activeIndex,
                theme = theme,
                infoText = infoText,
                debugBounds = debugBounds,
                density = resources.displayMetrics.density,
                // 按钮中文标签只画在**根菜单**（需求 §10.3）。
                showButtonLabels = state.levelId == WheelMenuCatalog.ROOT_ID,
            ),
        )
    }

    private fun mirrorOf(direction: WheelExpandDirection): Float =
        if (direction == WheelExpandDirection.right) 1f else 0f

    private fun hiddenFrame(): WheelAnimationFrame = WheelAnimationFrame(
        openProgress = 0f,
        selectionPosition = 0f,
        layerProgress = 1f,
        titleProgress = 1f,
        mirrorProgress = 1f,
        buttonProgress = emptyList(),
        pressIndex = -1,
        pressProgress = 0f,
        rotationDeg = 0f,
        scale = 1f,
    )

    /** 一行式诊断（日志用）。 */
    fun dump(): String = String.format(
        Locale.US,
        "wheel phase=%s level=%s dir=%s active=%d anim=%s gesture=%s window=%s " +
            "avgFrame=%.1fms maxFrame=%.1fms dropped=%d",
        state.phase.name,
        state.levelId,
        state.direction.name,
        state.activeIndex,
        run?.kind?.name ?: "idle",
        gesture.ownerName,
        layout?.windowRect?.toString() ?: "none",
        frameStats.averageMs,
        frameStats.maxMs,
        frameStats.dropped,
    )
}
