package asia.akechi.petlife.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Animatable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.roundToInt

/**
 * 悬浮窗的可见状态。
 *
 * 单独建模的原因（4C-2 真机缺陷复盘）：只用一个 `Bitmap?` 无法区分
 * "还没加载 / 加载失败 / 根本没有素材 / 诊断模式"，而它们的界面处理完全不同。
 */
internal enum class OverlayVisual {
    /** 有素材并已显示。 */
    asset,

    /** 正在加载（此时必须显示可见占位，不能是空窗口）。 */
    loading,

    /** 加载/校验失败（必须显示**可见的**错误占位）。 */
    failure,

    /** 还没有任何素材。 */
    empty,

    /**
     * 诊断模式：完全不依赖素材的固定洋红方块。
     *
     * 用于二分定位"问题在窗口/命令时序"还是"在素材解析与绘制"（4C-2 真机排障第二步）。
     */
    debug,
}

/**
 * 可见状态的**纯决策**（可 JVM 单测）。
 *
 * 核心不变式：**只要不是"有图可显示"以外的任何情况，都必须落到一个可见的占位状态** ——
 * 绝不返回"什么都不显示"，也绝不允许把窗口整体做成全透明。
 */
internal object OverlayVisualPolicy {

    fun resolve(
        hasImage: Boolean,
        loading: Boolean,
        lastError: String?,
        debugMode: Boolean = false,
    ): OverlayVisual = when {
        debugMode -> OverlayVisual.debug
        hasImage -> OverlayVisual.asset
        loading -> OverlayVisual.loading
        !lastError.isNullOrEmpty() -> OverlayVisual.failure
        else -> OverlayVisual.empty
    }

    /** 占位/诊断文案（asset 状态不显示占位，返回空串）。 */
    fun placeholderText(visual: OverlayVisual): String = when (visual) {
        OverlayVisual.asset -> ""
        OverlayVisual.loading -> "加载中…"
        OverlayVisual.failure -> "素材加载失败"
        OverlayVisual.empty -> "等待素材"
        OverlayVisual.debug -> "PetLife Overlay"
    }

    /**
     * 是否需要画可见底（不透明边框 + 填充）。
     *
     * 只要不是 [OverlayVisual.asset] 就必须画 —— 这是"窗口永远能被看见"的兜底：
     * 用户至少能看到"这里有一个窗口"，而不是"什么都没发生"。
     */
    fun showsPlaceholderChrome(visual: OverlayVisual): Boolean =
        visual != OverlayVisual.asset
}

/**
 * 悬浮桌宠的**原生 View**（Phase 4C-2）。
 *
 * 结构：
 * ```
 * FrameLayout（显式尺寸 + minimumWidth/Height，绝不为 0×0）
 *   ├── ImageView   当前素材（MATCH_PARENT，FIT_CENTER，保持宽高比）
 *   ├── TextView    占位/诊断文案
 *   └── TextView    "动态·第一帧" 角标（4C-4 之前必须显式标注）
 * ```
 *
 * 三个关键不变式（都是 4C-2 真机两次失败的教训）：
 * 1. **根 View 永远有非零尺寸**：`prepareWindowGeometry` 写 `minimumWidth/Height`，
 *    且 `onMeasure` 先按 EXACTLY 调 `super`（让 FrameLayout 正常测量子 View）再钉死自身尺寸；
 * 2. **非 asset 状态一定有可见底**，绝不出现"全透明窗口"；
 * 3. **alpha / scale / visibility 在每次刷新时显式归位**，避免被历史状态或复用的 View 带成不可见。
 */
internal class PetOverlayView(context: Context) : FrameLayout(context) {

    /**
     * 桌宠内容容器（Phase 4C-3B）。
     *
     * 存在意义：可见性/透明度/背景这些"桌宠本体"的样式统一作用在内层，
     * 根 View 专心做"窗口画布"（恒等于桌宠矩形）。菜单已经拆到独立的
     * [PetMenuView] 窗口，因此这里不再需要"相对偏移"。
     */
    private val petContent: FrameLayout = FrameLayout(context).apply {
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
    }

    private val imageView: ImageView = ImageView(context).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        adjustViewBounds = false
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        visibility = View.GONE
    }

    private val placeholder: TextView = TextView(context).apply {
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        text = OverlayVisualPolicy.placeholderText(OverlayVisual.empty)
        setPadding(dp(6f), dp(4f), dp(6f), dp(4f))
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
    }

    /** 动态素材在 4C-2 只显示第一帧，必须让用户看得见这件事。 */
    private val badge: TextView = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 8f)
        text = "动态·第一帧"
        visibility = View.GONE
        setPadding(dp(4f), dp(1f), dp(4f), dp(1f))
        background = GradientDrawable().apply {
            cornerRadius = dpF(4f)
            setColor(Color.parseColor("#CC1F2933"))
        }
        layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            bottomMargin = dp(2f)
            leftMargin = dp(2f)
        }
    }

    /** 动画是否暂停（息屏时暂停；真正接动画是 4C-4 的事）。 */
    var animationPaused: Boolean = false
        private set

    /** 当前可见状态（诊断用）。 */
    var visual: OverlayVisual = OverlayVisual.empty
        private set

    /** 是否已经成功挂上一张图。 */
    var hasImage: Boolean = false
        private set

    private var debugMode: Boolean = false
    private var desiredWidthPx: Int = 0
    private var desiredHeightPx: Int = 0

    /** 当前视觉是否是**可播放动画**（动态 WebP 且系统支持完整播放）。 */
    private var animateVisual: Boolean = false

    /**
     * 触摸事件转发（Phase 4C-3A）。
     *
     * 由 [PetOverlayManager] 安装：手势判定（touchSlop / 点击 / 拖动）全部在
     * 状态机里，View 只负责把 [android.view.MotionEvent] 递出去，
     * **不在这里做任何 WindowManager 操作**。
     */
    var touchHandler: ((android.view.MotionEvent) -> Boolean)? = null

    init {
        // 自身也钉住最小尺寸，双保险（根 View 尺寸由 onMeasure 决定）。
        petContent.addView(imageView)
        petContent.addView(placeholder)
        petContent.addView(badge)
        addView(petContent)
        refreshVisual(loading = false, lastError = null)
    }

    /** 挂上一张**静态**素材（PNG / JPG / 静态 WebP / 低版本的第一帧回退）。 */
    fun showStatic(drawable: Drawable) {
        applyDrawable(drawable, animatable = false)
    }

    /**
     * 挂上一个**动态**素材（动态 WebP）。
     *
     * 播放/停止统一走 [Animatable]（API 1 就有），因此不需要在 24~27 上引用
     * `AnimatedImageDrawable` 这个 API 28 的类。
     */
    fun showAnimated(drawable: Drawable) {
        applyDrawable(drawable, animatable = true)
    }

    /**
     * 解码失败：**清除旧视觉**并显示**可见的**错误占位。
     *
     * 为什么不像 4C-2 那样保留旧图：切换素材失败时留着旧素材，用户会误以为切换成功。
     * 4C-4 按需求建议统一改为"显示明确错误占位"（窗口绝不消失）。
     */
    fun showErrorPlaceholder(message: String?) {
        stopAnimation()
        animateVisual = false
        hasImage = false
        imageView.setImageDrawable(null)
        applyVisual(OverlayVisual.failure)
        placeholder.text = message?.takeIf { it.isNotBlank() }
            ?: OverlayVisualPolicy.placeholderText(OverlayVisual.failure)
        OverlayLog.log("visual.apply.placeholder reason=${message ?: "<none>"}")
    }

    /** 清空视觉（隐藏/停止时用）：停动画 → 摘掉 Drawable → 回到空占位。 */
    fun clearVisual() {
        stopAnimation()
        animateVisual = false
        hasImage = false
        imageView.setImageDrawable(null)
        applyVisual(OverlayVisual.empty)
        OverlayLog.log("visual.clear ${dump()}")
    }

    /** 开始播放（已在下述条件里判过；这里只保证幂等）。 */
    fun startAnimationIfAllowed() {
        if (!animateVisual) return
        val animatable = imageView.drawable as? Animatable ?: run {
            OverlayLog.warn("animation.start 忽略：当前 Drawable 不是 Animatable")
            return
        }
        if (animatable.isRunning) return
        try {
            animatable.start()
        } catch (t: Throwable) {
            OverlayLog.error("animation.error 启动失败", t)
        }
    }

    /** 停止播放（幂等；不会把 Drawable 摘掉 —— 重新显示时可直接恢复）。 */
    fun stopAnimation() {
        val animatable = imageView.drawable as? Animatable ?: return
        if (!animatable.isRunning) return
        try {
            animatable.stop()
        } catch (t: Throwable) {
            OverlayLog.warn("animation.stop 失败（忽略）", t)
        }
    }

    /** 当前动画是否真的在跑（诊断 + 幂等判据）。 */
    val isAnimationRunning: Boolean
        get() = (imageView.drawable as? Animatable)?.isRunning == true

    /** 当前视觉是否是动态素材（与是否在播放无关）。 */
    val isAnimatableVisual: Boolean get() = animateVisual

    /** 当前视觉的宽高比（无图时 1:1；静态与动态走同一条路径）。 */
    val drawableAspectRatio: Float
        get() {
            val drawable = imageView.drawable ?: return 1f
            val w = drawable.intrinsicWidth
            val h = drawable.intrinsicHeight
            return if (w > 0 && h > 0) w.toFloat() / h.toFloat() else 1f
        }

    private fun applyDrawable(drawable: Drawable, animatable: Boolean) {
        // 需求第 12 节：先从 ImageView 移除/替换，再释放旧引用；替换前先停旧动画。
        stopAnimation()
        OverlayLog.log(
            "visual.replace animatable=$animatable " +
                "size=${drawable.intrinsicWidth}x${drawable.intrinsicHeight} " +
                "type=${drawable.javaClass.simpleName}",
        )
        animateVisual = animatable
        hasImage = true
        imageView.setImageDrawable(drawable)
        applyVisual(OverlayVisual.asset)
        OverlayLog.log(
            "visual.apply.${if (animatable) "animated" else "static"} " +
                "running=$isAnimationRunning ${dump()}",
        )
    }

    /** 打开/关闭诊断模式（洋红方块，不依赖素材）。 */
    fun setDebugMode(enabled: Boolean) {
        if (debugMode == enabled) return
        debugMode = enabled
        refreshVisual(loading = false, lastError = null)
    }

    /** 按"有没有图 / 是否在加载 / 最近一次错误 / 诊断模式"刷新可见状态。 */
    fun refreshVisual(loading: Boolean, lastError: String?) {
        applyVisual(
            OverlayVisualPolicy.resolve(
                hasImage = hasImage,
                loading = loading,
                lastError = lastError,
                debugMode = debugMode,
            ),
        )
    }

    private fun applyVisual(next: OverlayVisual) {
        visual = next
        val showChrome = OverlayVisualPolicy.showsPlaceholderChrome(next)
        placeholder.text = OverlayVisualPolicy.placeholderText(next)
        placeholder.visibility = if (showChrome) View.VISIBLE else View.GONE
        when (next) {
            OverlayVisual.asset -> {
                // 真实素材：撤掉占位底，透明通道才不会被挡住。
                petContent.background = null
            }
            OverlayVisual.debug -> {
                // 诊断模式：**不透明**洋红 —— 只要能看见它就说明窗口链路是通的。
                petContent.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#FFFF00FF"))
                }
                placeholder.setTextColor(Color.WHITE)
                placeholder.setBackgroundColor(Color.TRANSPARENT)
            }
            else -> {
                // 可见占位底：半透明填充 + 不透明边框，用户一眼能看出"窗口在这里"。
                petContent.background = GradientDrawable().apply {
                    cornerRadius = dpF(14f)
                    setColor(Color.parseColor("#E6232F3E"))
                    setStroke(dp(2f), Color.parseColor("#FF7FB3D5"))
                }
                placeholder.setTextColor(Color.WHITE)
            }
        }
        imageView.visibility = if (hasImage && next == OverlayVisual.asset) {
            View.VISIBLE
        } else {
            View.GONE
        }
        // 显式归位：绝不让历史/复用状态把整个窗口带成不可见。
        // 4C-3B：可见性/透明度归位作用在**桌宠内容层**上 —— 根 View 从此是
        // "菜单画布"，它必须始终可见（否则整扇菜单会被一起隐藏）；
        // 而桌宠本身的可见性仍然由这里显式钉死（4C-2 的教训不变）。
        petContent.alpha = 1f
        petContent.scaleX = 1f
        petContent.scaleY = 1f
        petContent.visibility = View.VISIBLE
        alpha = 1f
        scaleX = 1f
        scaleY = 1f
        visibility = View.VISIBLE
        requestLayout()
        invalidate()
    }

    // -----------------------------------------------------------------------
    // 窗口几何（Phase 4C-3A / 4C-3B）
    // -----------------------------------------------------------------------

    /**
     * 只准备窗口尺寸参数，**不触发可见的半完成状态**。
     *
     * 为什么不让调用方分别调"设尺寸 + requestLayout + updateViewLayout"：
     * 那会让根 View 期望尺寸与 WindowManager 窗口矩形分两次生效，
     * Android 可能在两次之间绘制一帧。这里把参数**一次改完**，
     * 由调用方随后用**唯一一次** `updateViewLayout` 触发遍历。
     *
     * 注意：刻意**不调用** `setLayoutParams`（它内部会 requestLayout），
     * 而是原地修改已有的 LayoutParams 对象 —— 准备阶段一次遍历都不触发。
     *
     * 菜单已经拆到独立的 [PetMenuView] 窗口，因此这里不需要任何"相对偏移"：
     * 桌宠内容永远铺满自己的窗口。
     */
    fun prepareWindowGeometry(size: OverlaySize) {
        val safeWidth = OverlayGeometry.safeViewSize(size.width)
        val safeHeight = OverlayGeometry.safeViewSize(size.height)
        minimumWidth = safeWidth
        minimumHeight = safeHeight
        desiredWidthPx = safeWidth
        desiredHeightPx = safeHeight

        val lp = petContent.layoutParams as LayoutParams
        lp.width = safeWidth
        lp.height = safeHeight
        lp.leftMargin = 0
        lp.topMargin = 0
    }

    /**
     * 幂等地保证桌宠内容**始终可见**（Phase 4C-6B-1.2 A3）。
     *
     * 隐藏机制已**彻底删除**：本类不再提供任何能把 `imageAlpha` 置 0 的入口，
     * 也不存在"菜单窗口接管人物"的开关。这里只兜住"万一被外部改成非 255"的情况。
     *
     * @return true 表示本次**真的做了纠正**（此前不是 255）；正常路径恒返回 false。
     */
    fun ensureSourceVisible(): Boolean {
        if (imageView.imageAlpha == 255) return false
        imageView.imageAlpha = 255
        return true
    }

    /** 下一帧诊断：桌宠内容层在**屏幕**上的绝对位置。 */
    fun petContentLocationOnScreen(): IntArray {
        val location = IntArray(2)
        petContent.getLocationOnScreen(location)
        return location
    }

    /** 下一帧诊断：桌宠内容层的真实尺寸。 */
    fun petContentSize(): IntArray = intArrayOf(petContent.width, petContent.height)

    fun setPlaceholderText(text: String) {
        placeholder.text = text
    }

    /** true = 显示"动态素材当前只有第一帧"角标。 */
    fun setAnimatedBadgeVisible(visible: Boolean) {
        badge.visibility = if (visible) View.VISIBLE else View.GONE
    }

    fun setAnimationPaused(paused: Boolean) {
        animationPaused = paused
    }

    fun imageViewSize(): IntArray = intArrayOf(imageView.width, imageView.height)

    /** 一行式诊断（日志与 `getState` 共用），**不省略任何关键字段**。 */
    fun dump(): String = buildString {
        append("visual=").append(visual)
        append(" size=").append(width).append('x').append(height)
        append(" measured=").append(measuredWidth).append('x').append(measuredHeight)
        append(" min=").append(minimumWidth).append('x').append(minimumHeight)
        append(" desired=").append(desiredWidthPx).append('x').append(desiredHeightPx)
        append(" visibility=").append(visibility)
        append(" alpha=").append(alpha)
        append(" scale=").append(scaleX).append('x').append(scaleY)
        append(" attached=").append(isAttachedToWindow)
        append(" shader=").append(if (petContent.background == null) "none" else "set")
        append(" image=").append(imageView.width).append('x').append(imageView.height)
        append(" imageVisibility=").append(imageView.visibility)
        append(" hasImage=").append(hasImage)
        append(" debug=").append(debugMode)
        append(" petContent=").append(petContent.width).append('x').append(petContent.height)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = desiredWidthPx.coerceAtLeast(1)
        val h = desiredHeightPx.coerceAtLeast(1)
        // 关键：必须先按"确定尺寸"调用 super，让 FrameLayout 正常测量子 View。
        // 只调 setMeasuredDimension 会让 ImageView / TextView 的 measuredWidth
        // 恒为 0，onLayout 把它们摆成 0×0 —— 窗口在，但什么都看不见。
        super.onMeasure(
            MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY),
        )
        setMeasuredDimension(w, h)
    }

    /** 把触摸事件交给手势状态机（Phase 4C-3A）。 */
    override fun onTouchEvent(event: android.view.MotionEvent): Boolean =
        touchHandler?.invoke(event) ?: super.onTouchEvent(event)

    private val density: Float
        get() = resources.displayMetrics.density

    /** dp → 整数像素（padding / margin / 描边宽度）。 */
    private fun dp(value: Float): Int = (value * density).roundToInt()

    /** dp → 浮点像素（`cornerRadius` 需要 Float）。 */
    private fun dpF(value: Float): Float = value * density
}
