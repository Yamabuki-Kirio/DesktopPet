package asia.akechi.petlife.overlay

/** 动作路由（需求 §17）。 */
internal enum class WheelActionRoute {
    /** 导航：打开子菜单 / 返回 / 关闭菜单 —— 4C-6B-1 **真实生效**。 */
    navigation,

    /** 业务：状态、素材、记录、同步、服务控制…… —— 4C-6B-1 只发**结构化占位事件**。 */
    business,

    /** 只读信息项：显示一条短提示，不改任何状态。 */
    info,
}

/** 分发结果（供日志与诊断使用）。 */
internal data class WheelActionOutcome(
    val route: WheelActionRoute,
    val action: WheelMenuAction,
    val entryId: String,
    /** 宿主是否真的处理了（导航类为 true；业务占位恒为 false）。 */
    val handled: Boolean,
)

/**
 * 轮盘宿主（由 `PetOverlayManager` 实现）。
 *
 * 刻意只有三个方法：**导航**、**业务占位**、**只读信息**。
 * 这样 4C-6B-2 只需替换 [onBusinessAction] 的实现，
 * 不必回头改轮盘的交互、绘制或几何。
 */
internal interface WheelMenuActionHost {

    /** 导航类。返回 `true` 表示已处理（用于日志与诊断）。 */
    fun onNavigateAction(action: WheelMenuAction, entryId: String): Boolean

    /** 业务类：4C-6B-1 只发结构化事件 + 调试提示，**不复制业务逻辑**。 */
    fun onBusinessAction(action: WheelMenuAction, entryId: String)

    /** 只读信息项（"当前状态""今日时长"等）。 */
    fun onInfoAction(entryId: String, entry: WheelMenuEntry)
}

/**
 * 统一动作分发（需求 §17）。
 *
 * "轮盘只是命令的发射器"这句话就落在这里：**交互层永远只调用 [dispatch]**，
 * 不允许任何一处直接去调业务方法 —— 否则"哪个动作是真的、哪个是占位"
 * 会散落在渲染代码里，4C-6B-2 接线时必然漏掉几处。
 */
internal class WheelMenuActionDispatcher(private val host: WheelMenuActionHost) {

    /** 最近一次分发的动作（诊断字段 `lastMenuAction` 的数据源）。 */
    var lastActionWire: String? = null
        private set

    var lastRoute: WheelActionRoute? = null
        private set

    fun routeOf(action: WheelMenuAction): WheelActionRoute = when (action) {
        WheelMenuAction.openPetMenu,
        WheelMenuAction.openAppearanceMenu,
        WheelMenuAction.openRecordsMenu,
        WheelMenuAction.openToolsMenu,
        WheelMenuAction.openSettingsMenu,
        WheelMenuAction.back,
        WheelMenuAction.closeMenu,
        -> WheelActionRoute.navigation

        WheelMenuAction.showInfo -> WheelActionRoute.info

        else -> WheelActionRoute.business
    }

    fun dispatch(action: WheelMenuAction, entryId: String, entry: WheelMenuEntry?): WheelActionOutcome {
        val route = routeOf(action)
        lastActionWire = action.wire
        lastRoute = route
        val handled = when (route) {
            WheelActionRoute.navigation -> host.onNavigateAction(action, entryId)
            WheelActionRoute.info -> {
                if (entry != null) host.onInfoAction(entryId, entry)
                false
            }
            WheelActionRoute.business -> {
                host.onBusinessAction(action, entryId)
                false
            }
        }
        return WheelActionOutcome(route, action, entryId, handled)
    }

    /**
     * 导航类动作对应的目标子菜单（`null` = 不是"进入子菜单"这条路径）。
     *
     * 单独抽出来是为了让"根条目 → 子菜单"的映射**只有一份**，
     * 界面、状态机与测试都读它。
     */
    fun targetLevelOf(action: WheelMenuAction): String? = when (action) {
        WheelMenuAction.openPetMenu -> WheelMenuCatalog.LEVEL_PET
        WheelMenuAction.openAppearanceMenu -> WheelMenuCatalog.LEVEL_APPEARANCE
        WheelMenuAction.openRecordsMenu -> WheelMenuCatalog.LEVEL_RECORDS
        WheelMenuAction.openToolsMenu -> WheelMenuCatalog.LEVEL_TOOLS
        WheelMenuAction.openSettingsMenu -> WheelMenuCatalog.LEVEL_SETTINGS
        else -> null
    }
}
