package asia.akechi.petlife.overlay

import kotlin.math.hypot

/**
 * 悬浮桌宠的手势状态（Phase 4C-3A）。
 *
 * 为什么要有明确状态而不是几个布尔值：拖动、点击、双指缩放三者互斥，
 * 用 `isDragging`/`isPressed`/`isScaling` 互相覆盖必然出现
 * "拖动结束误触发菜单""缩放中途把窗口拖走"这类竞态。
 *
 * 状态迁移（4C-3A 实现的部分）：
 * ```
 * IDLE --DOWN--> PRESSING --移动>touchSlop--> DRAGGING --UP--> IDLE
 *                    |                                        ↑
 *                    +---UP(未超 slop 且未超时)--> 点击 --> IDLE
 *                    +---UP(超时/超 slop)------> 取消 --> IDLE
 *                    +---CANCEL--------------------------> IDLE
 * ```
 * [SCALING] 属于 4C-3A 的可选双指缩放（第一版不实现，只在机器里预留转移），
 * [MENU_OPEN] 属于 4C-3B 的圆盘菜单，[HIDDEN] / [STOPPED] 由服务生命周期驱动。
 */
internal enum class OverlayGestureState {
    IDLE,
    PRESSING,
    DRAGGING,
    SCALING,
    MENU_OPEN,
    HIDDEN,
    STOPPED,
}

/** 一次触摸事件的**判定结果**（调用方据此操作窗口，机器本身不碰 WindowManager）。 */
internal enum class OverlayGestureEffect {
    /** 什么都不做。 */
    none,

    /** 手指按下（可以开始累积拖动）。 */
    press,

    /** 越过 touchSlop，正式开始拖动。 */
    dragStart,

    /** 拖动中（每次 MOVE 一次）。 */
    drag,

    /** 拖动结束（此时才允许持久化位置）。 */
    dragEnd,

    /** 判定为单击（移动未超 slop 且按下时间未超阈值）。 */
    click,

    /** 手势被取消（ACTION_CANCEL、超时、或多指介入）。 */
    cancel,
}

/**
 * 手势状态机（**纯逻辑**，可 JVM 单测）。
 *
 * 硬规则（对应需求"三、4C-3A 手势状态机"）：
 * 1. `DOWN` 后先进 [OverlayGestureState.PRESSING]；
 * 2. 移动超过 touchSlop 才进 [OverlayGestureState.DRAGGING]；
 * 3. [OverlayGestureState.DRAGGING] 状态下松手**一定不**产生 [OverlayGestureEffect.click]；
 * 4. [OverlayGestureState.SCALING] 状态下不拖动、不点击；
 * 5. `ACTION_CANCEL` 必须回到干净状态。
 *
 * touchSlop 由调用方传入 `ViewConfiguration.getScaledTouchSlop()`，
 * **不写死像素阈值**。
 */
internal class OverlayGestureMachine(
    private val touchSlopPx: Int,
    private val tapTimeoutMs: Long = OverlayGeometry.TAP_TIMEOUT_MS,
) {

    var state: OverlayGestureState = OverlayGestureState.IDLE
        private set

    /**
     * 窗口当前是否可以更新（已挂载且 `isAttachedToWindow == true`）。
     *
     * 为 false 时**不允许进入拖动**：否则会出现"View 已经被摘掉，
     * 还在对它调 updateViewLayout"（需求"三、第 7/8 条"）。
     */
    var windowUpdatable: Boolean = true

    private var downX: Float = 0f
    private var downY: Float = 0f
    private var downAtMs: Long = 0L
    private var dragging: Boolean = false

    /** touchSlop 至少为 1，避免"任何移动都算拖动"。 */
    private val slop: Int get() = touchSlopPx.coerceAtLeast(1)

    fun onDown(x: Float, y: Float, timeMs: Long, pointerCount: Int = 1): OverlayGestureEffect {
        if (state == OverlayGestureState.HIDDEN || state == OverlayGestureState.STOPPED) {
            return OverlayGestureEffect.none
        }
        // 第二根手指落下：进入缩放（4C-3A 第一版不实现缩放，直接取消手势，
        // 保证"双指时既不会拖动也不会打开菜单"）。
        if (pointerCount > 1) {
            return beginScaling()
        }
        state = OverlayGestureState.PRESSING
        downX = x
        downY = y
        downAtMs = timeMs
        dragging = false
        return OverlayGestureEffect.press
    }

    fun onMove(x: Float, y: Float, timeMs: Long, pointerCount: Int = 1): OverlayGestureEffect {
        if (pointerCount > 1) {
            // 拖动中突然多指：立即结束拖动（不持久化——交给 cancel 语义），进入缩放态。
            if (state == OverlayGestureState.DRAGGING || state == OverlayGestureState.PRESSING) {
                return beginScaling()
            }
            return OverlayGestureEffect.none
        }
        return when (state) {
            OverlayGestureState.PRESSING,
            // 菜单打开时按下桌宠：依然允许"移动超过 slop → 开始拖动"
            // （需求 3.3：菜单打开时开始拖动要先关菜单，再进入 DRAGGING）。
            OverlayGestureState.MENU_OPEN,
            ->
                if (!windowUpdatable) {
                    // 窗口不可更新（未附着）：不进入拖动，位置一动不动。
                    OverlayGestureEffect.none
                } else if (movedBeyondSlop(x, y)) {
                    state = OverlayGestureState.DRAGGING
                    dragging = true
                    OverlayGestureEffect.dragStart
                } else {
                    OverlayGestureEffect.none
                }
            OverlayGestureState.DRAGGING -> OverlayGestureEffect.drag
            else -> OverlayGestureEffect.none
        }
    }

    fun onUp(x: Float, y: Float, timeMs: Long, pointerCount: Int = 1): OverlayGestureEffect {
        if (pointerCount > 1) return beginScaling()
        val previous = state
        val beyondSlop = movedBeyondSlop(x, y)
        val withinTapTime = timeMs - downAtMs in 0..tapTimeoutMs
        clearGesture()

        return when (previous) {
            // 拖动过就绝不再判点击（需求 3 / 7.5 的硬规则）。
            OverlayGestureState.DRAGGING -> OverlayGestureEffect.dragEnd
            OverlayGestureState.PRESSING ->
                if (!beyondSlop && withinTapTime) {
                    OverlayGestureEffect.click
                } else {
                    OverlayGestureEffect.cancel
                }
            else -> OverlayGestureEffect.none
        }
    }

    fun onCancel(): OverlayGestureEffect {
        val previous = state
        clearGesture()
        return when (previous) {
            OverlayGestureState.PRESSING,
            OverlayGestureState.DRAGGING,
            OverlayGestureState.SCALING,
            -> OverlayGestureEffect.cancel
            else -> OverlayGestureEffect.none
        }
    }

    /** 窗口隐藏 / 服务停止：取消一切进行中的手势（需求 5）。 */
    fun suspend(target: OverlayGestureState) {
        require(target == OverlayGestureState.HIDDEN || target == OverlayGestureState.STOPPED) {
            "suspend 只接受 HIDDEN / STOPPED"
        }
        clearGesture()
        state = target
    }

    /** 菜单已打开：进入 [OverlayGestureState.MENU_OPEN]（幂等）。 */
    fun onMenuOpened() {
        if (state == OverlayGestureState.HIDDEN || state == OverlayGestureState.STOPPED) return
        clearGesture()
        state = OverlayGestureState.MENU_OPEN
    }

    /** 菜单已关闭：回到 [OverlayGestureState.IDLE]（幂等；HIDDEN/STOPPED 不被覆盖）。 */
    fun onMenuClosed() {
        if (state == OverlayGestureState.HIDDEN || state == OverlayGestureState.STOPPED) return
        clearGesture()
        state = OverlayGestureState.IDLE
    }

    /** 菜单当前是否处于打开态（诊断 / 命中判定用）。 */
    fun isMenuOpen(): Boolean = state == OverlayGestureState.MENU_OPEN

    /** 是否正处于"拖动中"（调用方据此决定要不要写窗口坐标）。 */
    fun isDragging(): Boolean = dragging

    /** 缩放态（4C-3A 第一版只用于"取消手势"，不产生窗口变化）。 */
    private fun beginScaling(): OverlayGestureEffect {
        val previous = state
        dragging = false
        state = OverlayGestureState.SCALING
        return if (previous == OverlayGestureState.DRAGGING ||
            previous == OverlayGestureState.PRESSING
        ) {
            OverlayGestureEffect.cancel
        } else {
            OverlayGestureEffect.none
        }
    }

    private fun clearGesture() {
        dragging = false
        downX = 0f
        downY = 0f
        downAtMs = 0L
        if (state != OverlayGestureState.HIDDEN && state != OverlayGestureState.STOPPED) {
            state = OverlayGestureState.IDLE
        }
    }

    private fun movedBeyondSlop(x: Float, y: Float): Boolean =
        hypot((x - downX).toDouble(), (y - downY).toDouble()) > slop
}
