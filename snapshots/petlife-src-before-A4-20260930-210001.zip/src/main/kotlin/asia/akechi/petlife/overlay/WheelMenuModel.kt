package asia.akechi.petlife.overlay

/**
 * 轮盘菜单的**统一命令**（Phase 4C-6B-1，需求 §17）。
 *
 * 为什么先定命令再画菜单：菜单只是这些命令的"发射器"。
 * 4C-6B-1 只让导航类命令真实生效（打开 / 返回 / 关闭），
 * 其余命令一律走 [WheelMenuActionDispatcher] 的**结构化占位事件**，
 * 真正的业务接线留给 4C-6B-2 —— 这样"轮盘动画问题"与"业务问题"
 * 不会在同一轮真机验收里混在一起。
 *
 * [wire] 是与 Flutter / 日志/ 事件共用的稳定字符串（**不得随意改名**）。
 */
internal enum class WheelMenuAction(val wire: String) {
    // --- 导航（4C-6B-1 真实生效）---
    openPetMenu("openPetMenu"),
    openAppearanceMenu("openAppearanceMenu"),
    openRecordsMenu("openRecordsMenu"),
    openToolsMenu("openToolsMenu"),
    openSettingsMenu("openSettingsMenu"),
    hideOverlay("hideOverlay"),
    back("back"),
    closeMenu("closeMenu"),

    // --- 桌宠 ---
    toggleAutomaticState("toggleAutomaticState"),
    choosePetState("choosePetState"),
    restoreAutomaticState("restoreAutomaticState"),
    togglePositionLock("togglePositionLock"),
    changePetSize("changePetSize"),
    resetPetPosition("resetPetPosition"),

    // --- 形象 ---
    previousAsset("previousAsset"),
    nextAsset("nextAsset"),
    randomAsset("randomAsset"),
    toggleFavorite("toggleFavorite"),
    switchCharacter("switchCharacter"),
    openStateMapping("openStateMapping"),
    openAssetLibrary("openAssetLibrary"),

    // --- 记录 ---
    toggleTracking("toggleTracking"),
    syncNow("syncNow"),
    openUsageStatistics("openUsageStatistics"),

    // --- 工具 ---
    startFocusTimer("startFocusTimer"),
    openShortcut("openShortcut"),
    openPetLife("openPetLife"),

    // --- 设置 ---
    selectTheme("selectTheme"),
    changeOpacity("changeOpacity"),
    changeMenuDistance("changeMenuDistance"),
    toggleHaptics("toggleHaptics"),
    toggleSound("toggleSound"),
    openDiagnostics("openDiagnostics"),
    restartOverlayService("restartOverlayService"),
    stopOverlayService("stopOverlayService"),

    /** 只读信息项（"当前应用""同步状态"等），点击不产生副作用。 */
    showInfo("showInfo"),
}

/** 轮盘图标 key（**原创几何**，见 `WheelMenuIcons`；不使用任何游戏美术资源）。 */
internal enum class WheelMenuIcon {
    pet,
    appearance,
    record,
    tools,
    gear,
    hide,
    cycle,
    state,
    hand,
    refresh,
    pin,
    resize,
    home,
    back,
    prev,
    next,
    shuffle,
    heart,
    character,
    mapping,
    library,
    clock,
    app,
    pause,
    sync,
    cloud,
    chart,
    timer,
    bolt,
    star,
    edit,
    palette,
    opacity,
    ruler,
    vibrate,
    sound,
    info,
    restart,
    power,
}

/**
 * 一个轮盘条目。
 *
 * [titleEn] / [titleZh] / [description] 三者是需求 §3 的"大号倾斜英文标题 +
 * 中文名称 + 一句简短说明"三层信息；根菜单条目三者齐全，子菜单条目通常
 * 只有中文名（`titleEn` 为空时渲染层只画中文）。
 */
internal data class WheelMenuEntry(
    val id: String,
    val action: WheelMenuAction,
    val icon: WheelMenuIcon,
    val labelZh: String,
    val titleEn: String? = null,
    val description: String? = null,
    val enabled: Boolean = true,
    /** `true` = 固定槽位的"返回"（永远排在视觉最下方，不参与重排）。 */
    val isBack: Boolean = false,
)

/** 一个菜单层级。 */
internal data class WheelMenuLevel(
    val id: String,
    val titleEn: String,
    val titleZh: String,
    val entries: List<WheelMenuEntry>,
) {
    val itemCount: Int get() = entries.size
}

/**
 * 菜单目录（需求 §4）：根菜单固定六项，五个子菜单 + 一个直接动作。
 *
 * 全部条目的 `action` 都已钉死 —— 4C-6B-2 只需要替换
 * [WheelMenuActionDispatcher] 的处理器，**不需要动菜单结构**。
 */
internal object WheelMenuCatalog {

    const val ROOT_ID = "root"
    const val LEVEL_PET = "pet"
    const val LEVEL_APPEARANCE = "appearance"
    const val LEVEL_RECORDS = "records"
    const val LEVEL_TOOLS = "tools"
    const val LEVEL_SETTINGS = "settings"

    /** 固定返回键（需求 §5）。 */
    private val BACK = WheelMenuEntry(
        id = "back",
        action = WheelMenuAction.back,
        icon = WheelMenuIcon.back,
        labelZh = "返回",
        description = "回到上一层",
        isBack = true,
    )

    /** 根菜单：桌宠 / 形象 / 记录 / 工具 / 设置 / 隐藏。 */
    val ROOT: WheelMenuLevel = WheelMenuLevel(
        id = ROOT_ID,
        titleEn = "PETLIFE",
        titleZh = "桌宠",
        entries = listOf(
            WheelMenuEntry(
                id = "root_pet",
                action = WheelMenuAction.openPetMenu,
                icon = WheelMenuIcon.pet,
                labelZh = "桌宠",
                titleEn = "PET",
                description = "AUTO MODE",
            ),
            WheelMenuEntry(
                id = "root_appearance",
                action = WheelMenuAction.openAppearanceMenu,
                icon = WheelMenuIcon.appearance,
                labelZh = "形象",
                titleEn = "APPEARANCE",
                description = "角色与素材",
            ),
            WheelMenuEntry(
                id = "root_records",
                action = WheelMenuAction.openRecordsMenu,
                icon = WheelMenuIcon.record,
                labelZh = "记录",
                titleEn = "RECORD",
                description = "今日使用时长",
            ),
            WheelMenuEntry(
                id = "root_tools",
                action = WheelMenuAction.openToolsMenu,
                icon = WheelMenuIcon.tools,
                labelZh = "工具",
                titleEn = "TOOLS",
                description = "专注与快捷入口",
            ),
            WheelMenuEntry(
                id = "root_settings",
                action = WheelMenuAction.openSettingsMenu,
                icon = WheelMenuIcon.gear,
                labelZh = "设置",
                titleEn = "SYSTEM",
                description = "主题与服务",
            ),
            WheelMenuEntry(
                id = "root_hide",
                action = WheelMenuAction.hideOverlay,
                icon = WheelMenuIcon.hide,
                labelZh = "隐藏",
                titleEn = "HIDE",
                description = "隐藏桌宠（服务继续运行）",
            ),
        ),
    )

    /** 桌宠子菜单（需求 §4.1）。 */
    val PET: WheelMenuLevel = WheelMenuLevel(
        id = LEVEL_PET,
        titleEn = "PET",
        titleZh = "桌宠",
        entries = listOf(
            WheelMenuEntry("pet_auto", WheelMenuAction.toggleAutomaticState, WheelMenuIcon.cycle, "自动状态"),
            WheelMenuEntry("pet_current", WheelMenuAction.showInfo, WheelMenuIcon.state, "当前状态"),
            WheelMenuEntry("pet_manual", WheelMenuAction.choosePetState, WheelMenuIcon.hand, "手动状态"),
            WheelMenuEntry(
                "pet_restore",
                WheelMenuAction.restoreAutomaticState,
                WheelMenuIcon.refresh,
                "恢复自动",
            ),
            WheelMenuEntry("pet_lock", WheelMenuAction.togglePositionLock, WheelMenuIcon.pin, "锁定位置"),
            WheelMenuEntry("pet_size", WheelMenuAction.changePetSize, WheelMenuIcon.resize, "调整大小"),
            WheelMenuEntry("pet_home", WheelMenuAction.resetPetPosition, WheelMenuIcon.home, "默认位置"),
            BACK,
        ),
    )

    /** 形象子菜单（需求 §4.2）。 */
    val APPEARANCE: WheelMenuLevel = WheelMenuLevel(
        id = LEVEL_APPEARANCE,
        titleEn = "APPEARANCE",
        titleZh = "形象",
        entries = listOf(
            WheelMenuEntry("appearance_prev", WheelMenuAction.previousAsset, WheelMenuIcon.prev, "上一素材"),
            WheelMenuEntry("appearance_next", WheelMenuAction.nextAsset, WheelMenuIcon.next, "下一素材"),
            WheelMenuEntry("appearance_random", WheelMenuAction.randomAsset, WheelMenuIcon.shuffle, "随机素材"),
            WheelMenuEntry("appearance_fav", WheelMenuAction.toggleFavorite, WheelMenuIcon.heart, "收藏"),
            WheelMenuEntry(
                "appearance_character",
                WheelMenuAction.switchCharacter,
                WheelMenuIcon.character,
                "切换角色",
            ),
            WheelMenuEntry(
                "appearance_mapping",
                WheelMenuAction.openStateMapping,
                WheelMenuIcon.mapping,
                "状态映射",
            ),
            WheelMenuEntry(
                "appearance_library",
                WheelMenuAction.openAssetLibrary,
                WheelMenuIcon.library,
                "素材库",
            ),
            BACK,
        ),
    )

    /** 记录子菜单（需求 §4.3）。 */
    val RECORDS: WheelMenuLevel = WheelMenuLevel(
        id = LEVEL_RECORDS,
        titleEn = "RECORD",
        titleZh = "记录",
        entries = listOf(
            WheelMenuEntry("records_today", WheelMenuAction.showInfo, WheelMenuIcon.clock, "今日时长"),
            WheelMenuEntry("records_app", WheelMenuAction.showInfo, WheelMenuIcon.app, "当前应用"),
            WheelMenuEntry("records_track", WheelMenuAction.toggleTracking, WheelMenuIcon.pause, "暂停/恢复"),
            WheelMenuEntry("records_sync", WheelMenuAction.syncNow, WheelMenuIcon.sync, "立即同步"),
            WheelMenuEntry("records_sync_state", WheelMenuAction.showInfo, WheelMenuIcon.cloud, "同步状态"),
            WheelMenuEntry(
                "records_stats",
                WheelMenuAction.openUsageStatistics,
                WheelMenuIcon.chart,
                "详细统计",
            ),
            BACK,
        ),
    )

    /** 工具子菜单（需求 §4.4）。 */
    val TOOLS: WheelMenuLevel = WheelMenuLevel(
        id = LEVEL_TOOLS,
        titleEn = "TOOLS",
        titleZh = "工具",
        entries = listOf(
            WheelMenuEntry("tools_focus", WheelMenuAction.startFocusTimer, WheelMenuIcon.timer, "专注计时"),
            WheelMenuEntry("tools_shortcut", WheelMenuAction.openShortcut, WheelMenuIcon.bolt, "快捷应用"),
            WheelMenuEntry("tools_open_app", WheelMenuAction.openPetLife, WheelMenuIcon.star, "打开 PetLife"),
            WheelMenuEntry(
                "tools_custom",
                WheelMenuAction.openShortcut,
                WheelMenuIcon.edit,
                "自定义快捷入口",
            ),
            BACK,
        ),
    )

    /** 设置子菜单（需求 §4.5）。 */
    val SETTINGS: WheelMenuLevel = WheelMenuLevel(
        id = LEVEL_SETTINGS,
        titleEn = "SYSTEM",
        titleZh = "设置",
        entries = listOf(
            WheelMenuEntry("settings_theme", WheelMenuAction.selectTheme, WheelMenuIcon.palette, "主题"),
            WheelMenuEntry("settings_opacity", WheelMenuAction.changeOpacity, WheelMenuIcon.opacity, "透明度"),
            WheelMenuEntry(
                "settings_distance",
                WheelMenuAction.changeMenuDistance,
                WheelMenuIcon.ruler,
                "菜单距离",
            ),
            WheelMenuEntry("settings_haptics", WheelMenuAction.toggleHaptics, WheelMenuIcon.vibrate, "触觉反馈"),
            WheelMenuEntry("settings_sound", WheelMenuAction.toggleSound, WheelMenuIcon.sound, "音效"),
            WheelMenuEntry(
                "settings_diagnostics",
                WheelMenuAction.openDiagnostics,
                WheelMenuIcon.info,
                "诊断信息",
            ),
            WheelMenuEntry(
                "settings_restart",
                WheelMenuAction.restartOverlayService,
                WheelMenuIcon.restart,
                "重启服务",
            ),
            WheelMenuEntry(
                "settings_stop",
                WheelMenuAction.stopOverlayService,
                WheelMenuIcon.power,
                "停止服务",
            ),
            BACK,
        ),
    )

    private val LEVELS: Map<String, WheelMenuLevel> = listOf(
        ROOT, PET, APPEARANCE, RECORDS, TOOLS, SETTINGS,
    ).associateBy { it.id }

    fun level(id: String): WheelMenuLevel? = LEVELS[id]

    /** 子菜单 ID → 其父级永远是根菜单（层级只有两级 + 固定返回）。 */
    fun isRoot(id: String): Boolean = id == ROOT_ID

    /**
     * 一个层级最多多少项 —— 几何层据此决定按钮尺寸与环带半径，
     * 需求 §4.5 的"设置"是最大的一层（8 项 + 返回 = 9）。
     */
    val maxItems: Int = LEVELS.values.maxOf { it.itemCount }

    /**
     * 所有条目里最长的中文标签字数。
     *
     * 用来估算"文字 chip 可能伸出刀刃多远"，好把它算进菜单窗口包围盒 ——
     * 真机反馈的"桌宠/形象/记录/工具/设置/隐藏 被窗口矩形裁切"就是漏了这一步。
     */
    val maxLabelChars: Int = LEVELS.values
        .flatMap { it.entries }
        .maxOfOrNull { it.labelZh.length }
        ?: 1

    /** 命中"直接动作"的根条目（"隐藏"不进子菜单，需求 §4.6）。 */
    fun directActionOf(levelId: String, index: Int): WheelMenuAction? {
        val level = level(levelId) ?: return null
        return level.entries.getOrNull(index)?.action
    }
}

/**
 * 菜单栈（需求 §5）。
 *
 * **只有这一处维护层级**：进入子菜单 = `push`，返回 = `pop`，
 * 关闭 = `clear`。绝不为每个子菜单写独立的返回逻辑 ——
 * 那正是"多级返回错乱"的根源。
 */
internal class WheelMenuStack {

    private val ids = ArrayList<String>()

    val depth: Int get() = ids.size

    val isEmpty: Boolean get() = ids.isEmpty()

    /** 栈顶（当前层级）；空栈返回 `null`。 */
    val currentId: String?
        get() = ids.lastOrNull()

    val current: WheelMenuLevel?
        get() = currentId?.let { WheelMenuCatalog.level(it) }

    fun path(): List<String> = ids.toList()

    /** 打开根菜单（幂等：已打开时不清空子层级）。 */
    fun open() {
        if (ids.isEmpty()) ids.add(WheelMenuCatalog.ROOT_ID)
    }

    /** 进入子菜单；非法层级**拒绝**（保持原层级，绝不产生非法路径）。 */
    fun push(levelId: String): Boolean {
        if (WheelMenuCatalog.level(levelId) == null) return false
        if (WheelMenuCatalog.isRoot(levelId)) return false
        if (ids.isEmpty()) return false
        if (ids.last() == levelId) return false
        ids.add(levelId)
        return true
    }

    /** 返回一级；在根菜单时返回 `false`（**不关闭菜单**，关闭是另一个动作）。 */
    fun pop(): Boolean {
        if (ids.size <= 1) return false
        ids.removeAt(ids.size - 1)
        return true
    }

    /** 一路回根（长按返回 / 需求 §5 的可选能力）。 */
    fun popToRoot(): Boolean {
        if (ids.size <= 1) return false
        while (ids.size > 1) ids.removeAt(ids.size - 1)
        return true
    }

    fun clear() {
        ids.clear()
    }
}
