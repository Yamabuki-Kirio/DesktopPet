﻿package asia.akechi.petlife.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import java.util.Locale

/**
 * 服务向窗口层暴露的**持久化回调**。
 *
 * 为什么不让 manager 直接写 `SharedPreferences`：位置的"存"与"取"必须成对
 * 出现在同一个地方（服务），否则容易出现"窗口按 A 规则摆放、存储按 B 规则写入"
 * 这种自相矛盾的组合。manager 只负责算，服务负责存。
 */
internal interface OverlayWindowHost {

    /**
     * 手势结束后持久化位置（**只在松手/动画结束时调用一次**，绝不在 MOVE 里写盘）。
     *
     * @param xRatio 相对可用区域横向比例（0~1）
     * @param yRatio 相对可用区域纵向比例（0~1）
     * @param edge   当前吸附到的边（关闭吸附时为 [OverlaySnapEdge.none]）
     */
    fun onPersistPosition(xRatio: Float, yRatio: Float, edge: OverlaySnapEdge)

    /** 单击桌宠（4C-3A 只记日志；4C-3B 在 manager 里开关圆盘菜单）。 */
    fun onClickPet()

    /**
     * 轮盘条目动作（Phase 4C-6B-1）。
     *
     * 只传**原始值**（命令 wire / 条目 id / 说明），不传轮盘模型：
     * 服务是 public 类，不能把 internal 的菜单模型暴露到它的重写签名里。
     *
     * 4C-6B-1 只有导航类真实生效；[detail] 里带的是占位说明（业务类），
     * 服务侧据此记日志并给一句短提示，**不复制任何业务逻辑**。
     */
    fun onMenuAction(actionWire: String, itemId: String, detail: String)

    /**
     * 轮盘选中项的**只读实时信息**（需求 §3 的"可选实时状态"）。
     *
     * 必须只读**已经缓存的**值：绝不查数据库、绝不打新的使用统计查询 ——
     * 它会在选中变化时被调用，不能有 IO。
     */
    fun onMenuInfo(itemId: String): String?

    /**
     * 原子几何提交后的**下一帧**核对结果（Phase 4C-3B 收尾修复）。
     *
     * manager 读不到服务里的静态诊断字段，因此把结果回调给服务由它发布。
     * [settled] 为 false 说明下一帧桌宠的绝对位置与提交前不一致（>1px）——
     * 那是真机上"抽动"的直接证据。
     */
    fun onGeometrySettled(tag: String, deltaX: Int, deltaY: Int, settled: Boolean)
}

/**
 * 悬浮窗的 WindowManager 生命周期 + 位置/尺寸/手势（Phase 4C-3A）。
 *
 * 单实例由这里保证：任何时刻**最多**持有一个 [PetOverlayView] 与一份
 * [WindowManager.LayoutParams]；[attach] 幂等（已挂载时只更新，不新建第二个窗口）。
 *
 * 四条硬规则（4C-3A）：
 * 1. 所有 `WindowManager` 操作都在**主线程**串行（[requireMainThread] 会告警）；
 * 2. 拖动过程只 `updateViewLayout`，**不写盘、不 removeView/addView**；
 * 3. 位置一律以**相对比例 + 可用区域**重算，绝不把绝对像素当作恢复依据；
 * 4. 窗口未附着（[View.isAttachedToWindow] 为 false）时**不执行** `updateViewLayout`。
 */
internal class PetOverlayManager(
    private val context: Context,
    private val host: OverlayWindowHost,
) : WheelMenuActionHost {

    private val windowManager: WindowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var view: PetOverlayView? = null
    private var params: WindowManager.LayoutParams? = null

    /** 当前可用区域（每次计算都重新解析，横竖屏/分屏后自动生效）。 */
    private var bounds: OverlayBounds = OverlayBounds.unknown

    /** 手势状态机：**每个窗口一个**，因此新窗口一定是干净的 IDLE。 */
    private var gesture: OverlayGestureMachine? = null

    /** 拖动起点（屏幕原始坐标）与窗口起点（LP 坐标）。 */
    private var pressRawX: Float = 0f
    private var pressRawY: Float = 0f
    private var dragOriginX: Int = 0
    private var dragOriginY: Int = 0

    private var snapAnimator: ValueAnimator? = null

    /** 进行中的贴边动画的目标（动画被打断时要按它落定，不能停在中间帧）。 */
    private var snapTargetEdge: OverlaySnapEdge = OverlaySnapEdge.none
    private var snapTargetX: Int = 0
    private var snapTargetY: Int = 0

    // --- Phase 4C-6B-1：P3P 风格分层轮盘 ---
    //
    // 结构沿用 4C-3B 的双窗口结论（**不要把轮盘并回桌宠窗口**）：
    // 桌宠窗口的 LayoutParams 在开/关菜单时一个字段都不改，轮盘画在独立菜单窗口里。

    /** 菜单**窗口级**状态（唯一权威；不额外维护 menuOpen/menuOpening 之类的布尔量）。 */
    private var menuState: OverlayMenuState = OverlayMenuState.closed

    /** 轮盘菜单窗口（**独立窗口**；null = 当前没有菜单窗口）。 */
    private var menuView: WheelMenuView? = null
    private var menuParams: WindowManager.LayoutParams? = null

    /**
     * 本次打开的**信封**：窗口矩形 + 轮盘中心 + 环带半径上限。
     *
     * 打开时算一次，之后根选项切换 / 层级切换都只改内部绘制（需求 §14）。
     */
    private var envelope: WheelMenuEnvelope? = null

    /** 最近一次轮盘布局（诊断用）。 */
    private var activeLayout: WheelMenuLayout? = null

    /** 当前生效的轮盘主题（打开时快照；设置页改动会即时下发）。 */
    private var menuTheme: WheelMenuTheme = WheelMenuThemes.default()

    /** 上一次展开方向（用于中央缓冲区的滞回；null = 本次运行还没开过）。 */
    private var lastDirection: WheelExpandDirection? = null

    /** 上一次垂直模式（用于阈值附近的滞回，需求 §8）。 */
    private var lastVerticalMode: WheelVerticalMode? = null

    /** 轮盘布局设置（尺寸 / 距离 / 紧凑；与主题分开，需求 §5）。 */
    private var menuSettings: WheelMenuLayoutSettings = WheelMenuLayoutSettings.DEFAULT

    /**
     * 当前素材的**视觉边界**（由服务在解码成功后测量；null = 按整张图处理）。
     *
     * 中央缺口必须按视觉边界算，否则透明留白会把缺口撑得远大于人物（需求 §3）。
     */
    private var petContentBounds: PetContentBounds? = null

    /** 服务在素材解码成功后把视觉边界交给窗口层。 */
    fun setPetContentBounds(bounds: PetContentBounds?) {
        petContentBounds = bounds
    }

    // --- Phase 4C-6B-1.1 真机回归：菜单打开链路的可判定诊断 ---
    //
    // 真机症状是"点击桌宠完全没有菜单"。为了不用猜，把这条链路拆成 5 个可判定状态：
    // 没收到点击 / 收到点击但没请求打开 / 请求了但 addView 失败 /
    // addView 成功但 View 未附着（被系统拒绝或被压在下面）/ 菜单存在但几何不可见。

    private var petTapReceived: Boolean = false
    private var menuOpenRequested: Boolean = false
    private var menuAddViewAttempted: Boolean = false
    private var menuAddViewSucceeded: Boolean = false
    private var lastMenuOpenError: String? = null

    /** 一行式可判定诊断（写进日志与运行时状态，设置页直接显示）。 */
    fun menuOpenDiagnostics(): String {
        // 发布前先兜底保证桌宠可见（视觉规则已固定为"桌宠窗口自绘"）。
        enforcePetAlwaysVisible("diagnostics")
        val bounds = menuParams?.let { "(${it.x},${it.y} ${it.width}x${it.height})" } ?: "none"
        val visibility = menuView?.let {
            when {
                it.visibility == View.VISIBLE -> "VISIBLE"
                it.visibility == View.INVISIBLE -> "INVISIBLE"
                else -> "GONE"
            }
        } ?: "none"
        val intrinsic = activeLayout?.let {
            "${(it.rimOuterPx * 2).toInt()}x${(it.bladeLengthPx * 2).toInt()}"
        } ?: "none"
        return "tap=${if (petTapReceived) 1 else 0}" +
            " req=${if (menuOpenRequested) 1 else 0}" +
            " addAttempt=${if (menuAddViewAttempted) 1 else 0}" +
            " addOk=${if (menuAddViewSucceeded) 1 else 0}" +
            " attached=${if (menuView?.isAttachedToWindow == true) 1 else 0}" +
            " vis=$visibility" +
            " bounds=$bounds" +
            " types=${OverlayWindowSpec.menuWindowType(Build.VERSION.SDK_INT)}/" +
            "${OverlayWindowSpec.petWindowType(Build.VERSION.SDK_INT)}" +
            " err=${lastMenuOpenError ?: "<none>"}" +
            " | intrinsic=$intrinsic" +
            " placed=${activeLayout?.windowRect ?: "none"}" +
            " wheelScale=${menuSettings.preferredScale}" +
            " buttonScale=${menuSettings.buttonVisualScale}" +
            " dir=${activeLayout?.direction?.name ?: "none"}" +
            // 【A3】三项恒定：隐藏机制已彻底删除，视觉所有权不可切换。
            PetVisualInvariant.diagnosticSegment()
    }

    /** 菜单打开**之前**桌宠窗口的矩形（只用于下一帧核对"桌宠绝对没动"）。 */
    private var petRectBeforeMenu: OverlayRect? = null

    /** 已经 detach：动画回调不得再操作 WindowManager。 */
    private var disposed: Boolean = false

    /** 轮盘尺寸参数（px，按密度换算，attach/applySettings 时刷新）。 */
    private var wheelSpec: WheelMenuSpec = WheelMenuSpec.fromDensity(1f)

    /** 统一动作分发（需求 §17）：导航真实生效，业务项只发结构化占位事件。 */
    private val actions: WheelMenuActionDispatcher by lazy { WheelMenuActionDispatcher(this) }

    /** 缓存的设置（拖动/吸附路径需要，避免每次回读 SharedPreferences）。 */
    private var snapEnabled: Boolean = true
    private var debugMode: Boolean = false

    /** 轮盘触觉反馈开关（同样缓存，避免每次开菜单回读）。 */
    private var menuHapticsEnabled: Boolean = true

    /** 按钮视觉缩放（独立于轮盘缩放，需求 §4.3）。 */
    private var menuButtonScale: Float = WheelMenuLayoutSettings.DEFAULT_BUTTON_SCALE

    /** 触摸穿透开启时窗口收不到事件，这里再兜一层。 */
    private var touchThrough: Boolean = false

    /** 最近一次 addView / updateViewLayout 的失败原因（诊断用）。 */
    var lastWindowError: String? = null
        private set

    /** 最近一次 addView / updateViewLayout 的结果（诊断用，成功也要留痕）。 */
    var lastWindowAction: String = "none"
        private set

    val isAttached: Boolean get() = view != null

    /** 窗口当前是否可见（我们从不主动把根 View 设为 GONE，这里如实反映）。 */
    val isVisible: Boolean get() = view?.visibility == View.VISIBLE

    /** 根 View 是否已附着到窗口（`addView` 真正生效的判据）。 */
    val isAttachedToWindow: Boolean get() = view?.isAttachedToWindow == true

    /** 当前手势状态名（诊断）。 */
    val gestureStateName: String get() = gesture?.state?.name ?: OverlayGestureState.IDLE.name

    /** 当前菜单状态名（诊断）。 */
    val menuStateName: String get() = menuState.name

    /** 菜单是否占着扩展窗口（此时必须接收"外部点击关闭"）。 */
    val isMenuOpen: Boolean get() = menuState.occupiesWindow

    /** 当前菜单条目数量（诊断）。 */
    val menuButtonCount: Int get() = activeLayout?.itemCount ?: 0

    /** 菜单窗口是否已经挂在 WindowManager 上（诊断）。 */
    val isMenuWindowAttached: Boolean get() = menuView != null

    /** 轮盘当前层级（诊断）。 */
    val menuLevelName: String get() = menuView?.levelIdName ?: "none"

    /** 轮盘当前选中槽位（诊断）。 */
    val menuActiveIndex: Int get() = menuView?.activeIndexNow ?: 0

    /** 轮盘当前动画（诊断）。 */
    val menuAnimationName: String get() = menuView?.animationName ?: "idle"

    /** 轮盘手势归属（诊断）。 */
    val menuGestureOwnerName: String get() = menuView?.gestureOwnerName ?: "none"

    /** 最近一次动作路由（诊断）。 */
    val lastMenuActionWire: String? get() = actions.lastActionWire

    /** 最近一次动作是否只是占位（诊断）。 */
    val lastMenuActionIsPlaceholder: Boolean get() = actions.lastRoute != null &&
        actions.lastRoute != WheelActionRoute.navigation

    /** 性能指标（需求 §15 的调试指标）。 */
    fun menuPerformanceSummary(): String {
        val stats = menuView?.frameStatsSnapshot() ?: return "wheel perf=<none>"
        return String.format(
            Locale.US,
            "wheel perf frames=%d avg=%.1fms max=%.1fms dropped=%d",
            stats.frames,
            stats.averageMs,
            stats.maxMs,
            stats.dropped,
        )
    }

    /** 最近一次轮盘几何的一句话摘要（诊断）。 */
    fun menuSummary(): String {
        val current = activeLayout ?: return "wheel=<none>"
        val env = envelope
        return "wheel dir=${current.direction.labelZh} level=${menuLevelName} " +
            "items=${current.itemCount} active=${menuActiveIndex} " +
            "radius=${current.ringRadiusPx.toInt()} step=${current.stepDeg.toInt()} " +
            "blade=${current.bladeLengthPx.toInt()} degraded=${current.degraded} " +
            "window=${env?.windowRect ?: "none"} anim=$menuAnimationName gesture=$menuGestureOwnerName"
    }

    fun viewSize(): IntArray {
        val v = view ?: return intArrayOf(0, 0)
        return intArrayOf(v.width, v.height)
    }

    fun imageViewSize(): IntArray = view?.imageViewSize() ?: intArrayOf(0, 0)

    /**
     * 桌宠窗口的**绝对**屏幕矩形（= 桌宠的绝对矩形）。
     *
     * 双窗口方案下这是唯一权威来源：桌宠窗口的 LayoutParams 就是桌宠的位置与尺寸，
     * 菜单在**另一个**窗口里，因此开/关菜单不会改动这里任何字段（抽动在结构上不可能发生）。
     */
    private fun petWindowRect(): OverlayRect {
        val p = params ?: return OverlayRect(0, 0, 0, 0)
        return OverlayRect(
            left = p.x,
            top = p.y,
            right = p.x + p.width.coerceAtLeast(1),
            bottom = p.y + p.height.coerceAtLeast(1),
        )
    }

    /** 当前**桌宠**尺寸（未挂载时给一个不变量化的兜底值）。 */
    fun petSize(): OverlaySize {
        val rect = petWindowRect()
        if (rect.isUsable) return OverlaySize(rect.width, rect.height)
        return OverlaySize.fallback
    }

    /** 当前**桌宠**左上角像素（诊断 / 位置持久化 / 吸附判定都用它）。 */
    fun currentTopLeft(): IntArray {
        val rect = petWindowRect()
        return intArrayOf(rect.left, rect.top)
    }

    /** 当前可用区域（诊断）。 */
    fun currentBounds(): OverlayBounds = bounds

    /** 当前可见状态名（`asset`/`loading`/`failure`/`empty`/`debug`；未挂载时 `absent`）。 */
    fun currentVisual(): String = view?.visual?.name ?: "absent"

    fun postAfterLayout(block: () -> Unit) {
        view?.post { block() } ?: OverlayLog.warn("postAfterLayout 被忽略：窗口未挂载")
    }

    /** 一行式窗口诊断（日志用）。 */
    fun dump(): String {
        val v = view
        val p = params
        val topLeft = currentTopLeft()
        return buildString {
            append("attached=").append(isAttached)
            append(" attachedToWindow=").append(isAttachedToWindow)
            append(" visible=").append(isVisible)
            append(" lp=")
            if (p == null) {
                append("null")
            } else {
                append(p.width).append('x').append(p.height)
                append(" x=").append(p.x).append(" y=").append(p.y)
                append(" type=").append(p.type)
                append(" flags=").append(p.flags)
                append(" format=").append(p.format)
                append(" gravity=").append(p.gravity)
                append(" alpha=").append(p.alpha)
            }
            append(" bounds=").append(bounds.left).append(',').append(bounds.top)
                .append('-').append(bounds.right).append(',').append(bounds.bottom)
            append(" size=").append(petSize().width).append('x').append(petSize().height)
            append(" topLeft=").append(topLeft[0]).append(',').append(topLeft[1])
            append(" gesture=").append(gestureStateName)
            append(" menu=").append(menuState.name)
            append(" menuWindow=")
            append(menuParams?.let { "(${it.x},${it.y} ${it.width}x${it.height})" } ?: "none")
            append(" menuLevel=").append(menuLevelName)
            append(" menuItems=").append(menuButtonCount)
            append(" menuActive=").append(menuActiveIndex)
            append(" menuAnim=").append(menuAnimationName)
            append(" petRectBeforeMenu=").append(petRectBeforeMenu ?: "none")
            append(" screen=").append(screenSize()[0]).append('x').append(screenSize()[1])
            append(" density=").append(context.resources.displayMetrics.density)
            append(" thread=").append(Thread.currentThread().name)
            append(" mainThread=").append(Looper.myLooper() == Looper.getMainLooper())
            append(" view[").append(v?.dump() ?: "null").append(']')
            append(" lastAction=").append(lastWindowAction)
            append(" lastError=").append(lastWindowError ?: "<none>")
        }
    }

    // -----------------------------------------------------------------------
    // 挂载 / 卸载
    // -----------------------------------------------------------------------

    /**
     * 挂载窗口；**幂等**。返回是否为本次新建。
     *
     * 已挂载时只把新的缩放/标志/占位文字应用上去，绝不 addView 第二次。
     */
    fun attach(store: PetOverlayStore): Boolean {
        val existing = view
        if (existing != null) {
            applySettings(store)
            OverlayLog.log("addView 跳过：已有唯一窗口（幂等）")
            return false
        }

        requireMainThread("addView")
        cancelSnapAnimation(applyTarget = false)

        snapEnabled = store.snapEnabled
        debugMode = store.debugOverlayMode
        touchThrough = store.touchThrough
        menuTheme = store.menuTheme()
        menuHapticsEnabled = store.menuHapticsEnabled
        menuSettings = store.menuLayoutSettings()
        menuButtonScale = menuSettings.buttonVisualScale
        // 每次 attach 都重新解析可用区域：旋转/分屏后一定是新的值。
        bounds = resolveBounds()

        val density = context.resources.displayMetrics.density
        val size = computeSize(store, density)
        val topLeft = computeTopLeft(store, size)

        val created = PetOverlayView(context).apply {
            setDebugMode(debugMode)
            // 桌宠内容铺满自己的窗口（菜单在独立窗口里，因此没有相对偏移）。
            prepareWindowGeometry(size)
            // 触摸交给手势状态机（在 manager 里，每个窗口一个）。
            touchHandler = { event -> handleTouch(event) }
        }
        // 每个新窗口都从"菜单关闭 + 干净状态"开始（4C-3A 的手势机同理）。
        disposed = false
        menuState = OverlayMenuState.closed
        activeLayout = null
        envelope = null
        petRectBeforeMenu = null
        // 防御性：万一有残留的菜单窗口（异常路径），先清掉 —— 保证"每种窗口最多一个"。
        removeMenuWindow("attach-reset")
        wheelSpec = WheelMenuSpec.fromDensity(density)
        gesture = OverlayGestureMachine(
            touchSlopPx = ViewConfiguration.get(context).scaledTouchSlop,
        )
        // 显式尺寸，**不依赖 WRAP_CONTENT**：空 ImageView 的 WRAP_CONTENT 会算出 0×0。
        val layoutParams = WindowManager.LayoutParams(
            size.width,
            size.height,
            OverlayWindowSpec.petWindowType(Build.VERSION.SDK_INT),
            OverlayWindowSpec.windowFlags(store.touchThrough),
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = topLeft[0]
            y = topLeft[1]
            alpha = 1f
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        lastWindowAction = "addView(start) thread=${Thread.currentThread().name}"
        // addView 可能在极端情况下失败（例如系统在授权撤销的瞬间拒绝），
        // 此时必须保持"未挂载"，让调用方给出明确提示，而不是留下半残状态。
        try {
            windowManager.addView(created, layoutParams)
        } catch (t: Throwable) {
            view = null
            params = null
            gesture = null
            lastWindowError = "addView 失败：${t.message}"
            lastWindowAction = "addView(failed)"
            OverlayLog.error(lastWindowError ?: "addView 失败", t)
            throw t
        }

        view = created
        params = layoutParams
        lastWindowError = null
        lastWindowAction = "addView(ok)"
        OverlayLog.log(
            "addView ok debug=$debugMode aspect=${created.drawableAspectRatio} " +
                "topLeft(${topLeft[0]},${topLeft[1]}) ${dump()}",
        )
        OverlayLog.log(
            "position.restore xRatio=${store.xRatio} yRatio=${store.yRatio} " +
                "snapEnabled=$snapEnabled edge=${store.snapEdge} " +
                "x=${topLeft[0]} y=${topLeft[1]} bounds=${bounds.width}x${bounds.height} " +
                "size=${size.width}x${size.height}",
        )
        // 布局完成后再把**真实**尺寸/附着状态记一次：这是"看不见"最直接的证据。
        created.post {
            OverlayLog.log("addView settled(post) ${dump()}")
        }
        return true
    }

    /** 移动 / 缩放 / 旋转后**重新套用**全部几何与标志。 */
    fun applySettings(store: PetOverlayStore) {
        val currentView = view ?: return
        val currentParams = params ?: return

        requireMainThread("updateViewLayout")
        // 尺寸/位置即将重算：进行中的贴边动画必须停掉，否则会与新的坐标打架。
        cancelSnapAnimation(applyTarget = false)
        // 先记下"变化前"的桌宠几何（必须在 resetMenu 之前取，否则会拿到菜单窗口尺寸）。
        val previousSize = petSize()
        val previousTopLeft = currentTopLeft()
        // 几何即将变化（旋转/分屏/改大小/换素材）→ 菜单必须先收敛到 closed，
        // 否则会残留一个按旧桌面几何算出来的扩展窗口。
        resetMenuForGeometryChange("applySettings")

        debugMode = store.debugOverlayMode
        snapEnabled = store.snapEnabled
        touchThrough = store.touchThrough
        bounds = resolveBounds()

        val density = context.resources.displayMetrics.density
        wheelSpec = WheelMenuSpec.fromDensity(density)
        menuTheme = store.menuTheme()
        menuHapticsEnabled = store.menuHapticsEnabled
        menuSettings = store.menuLayoutSettings()
        menuButtonScale = menuSettings.buttonVisualScale
        val size = computeSize(store, density)
        val topLeft = computeTopLeft(store, size)

        currentView.setDebugMode(debugMode)
        currentParams.flags = OverlayWindowSpec.windowFlags(store.touchThrough)
        currentParams.format = PixelFormat.TRANSLUCENT
        currentParams.alpha = 1f

        // **原子**提交桌宠窗口：参数一次准备完，只触发一次 updateViewLayout。
        // 这是"桌宠本来就该移动"的场景（旋转 / 改大小）。
        val committed = applyPetWindowGeometry(
            left = topLeft[0],
            top = topLeft[1],
            size = size,
            tag = "updateViewLayout",
        )
        if (!committed) {
            // 提交被拒绝的原因必须区分清楚，**绝不能**把"刚创建、还没走完
            // onAttachedToWindow 的窗口"当失效窗口清理掉（那会造成
            // "服务在运行但窗口未成功添加"，4C-3B 复验缺陷 A）：
            // * 守卫拒绝（窗口未附着）→ 只是跳过本次几何提交，窗口本身是好的；
            // * addView/updateViewLayout 真抛异常且窗口确实已不在 WindowManager 上 → 才清理引用。
            if (lastWindowError != null && !currentView.isAttachedToWindow) {
                OverlayLog.warn("窗口确实已不在 WindowManager 上（$lastWindowError），清理引用")
                detach("update-failed-detached")
            } else {
                OverlayLog.warn("本次几何提交被跳过（窗口尚未附着），窗口保持不动：${dump()}")
            }
            return
        }
        currentView.invalidate()
        OverlayLog.log("updateViewLayout ok ${dump()}")
        if (previousSize != size) {
            OverlayLog.log(
                "size.update from=${previousSize.width}x${previousSize.height} " +
                    "to=${size.width}x${size.height} scale=${store.scale} " +
                    "aspect=${currentView.drawableAspectRatio}",
            )
        }
        if (previousTopLeft[0] != topLeft[0] || previousTopLeft[1] != topLeft[1]) {
            OverlayLog.log(
                "position.clamp from=(${previousTopLeft[0]},${previousTopLeft[1]}) " +
                    "to=(${topLeft[0]},${topLeft[1]}) edge=${store.snapEdge} " +
                    "bounds=${bounds.width}x${bounds.height}",
            )
        }
    }

    /** 切换诊断模式（保存到 store 后调用）。 */
    fun setDebugMode(enabled: Boolean) {
        val currentView = view ?: return
        debugMode = enabled
        currentView.setDebugMode(enabled)
        currentView.requestLayout()
        currentView.invalidate()
        OverlayLog.log("setDebugMode $enabled ${dump()}")
    }

    /**
     * 挂上**静态**视觉（PNG / JPG / 静态 WebP / 低版本第一帧回退）。
     */
    fun showStatic(drawable: Drawable) {
        view?.showStatic(drawable)
        OverlayLog.log("visual.apply.static ${dump()}")
    }

    /** 挂上**动态**视觉（动态 WebP）。 */
    fun showAnimated(drawable: Drawable) {
        view?.showAnimated(drawable)
        OverlayLog.log("visual.apply.animated ${dump()}")
    }

    /** 解码失败：清旧视觉 + 显示错误占位（窗口绝不消失）。 */
    fun showErrorPlaceholder(message: String?) {
        view?.showErrorPlaceholder(message)
        // 任务约束：素材加载失败 → 人物已不可见，把菜单关掉。
        closeMenuForVisualLoss("placeholder")
        OverlayLog.log("visual.apply.placeholder ${dump()}")
    }

    /**
     * 清空视觉（隐藏 / 停止时用）：停动画 → 摘 Drawable → 空占位。
     *
     * 必须在 `removeView` **之前**调用：先把 Drawable 从 ImageView 上摘掉，
     * 再让加载器释放引用（需求第 12 节）。
     */
    fun clearVisual(reason: String) {
        OverlayLog.log("visual.clear reason=$reason running=$isAnimationRunning")
        view?.clearVisual()
        // 任务约束：人物已不可见 → 把菜单关掉（透明洞里不再是人物）。
        closeMenuForVisualLoss(reason)
    }

    /**
     * 人物不再可见（加载失败 / 被清空）时关闭菜单（任务约束）。
     *
     * 菜单窗口只在人物区域**打透明洞**：一旦人物消失，洞里只剩占位文案/空白，
     * 菜单继续开着没有意义 —— 因此强制关闭。
     * 只动菜单状态，**不碰**窗口生命周期 / 尺寸范围 / 触摸逻辑。
     */
    private fun closeMenuForVisualLoss(reason: String) {
        if (menuState == OverlayMenuState.closed) return
        if (canRenderMenuForeground()) return
        lastMenuOpenError = "pet-not-visible-or-asset-missing"
        OverlayLog.warn("menu.close：人物不再可见（reason=$reason）→ 强制关闭菜单")
        closeMenu("visual-lost:$reason", animate = false)
    }

    /** 当前动画是否在跑（诊断）。 */
    val isAnimationRunning: Boolean get() = view?.isAnimationRunning == true

    /** 当前视觉是否为"可播放动画"。 */
    val isAnimatableVisual: Boolean get() = view?.isAnimatableVisual == true

    /**
     * 统一的动画播放同步（需求第 10/11 节）。
     *
     * 幂等：已经在跑就不再 start，已经停了就不再 stop；播放/暂停都记一条日志。
     */
    fun syncAnimation(shouldPlay: Boolean, reason: String) {
        val currentView = view ?: return
        if (shouldPlay) {
            if (currentView.isAnimationRunning) return
            currentView.startAnimationIfAllowed()
            if (currentView.isAnimationRunning) {
                OverlayLog.log("animation.start reason=$reason ${dump()}")
            }
        } else {
            if (!currentView.isAnimationRunning) return
            currentView.stopAnimation()
            OverlayLog.log("animation.stop reason=$reason ${dump()}")
        }
    }

    /**
     * 按"有没有图 / 是否在加载 / 最近一次错误"刷新可见状态。
     *
     * 关键点：**有图时永远显示图**（失败也不换成占位），
     * 没图时一定显示**可见的**占位底 —— 绝不留下全透明或 0×0 的窗口。
     */
    fun refreshVisual(loading: Boolean, lastError: String?) {
        val currentView = view ?: return
        currentView.refreshVisual(loading = loading, lastError = lastError)
        OverlayLog.log("refreshVisual loading=$loading ${dump()}")
    }

    fun setAnimationPaused(paused: Boolean) {
        view?.setAnimationPaused(paused)
    }

    /** 动态素材"仅第一帧"角标。 */
    fun setAnimatedBadgeVisible(visible: Boolean) {
        view?.setAnimatedBadgeVisible(visible)
    }

    /**
     * 当前窗口**长边**像素 —— 解码采样率以它为"目标尺寸"。
     *
     * 用长边而不是宽或高：素材宽高比不同，窗口宽高也不同，
     * 只有长边能保证"既不全尺寸解码、也不糊掉"。
     * 窗口未挂载时返回 0（调用方跳过加载）。
     */
    fun currentViewSizePx(): Int = params?.let { maxOf(it.width, it.height) } ?: 0

    /**
     * 移除窗口；**幂等**（重复调用不抛异常）。
     *
     * [reason] 会进日志，便于追"谁把它摘掉的"。
     * [suspendGesture] 用于把状态机明确推到 HIDDEN/STOPPED（诊断用）。
     */
    fun detach(
        reason: String = "unspecified",
        suspendGesture: OverlayGestureState? = null,
    ) {
        // 先取消动画：窗口都要没了，任何后续动画帧都不允许再 updateWindowLayout。
        cancelSnapAnimation(applyTarget = false)
        // 菜单窗口同理：取消动画 + 清按钮 + 移除独立菜单窗口。
        resetMenuForGeometryChange("detach:$reason")
        disposed = true
        val currentView = view ?: run {
            suspendGesture?.let { gesture?.suspend(it) }
            return
        }
        OverlayLog.log("removeView reason=$reason ${dump()}")
        // 先清引用再移除：即使 removeView 抛异常也不会留下悬空引用。
        view = null
        params = null
        lastWindowAction = "removeView($reason)"
        suspendGesture?.let { gesture?.suspend(it) }
        try {
            windowManager.removeView(currentView)
        } catch (t: Throwable) {
            OverlayLog.warn("removeView 失败（通常表示窗口已被系统移除）", t)
        }
    }

    /** 兼容旧调用（不带原因）。 */
    fun detach() = detach("unspecified")

    // -----------------------------------------------------------------------
    // 手势（Phase 4C-3A）
    // -----------------------------------------------------------------------

    /**
     * 触摸入口（由 [PetOverlayView] 转发）。
     *
     * 全程**不写盘**：只有松手（或贴边动画结束）才通过 [OverlayWindowHost.onPersistPosition] 存一次。
     */
    private fun handleTouch(event: MotionEvent): Boolean {
        val machine = gesture ?: return false
        if (touchThrough) return false

        val pointerCount = event.pointerCount
        val x = event.rawX
        val y = event.rawY
        val time = event.eventTime
        // 先把本次触摸坐标记下来：press 分支要用它当拖动起点。
        lastTouchX = x
        lastTouchY = y
        // 每次触摸都刷新"窗口是否可更新"：未附着时状态机会拒绝进入拖动。
        machine.windowUpdatable = view?.isAttachedToWindow == true

        val action = event.actionMasked

        val effect = when (action) {
            MotionEvent.ACTION_DOWN -> machine.onDown(x, y, time, pointerCount)
            MotionEvent.ACTION_MOVE -> machine.onMove(x, y, time, pointerCount)
            MotionEvent.ACTION_POINTER_DOWN -> machine.onDown(x, y, time, 2)
            MotionEvent.ACTION_POINTER_UP -> machine.onUp(x, y, time, 2)
            MotionEvent.ACTION_UP -> machine.onUp(x, y, time, pointerCount)
            MotionEvent.ACTION_CANCEL -> machine.onCancel()
            else -> OverlayGestureEffect.none
        }
        applyGestureEffect(effect)
        return effect != OverlayGestureEffect.none || machine.state != OverlayGestureState.IDLE
    }

    private fun applyGestureEffect(effect: OverlayGestureEffect) {
        when (effect) {
            OverlayGestureEffect.none -> Unit

            OverlayGestureEffect.press -> {
                // 新的手势开始：正在跑的贴边动画立即定格到目标位（确定状态）。
                cancelSnapAnimation(applyTarget = true)
                // 注意：**不在 press 记录窗口原点** —— 如果此刻菜单开着，
                // 窗口原点是"菜单窗口"的左上角，不是桌宠的。原点统一在 dragStart 记录
                // （那时菜单已经关掉、窗口已经缩回桌宠矩形）。
                pressRawX = lastTouchX
                pressRawY = lastTouchY
                OverlayLog.log(
                    "gesture.down x=${pressRawX.toInt()} y=${pressRawY.toInt()} " +
                        "menuState=${menuState.name} slop=${touchSlopPx()}",
                )
            }

            OverlayGestureEffect.dragStart -> {
                // 需求 3.3：菜单打开时开始拖动 → **先关菜单**（立即缩回窗口），再进入拖动。
                if (isMenuOpen) {
                    OverlayLog.log("gesture.drag.start 检测到菜单打开 → 先关闭菜单再拖动")
                    closeMenu("drag-start", animate = false)
                }
                val p = params
                dragOriginX = p?.x ?: 0
                dragOriginY = p?.y ?: 0
                OverlayLog.log(
                    "gesture.drag.start origin=($dragOriginX,$dragOriginY) slop=${touchSlopPx()}",
                )
            }

            OverlayGestureEffect.drag -> dragTo(lastTouchX, lastTouchY)

            OverlayGestureEffect.dragEnd -> {
                OverlayLog.log("gesture.drag.end ${positionSummary()}")
                finishDrag()
            }

            OverlayGestureEffect.click -> {
                OverlayLog.log("gesture.click ${positionSummary()}")
                // 4C-3B：单击 = 开关圆盘菜单（开着就关、关着就开）。
                toggleMenu(reason = "gesture-click")
                host.onClickPet()
            }

            OverlayGestureEffect.cancel -> {
                // 手势被取消（ACTION_CANCEL / 多指介入）：窗口可能已经被拖动过，
                // 因此要把"当前可见位置"落一次盘，避免下次恢复跳回更早的存档。
                OverlayLog.log("gesture.cancel ${positionSummary()}")
                persistCurrentPosition(edge = null)
            }
        }
    }

    /** 拖动中：只 updateViewLayout，绝不写盘、绝不 addView/removeView。 */
    private fun dragTo(rawX: Float, rawY: Float) {
        val p = params ?: return
        val current = view ?: return
        // 需求"三、第 7/8 条"：View 未附着时不得执行 updateViewLayout。
        if (!current.isAttachedToWindow) {
            OverlayLog.warn("拖动忽略：窗口未附着（isAttachedToWindow=false）")
            return
        }
        val size = petSize()
        val target = OverlayPositionCalculator.clampTopLeft(
            x = dragOriginX + (rawX - pressRawX).toInt(),
            y = dragOriginY + (rawY - pressRawY).toInt(),
            bounds = bounds,
            petWidth = size.width,
            petHeight = size.height,
        )
        if (p.x == target[0] && p.y == target[1]) return
        p.x = target[0]
        p.y = target[1]
        try {
            windowManager.updateViewLayout(current, p)
            lastWindowAction = "updateViewLayout(drag)"
            // MOVE 是高频事件：只在明确开启诊断模式时才逐帧打日志（需求"十、日志与诊断"）。
            if (debugMode) {
                OverlayLog.log("gesture.drag.move x=${p.x} y=${p.y}")
            }
        } catch (t: Throwable) {
            lastWindowError = "拖动 updateViewLayout 失败：${t.message}"
            lastWindowAction = "updateViewLayout(drag-failed)"
            OverlayLog.warn(lastWindowError ?: "拖动失败", t)
        }
    }

    /** 松手：先贴边（可选），再持久化。 */
    private fun finishDrag() {
        val p = params ?: return
        val size = petSize()
        val edge = if (snapEnabled) {
            OverlayPositionCalculator.snapEdgeFor(
                centerX = OverlayPositionCalculator.centerX(p.x, size.width),
                bounds = bounds,
            )
        } else {
            OverlaySnapEdge.none
        }

        if (edge == OverlaySnapEdge.none) {
            val clamped = OverlayPositionCalculator.clampTopLeft(p.x, p.y, bounds, size.width, size.height)
            if (clamped[0] != p.x || clamped[1] != p.y) {
                OverlayLog.log("position.clamp 松手修正 x=${p.x}->${clamped[0]} y=${p.y}->${clamped[1]}")
                p.x = clamped[0]
                p.y = clamped[1]
                safeUpdateViewLayout("snap-none-clamp")
            }
            persistCurrentPosition(edge = OverlaySnapEdge.none)
            return
        }

        val targetX = OverlayPositionCalculator.snapTargetX(edge, bounds, size.width)
        val targetY = p.y.coerceIn(
            bounds.top,
            (bounds.top + (bounds.height - size.height).coerceAtLeast(0)),
        )
        if (targetX == p.x && targetY == p.y) {
            persistCurrentPosition(edge = edge)
            return
        }
        OverlayLog.log("snap.start edge=${edge.labelZh} from=(${p.x},${p.y}) to=($targetX,$targetY)")
        startSnapAnimation(targetX, targetY, edge)
    }

    /** 贴边动画（150~250ms）；动画期间**不写盘**，结束后统一持久化。 */
    private fun startSnapAnimation(targetX: Int, targetY: Int, edge: OverlaySnapEdge) {
        val startX = params?.x ?: return
        val startY = params?.y ?: return
        cancelSnapAnimation(applyTarget = false)
        val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = OverlayGeometry.SNAP_ANIMATION_MS
            interpolator = DecelerateInterpolator()
            addUpdateListener { animation ->
                val fraction = animation.animatedValue as Float
                val p = params ?: return@addUpdateListener
                val v = view ?: return@addUpdateListener
                if (!v.isAttachedToWindow) return@addUpdateListener
                p.x = (startX + (targetX - startX) * fraction).toInt()
                p.y = (startY + (targetY - startY) * fraction).toInt()
                try {
                    windowManager.updateViewLayout(v, p)
                    lastWindowAction = "updateViewLayout(snap)"
                } catch (t: Throwable) {
                    OverlayLog.warn("贴边动画 updateViewLayout 失败", t)
                }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (snapAnimator !== animation) return
                    snapAnimator = null
                    val p = params ?: return
                    p.x = targetX
                    p.y = targetY
                    safeUpdateViewLayout("snap-end")
                    OverlayLog.log("snap.end edge=${edge.labelZh} x=$targetX y=$targetY")
                    persistCurrentPosition(edge = edge)
                }
            })
        }
        snapTargetEdge = edge
        snapTargetX = targetX
        snapTargetY = targetY
        snapAnimator = animator
        animator.start()
    }

    /**
     * 取消贴边动画。
     *
     * @param applyTarget true = 立刻落到目标位（"动画被取消时恢复确定状态"）；
     *   false = 停在当前帧（窗口即将移除 / 即将重算几何，落点无意义）。
     */
    private fun cancelSnapAnimation(applyTarget: Boolean) {
        val animator = snapAnimator ?: return
        snapAnimator = null
        val fraction = animator.animatedFraction
        animator.cancel()
        if (!applyTarget) {
            OverlayLog.log("snap.cancel fraction=$fraction（保持当前帧）")
            return
        }
        // 动画被打断：按"确定状态"处理 —— 立刻落到本次动画的目标位再持久化，
        // 避免"屏幕停在中间帧、存储写在目标位"，也避免把吸附边误写成 none。
        OverlayLog.log("snap.cancel fraction=$fraction（落到确定状态）")
        params?.let {
            it.x = snapTargetX
            it.y = snapTargetY
        }
        safeUpdateViewLayout("snap-cancel")
        persistCurrentPosition(edge = snapTargetEdge)
        snapTargetEdge = OverlaySnapEdge.none
    }

    private fun safeUpdateViewLayout(tag: String) {
        val p = params ?: return
        val v = view ?: return
        if (!v.isAttachedToWindow) return
        try {
            windowManager.updateViewLayout(v, p)
            lastWindowAction = "updateViewLayout($tag)"
        } catch (t: Throwable) {
            lastWindowError = "updateViewLayout($tag) 失败：${t.message}"
            OverlayLog.warn(lastWindowError ?: "updateViewLayout 失败", t)
        }
    }

    /**
     * 按**当前可见的 LP 坐标**持久化（相对比例 + 吸附边）。
     *
     * [edge] 为 null 表示"**按当前位置重新推断**吸附边"（不是在清除吸附）。
     * 之所以要区分：动画被打断、手势被取消时位置已经变了，此时若把边写成 `none`，
     * 下一次"改大小"就会按比例外扩而不是继续贴边（需求 2.5 明确禁止）。
     */
    private fun persistCurrentPosition(edge: OverlaySnapEdge?) {
        val p = params ?: return
        val size = petSize()
        if (!bounds.isUsable) {
            OverlayLog.warn("position.persist 跳过：可用区域不可信 bounds=${bounds.width}x${bounds.height}")
            return
        }
        val ratios = OverlayPositionCalculator.ratioFromTopLeft(
            x = p.x,
            y = p.y,
            bounds = bounds,
            petWidth = size.width,
            petHeight = size.height,
        )
        val resolvedEdge = edge ?: if (snapEnabled) {
            OverlayPositionCalculator.snapEdgeFor(
                centerX = OverlayPositionCalculator.centerX(p.x, size.width),
                bounds = bounds,
            )
        } else {
            OverlaySnapEdge.none
        }
        OverlayLog.log(
            "position.persist xRatio=${ratios[0]} yRatio=${ratios[1]} edge=${resolvedEdge.labelZh} " +
                "x=${p.x} y=${p.y} bounds=${bounds.width}x${bounds.height} " +
                "size=${size.width}x${size.height} orientation=${orientationName()}",
        )
        host.onPersistPosition(ratios[0], ratios[1], resolvedEdge)
    }

    private fun positionSummary(): String {
        val p = params ?: return "position=<none>"
        val size = petSize()
        return "x=${p.x} y=${p.y} size=${size.width}x${size.height} " +
            "bounds=${bounds.width}x${bounds.height} edge=${snapEdgeLabel()}"
    }

    private fun snapEdgeLabel(): String =
        OverlayPositionCalculator
            .snapEdgeFor(OverlayPositionCalculator.centerX(currentTopLeft()[0], petSize().width), bounds)
            .labelZh

    private fun touchSlopPx(): Int = ViewConfiguration.get(context).scaledTouchSlop

    /** 最近一次触摸的屏幕坐标（press 记录起点时要用）。 */
    private var lastTouchX: Float = 0f
    private var lastTouchY: Float = 0f

    // -----------------------------------------------------------------------
    // P3P 风格分层轮盘（Phase 4C-6B-1）
    //
    // 窗口几何：**展开一次、关闭一次**（需求 §14）；内部动画每帧只重绘 Canvas。
    // -----------------------------------------------------------------------

    /** 单击桌宠：开着就关、关着就开（唯一入口）。 */
    fun toggleMenu(reason: String) {
        if (reason.startsWith("gesture-click")) {
            petTapReceived = true
        }
        val next = OverlayMenuStateMachine.next(menuState, OverlayMenuEvent.requestToggle)
        OverlayLog.log(
            "menu.request.toggle reason=$reason menuState=${menuState.name} -> ${next.name} " +
                "gesture=$gestureStateName",
        )
        transitionMenu(OverlayMenuEvent.requestToggle, reason)
    }

    /**
     * 关闭菜单。
     *
     * @param animate false = 立即（隐藏/停止/权限撤销/几何变化：这是**清理**，不是交互）
     */
    fun closeMenu(reason: String, animate: Boolean) {
        if (menuState == OverlayMenuState.closed) {
            OverlayLog.log("menu.request.close 幂等（菜单本来就关着）reason=$reason")
            return
        }
        if (!animate) {
            OverlayLog.log("menu.request.close reason=$reason immediate=true")
            transitionMenu(OverlayMenuEvent.forceClose, reason)
            return
        }
        OverlayLog.log("menu.request.close reason=$reason immediate=false")
        transitionMenu(OverlayMenuEvent.requestClose, reason)
    }

    /** 设置页改动主题后立即下发（需求 §13.3：立即预览，不重开菜单）。 */
    fun applyMenuTheme(theme: WheelMenuTheme, reason: String) {
        menuTheme = theme
        menuView?.applyTheme(theme)
        OverlayLog.log("menu.theme.apply id=${theme.themeId} reason=$reason")
    }

    /**
     * 设置页改动**轮盘布局**（尺寸 / 紧凑）后立即生效（Phase 4C-6B-1.1，需求 §5 / §12）。
     *
     * 几何变了就**必须**重算窗口（与主题只换颜色不同），而"菜单打开期间窗口不变"
     * 是 4C-6B-1 的硬约束 —— 因此这里的口径是：
     * * 菜单**关着**：直接保存，下次打开用新尺寸；
     * * 菜单**开着**：立即收起菜单（不重开、不闪），下次点击桌宠即用新尺寸。
     *
     * 需求 §12 建议的"打开期间 180~220ms 几何插值"**本阶段未实现**（见文档 §12.14.12）。
     */
    fun applyMenuLayoutSettings(settings: WheelMenuLayoutSettings, reason: String) {
        val previous = menuSettings
        menuSettings = settings.normalized()
        menuButtonScale = menuSettings.buttonVisualScale
        // 按钮大小只通过 menuSettings 生效（spec 里不再存第二份，避免"设置了不生效"）。
        wheelSpec = WheelMenuSpec.fromDensity(context.resources.displayMetrics.density)
        OverlayLog.log(
            "wheel_layout_settings_updated scale=${previous.preferredScale}→" +
                "${menuSettings.preferredScale} button=${previous.buttonVisualScale}→" +
                "${menuSettings.buttonVisualScale} compact=${menuSettings.compactMode} reason=$reason",
        )
        if (isMenuOpen) {
            closeMenu("layout-settings-changed", animate = false)
        }
    }

    /**
     * 轮盘条目被确认（点击或滑选松手）。
     *
     * **这里是"菜单"与"业务"的唯一交界**：
     * 导航类（进入子菜单 / 返回 / 关闭）真实执行；
     * 其余一律交给 [WheelMenuActionDispatcher] 发结构化占位事件 —— 4C-6B-1 不复制业务逻辑。
     */
    private fun onWheelEntryConfirmed(entry: WheelMenuEntry, index: Int) {
        val outcome = actions.dispatch(entry.action, entry.id, entry)
        OverlayLog.log(
            "menu.action id=${entry.id} wire=${entry.action.wire} route=${outcome.route.name} " +
                "handled=${outcome.handled} level=$menuLevelName index=$index",
        )
        when (actions.targetLevelOf(entry.action)) {
            null -> when (entry.action) {
                WheelMenuAction.closeMenu -> closeMenu("wheel-action", animate = true)
                WheelMenuAction.back -> Unit
                // 非导航项：只把高亮与扇区平滑移过去（需求 §10.2），不改窗口、不关闭菜单。
                else -> menuView?.animateSelectionTo(index)
            }
            else -> enterLayer(entry.action, "wheel-entry:${entry.id}")
        }
    }

    /** 进入子菜单（唯一入口）。 */
    private fun enterLayer(action: WheelMenuAction, reason: String) {
        val target = actions.targetLevelOf(action) ?: return
        val level = WheelMenuCatalog.level(target) ?: return
        val view = menuView ?: return
        if (!view.enterLayer(level)) {
            OverlayLog.warn("menu.enterLayer 被拒绝 level=$target reason=$reason")
            return
        }
        activeLayout = view.currentLayout()
        OverlayLog.log(
            "menu.layer.enter level=$target items=${level.itemCount} " +
                "window=${envelope?.windowRect}（窗口未改动）reason=$reason",
        )
    }

    // ------------------------------------------------------------------
    // 轮盘动作宿主（WheelMenuActionHost）
    // ------------------------------------------------------------------

    /**
     * 导航类动作。
     *
     * 只有 [WheelMenuAction.back] 与 [WheelMenuAction.closeMenu] 需要在这里即时处理；
     * "进入子菜单"由 [onWheelEntryConfirmed] 的 `when` 分支完成（它需要知道被点的条目索引）。
     */
    override fun onNavigateAction(action: WheelMenuAction, entryId: String): Boolean = when (action) {
        WheelMenuAction.back -> {
            exitLayer("nav-back:$entryId")
            true
        }
        WheelMenuAction.closeMenu -> {
            closeMenu("nav-close:$entryId", animate = true)
            true
        }
        else -> false
    }

    /** 业务类：只发结构化占位事件（4C-6B-1 明确不接入真实业务）。 */
    override fun onBusinessAction(action: WheelMenuAction, entryId: String) {
        host.onMenuAction(
            actionWire = action.wire,
            itemId = entryId,
            detail = "该功能将在 4C-6B-2 接入（4C-6B-1 仅完成轮盘框架）",
        )
    }

    /** 只读信息项：把已经缓存的实时信息交给宿主提示，不改任何状态。 */
    override fun onInfoAction(entryId: String, entry: WheelMenuEntry) {
        val info = runCatching { host.onMenuInfo(entryId) }.getOrNull()
        host.onMenuAction(
            actionWire = WheelMenuAction.showInfo.wire,
            itemId = entryId,
            detail = info ?: entry.labelZh,
        )
    }

    /** 返回上一层（唯一入口）。 */
    private fun exitLayer(reason: String) {
        val view = menuView ?: return
        if (!view.state.canGoBack) {
            OverlayLog.log("menu.layer.exit 忽略：已经在根菜单 reason=$reason")
            return
        }
        if (!view.exitLayer()) {
            OverlayLog.warn("menu.layer.exit 被拒绝 reason=$reason")
            return
        }
        activeLayout = view.currentLayout()
        OverlayLog.log(
            "menu.layer.exit level=${view.levelIdName} " +
                "window=${envelope?.windowRect}（窗口未改动）reason=$reason",
        )
    }

    /** 唯一的菜单状态入口：所有转移都经过 [OverlayMenuStateMachine]。 */
    private fun transitionMenu(event: OverlayMenuEvent, reason: String) {
        val next = OverlayMenuStateMachine.next(menuState, event)
        if (next == menuState && event != OverlayMenuEvent.animationFinished) {
            OverlayLog.log("menu.state 幂等：保持 ${menuState.name}（event=${event.name} reason=$reason）")
            return
        }
        OverlayLog.log("menu.state ${menuState.name} -> ${next.name} event=${event.name} reason=$reason")
        when (next) {
            OverlayMenuState.closed -> enterClosed(reason)
            OverlayMenuState.opening -> enterOpening(reason)
            OverlayMenuState.open -> {
                // 只有"展开动画正常结束"会到这里：窗口已经是扩展状态，什么都不用改。
                menuState = OverlayMenuState.open
            }
            OverlayMenuState.closing -> enterClosing(reason)
        }
    }

    /**
     * 打开菜单：算**一次**信封（窗口 + 中心 + 环带半径）+ 根层级布局，
     * 添加菜单窗口，然后交给轮盘自己播展开动画。
     *
     * 桌宠窗口在这里**一个字段都不改** —— 这是"关掉菜单后桌宠不抽动"的结构性保证。
     */
    // --- Phase 4C-6B-1.2 A3：**桌宠隐藏机制彻底删除** ---
    //
    // 规则固定为：**原桌宠窗口永远自己绘制自己**，菜单窗口只在人物区域打透明洞。
    // 曾经的"菜单前景副本 + 隐藏原桌宠 + 前景首帧回调切换视觉所有权"已全部删除 ——
    // 两次真机都出现"打开菜单后桌宠消失"，根因是这条切换链任何一环失败都会导致两个窗口都不画人物。
    // 现在结构上不可能再发生：`PetOverlayView` 已**不存在**任何可隐藏内容的入口。

    /** 桌宠当前是否**能真实显示素材**（仅 `asset` 状态）—— 不能则拒绝打开菜单。 */
    private fun canRenderMenuForeground(): Boolean = view?.visual == OverlayVisual.asset

    /**
     * 强制保证原桌宠可见（所有生命周期/异常路径都收敛到这里）。
     *
     * 正常路径**不写日志**（需求 §20：稳定状态禁止重复刷 INFO）；
     * 只有真的发生"内容被外部改暗"这种不应出现的情况才记一条 ERROR。
     */
    private fun enforcePetAlwaysVisible(reason: String) {
        val corrected = view?.ensureSourceVisible() == true
        if (corrected) {
            OverlayLog.error(
                "检测到桌宠内容被改写（不应发生）reason=$reason → 已强制恢复 " +
                    PetVisualInvariant.diagnosticSegment().trim(),
            )
        }
    }

    /**
     * 打开菜单：算**一次**信封 + 根层级布局，添加菜单窗口，然后交给轮盘自己播展开动画。
     *
     * 桌宠窗口在这里**一个字段都不改** —— 这是"关掉菜单后桌宠不抽动"的结构性保证。
     */
    private fun enterOpening(reason: String) {
        menuOpenRequested = true
        // 任务约束：人物不可见或素材未就绪（在加载/失败/空/诊断）时**拒绝打开菜单**。
        if (!canRenderMenuForeground()) {
            lastMenuOpenError = "pet-not-visible-or-asset-missing"
            OverlayLog.warn(
                "menu.open 被拒绝：人物当前不可见或素材未就绪 visual=${currentVisual()} reason=$reason",
            )
            menuState = OverlayMenuState.closed
            return
        }
        if (!canTouchWindow()) {
            lastMenuOpenError = "pet-window-not-attached"
            OverlayLog.warn("menu.open 被拒绝：桌宠窗口未附着 reason=$reason")
            menuState = OverlayMenuState.closed
            return
        }
        val petRect = petWindowRect()
        val rootLevel = WheelMenuCatalog.ROOT
        val resolved = try {
            // 按**最大条目数**（"设置"的 9 项）+ 用户设定尺寸算信封：打开期间窗口恒定（需求 §14）。
            val env = WheelMenuGeometry.computeEnvelope(
                bounds = bounds,
                petWindowRect = petRect,
                content = petContentBounds,
                maxItemCount = WheelMenuCatalog.maxItems,
                spec = wheelSpec,
                settings = menuSettings,
                previousDirection = lastDirection,
                previousVerticalMode = lastVerticalMode,
                lockMode = false,
            )
            env to WheelMenuGeometry.layoutFor(env, rootLevel, wheelSpec)
        } catch (t: Throwable) {
            OverlayLog.error("轮盘几何计算异常（菜单不打开）", t)
            null
        }
        if (resolved == null) {
            lastMenuOpenError = "geometry-unavailable"
            OverlayLog.warn("menu.open 被拒绝：无法计算轮盘几何 reason=$reason")
            menuState = OverlayMenuState.closed
            return
        }
        val (env, layout) = resolved

        petRectBeforeMenu = petRect
        envelope = env
        activeLayout = layout
        lastDirection = env.direction
        lastVerticalMode = env.verticalMode

        // 只添加**独立菜单窗口**：桌宠窗口的 LayoutParams 一个字段都不改。
        if (!addMenuWindow(env, layout, petRect)) {
            envelope = null
            activeLayout = null
            menuState = OverlayMenuState.closed
            return
        }
        OverlayLog.log(
            "menu.open dir=${env.direction.labelZh} vmode=${env.verticalMode.labelZh} " +
                "items=${layout.itemCount} scale=${env.preferredScale}→${env.actualScale} " +
                "compact=${env.compact} radius=${layout.ringRadiusPx.toInt()} " +
                "blade=${layout.bladeLengthPx.toInt()} degraded=${env.degraded}" +
                "${env.fallbackReason?.let { " reason=$it" } ?: ""} anchorDist=${env.anchorDistancePx.toInt()} reason=$reason",
        )
        OverlayLog.log(
            "wheel_layout_computed bounds=${bounds.width}x${bounds.height} petWindow=$petRect " +
                "petAnchor=(${env.petAnchorX},${env.petAnchorY}) hole=(${env.holeRx.toInt()},${env.holeRy.toInt()}) " +
                "wheelWindow=${env.windowRect} petWindowUnchanged=true（双窗口：桌宠窗口不参与菜单开关）",
        )
        menuState = OverlayMenuState.opening
        gesture?.onMenuOpened()
        // 【A2 第二次回归】不再有任何"前景副本 / 隐藏原桌宠"的切换。
        // 人物由原桌宠窗口绘制；菜单窗口只在人物区域**打透明洞**（渲染层 CLEAR）。
        // 这里只做一件事：确保原桌宠是可见的（防御性，正常路径它一直是可见的）。
        enforcePetAlwaysVisible("menu-open")
        OverlayLog.log(
            "menu.open 视觉规则=桌宠窗口自绘+菜单挖洞（owner=PET_WINDOW, foregroundCopy=disabled）",
        )
        menuView?.startOpenAnimation()
        schedulePetPositionSettledDiagnostics("menu.open", petRect)
    }

    private fun enterClosing(reason: String) {
        // 关闭动画结束后才移除菜单窗口（需求：禁止动画未结束就留下错误触摸区域）。
        menuState = OverlayMenuState.closing
        menuView?.startCloseAnimation()
        OverlayLog.log("menu.animation.start close reason=$reason")
    }

    /**
     * 关闭菜单（唯一的收敛点，双窗口方案）。顺序：
     * 1. 定格轮盘动画（收敛到确定状态，绝不卡在中间帧）；
     * 2. **移除菜单窗口**（`removeView`）—— 桌宠窗口的 LayoutParams 一个字段都不改；
     * 3. 状态切到 closed；下一帧核对桌宠位置完全没动。
     */
    private fun enterClosed(reason: String) {
        val wasOpen = menuState.occupiesWindow
        val beforePet = petRectBeforeMenu
        menuView?.freeze()
        removeMenuWindow("closed:$reason")
        envelope = null
        activeLayout = null
        petRectBeforeMenu = null
        menuState = OverlayMenuState.closed
        gesture?.onMenuClosed()
        OverlayLog.log(
            "menu.close reason=$reason wasOpen=$wasOpen menuWindowAttached=$isMenuWindowAttached " +
                "petWindowUntouched=true",
        )
        if (debugMode && wasOpen) {
            OverlayLog.log(menuPerformanceSummary())
        }
        beforePet?.let { schedulePetPositionSettledDiagnostics("menu.close:$reason", it) }
    }

    /**
     * 几何变化（旋转/分屏/改大小/换素材）与 detach：定格动画并**移除菜单窗口**。
     *
     * 桌宠窗口不需要任何"还原"（它从来没被菜单改动过），因此这里只是把额外窗口清掉。
     */
    private fun resetMenuForGeometryChange(reason: String) {
        if (menuState == OverlayMenuState.closed && menuView == null) return
        menuView?.freeze()
        removeMenuWindow("geometry-change:$reason")
        envelope = null
        activeLayout = null
        petRectBeforeMenu = null
        menuState = OverlayMenuState.closed
        gesture?.onMenuClosed()
        OverlayLog.log("menu.configuration_changed reason=$reason（菜单窗口已移除，桌宠窗口未改动）")
    }

    /**
     * 轮盘一次动画播完。
     *
     * 只有**展开**与**收起**需要同步窗口级状态机；选项切换与换层是纯内部动画。
     */
    private fun onWheelAnimationFinished(kind: WheelAnimationKind) {
        OverlayLog.log("menu.animation.end kind=${kind.name} ${menuSummary()}")
        when (kind) {
            WheelAnimationKind.open ->
                transitionMenu(OverlayMenuEvent.animationFinished, "open-animation-end")
            WheelAnimationKind.close ->
                transitionMenu(OverlayMenuEvent.animationFinished, "close-animation-end")
            else -> Unit
        }
    }

    /**
     * 中央桌宠区域的拖动（由 [WheelMenuView] 转发，需求 §3 / §4 / §13）。
     *
     * 为什么必须转发：菜单窗口现在**在上层**（同类型 + 后 addView），
     * 缺口处虽然透明，但触摸仍然归菜单窗口 —— 不转发就"看得见人物却拖不动"。
     *
     * 口径（需求 §13）：拖动期间**不显示轮盘**；拖动结束**关闭菜单**不自动重开；
     * 由既有的贴边 + 落盘链路收尾（复用 4C-3A 已验证的逻辑，不写第二套）。
     */
    private fun onWheelPetDrag(x: Float, y: Float, phase: WheelPetDragPhase) {
        when (phase) {
            WheelPetDragPhase.start -> {
                val p = params ?: return
                forwardDragOriginX = p.x
                forwardDragOriginY = p.y
                forwardPressX = x
                forwardPressY = y
                // 拖动时人物必须可见（它由原窗口自绘，这里只是兜底保证）。
                enforcePetAlwaysVisible("pet-drag")
                OverlayLog.log(
                    "wheel.pet_drag.start origin=($forwardDragOriginX,$forwardDragOriginY) " +
                        "touch=(${x.toInt()},${y.toInt()})（轮盘已隐藏，位移转发给桌宠窗口）",
                )
            }

            WheelPetDragPhase.move -> dragPetForwarded(x, y)

            WheelPetDragPhase.end -> {
                OverlayLog.log("wheel.pet_drag.end ${positionSummary()}")
                // 先收菜单（立即、不重开），再走既有的贴边 + 落盘。
                closeMenu("wheel-pet-drag-end", animate = false)
                finishDrag()
            }
        }
    }

    private fun dragPetForwarded(x: Float, y: Float) {
        val p = params ?: return
        val current = view ?: return
        if (!current.isAttachedToWindow) return
        val size = petSize()
        val target = OverlayPositionCalculator.clampTopLeft(
            x = forwardDragOriginX + (x - forwardPressX).toInt(),
            y = forwardDragOriginY + (y - forwardPressY).toInt(),
            bounds = bounds,
            petWidth = size.width,
            petHeight = size.height,
        )
        if (p.x == target[0] && p.y == target[1]) return
        p.x = target[0]
        p.y = target[1]
        safeUpdateViewLayout("wheel-forward-drag")
    }

    /** 转发拖动期间的起点（屏幕坐标与触摸坐标各一份）。 */
    private var forwardDragOriginX: Int = 0
    private var forwardDragOriginY: Int = 0
    private var forwardPressX: Float = 0f
    private var forwardPressY: Float = 0f

    /**
     * 提交**桌宠窗口**的几何（位置 + 尺寸）：参数一次准备完，只触发一次 `updateViewLayout`。
     *
     * 只用于"桌宠本来就该移动"的场景（旋转 / 改大小 / 换素材）。
     * 菜单的开/关**不经过这里** —— 那正是双窗口方案要根治抽动的地方。
     */
    private fun applyPetWindowGeometry(
        left: Int,
        top: Int,
        size: OverlaySize,
        tag: String,
    ): Boolean {
        requireMainThread("applyPetWindowGeometry")
        val currentView = view ?: return false
        val p = params ?: return false
        if (!canTouchWindow()) {
            OverlayLog.warn("$tag 被拒绝：窗口未附着或实例已失效（窗口保持不动）")
            return false
        }
        currentView.prepareWindowGeometry(size)
        p.x = left
        p.y = top
        p.width = size.width.coerceAtLeast(1)
        p.height = size.height.coerceAtLeast(1)
        currentView.requestLayout()
        safeUpdateViewLayout(tag)
        return true
    }

    /**
     * 下一帧诊断：读取**真实**的桌宠窗口在屏幕上的位置，核对"桌宠绝对没动"。
     *
     * 双窗口方案下这条恒应为 `delta=(0,0)`；出现非 0 就是真机上有位移的直接证据。
     */
    private fun schedulePetPositionSettledDiagnostics(tag: String, beforePet: OverlayRect) {
        val currentView = view ?: return
        currentView.postOnAnimation {
            if (disposed) return@postOnAnimation
            val rootLocation = IntArray(2)
            currentView.getLocationOnScreen(rootLocation)
            val petContentLocation = currentView.petContentLocationOnScreen()
            val petContentSize = currentView.petContentSize()
            val p = params
            val dx = rootLocation[0] - beforePet.left
            val dy = rootLocation[1] - beforePet.top
            val settled = kotlin.math.abs(dx) <= 1 && kotlin.math.abs(dy) <= 1
            val message =
                "menu.geometry.settled tag=$tag rootLoc=(${rootLocation[0]},${rootLocation[1]}) " +
                    "petContentLoc=(${petContentLocation[0]},${petContentLocation[1]}) " +
                    "root=${currentView.width}x${currentView.height} " +
                    "petContent=${petContentSize[0]}x${petContentSize[1]} " +
                    "petWindowLp=(${p?.x},${p?.y} ${p?.width}x${p?.height}) " +
                    "menuWindow=${menuParams?.let { "(${it.x},${it.y} ${it.width}x${it.height})" } ?: "none"} " +
                    "beforePetWindow=(${beforePet.left},${beforePet.top}) " +
                    "delta=($dx,$dy) attached=${currentView.isAttachedToWindow}"
            if (settled) {
                OverlayLog.log(message)
            } else {
                OverlayLog.warn("$message —— 下一帧桌宠绝对位置与提交前不一致（>1px）")
            }
            host.onGeometrySettled(tag, dx, dy, settled)
        }
    }

    // -----------------------------------------------------------------------
    // 轮盘菜单窗口（双窗口方案）
    // -----------------------------------------------------------------------

    /**
     * 添加**独立的轮盘窗口**（最多一个）。
     *
     * 桌宠窗口在这里**一个字段都不改** —— 这是"关闭菜单时桌宠不抽动"的结构性保证。
     * 窗口矩形由 [envelope] 一次性给出：**打开期间不再变化**（需求 §14）。
     */
    private fun addMenuWindow(
        envelope: WheelMenuEnvelope,
        layout: WheelMenuLayout,
        petWindowRect: OverlayRect,
    ): Boolean {
        val menuRect = envelope.windowRect
        if (!menuRect.isUsable) {
            OverlayLog.warn("menu.window.open 跳过：没有可用的轮盘窗口矩形")
            return false
        }
        if (!canTouchWindow()) {
            OverlayLog.warn("menu.window.open 被拒绝：桌宠窗口未附着或实例已失效")
            return false
        }
        // 保证"每种窗口最多一个"：先清掉可能残留的菜单窗口。
        removeMenuWindow("reopen")

        val created = WheelMenuView(context).apply {
            entryListener = { entry, index -> onWheelEntryConfirmed(entry, index) }
            // 落在环带之外的按下 + 松手 = 外部点击 → 关闭菜单（需求 §5）。
            closeListener = { closeMenu("outside-tap", animate = false) }
            animationListener = { kind -> onWheelAnimationFinished(kind) }
            // 菜单窗口在上层 ⇒ 中央人物区域的拖动必须**主动转发**给桌宠窗口（需求 §3）。
            petDragListener = { x, y, phase -> onWheelPetDrag(x, y, phase) }
            infoProvider = { entry -> host.onMenuInfo(entry.id) }
            hapticsEnabled = menuHapticsEnabled
            debugBounds = debugMode
            present(
                envelope = envelope,
                level = WheelMenuCatalog.ROOT,
                layout = layout,
                theme = menuTheme,
                direction = envelope.direction,
                spec = wheelSpec,
            )
        }
        val lp = WindowManager.LayoutParams(
            menuRect.width,
            menuRect.height,
            // 轮盘窗口用**更低的窗口类型**：桌宠窗口必须始终盖在它之上（需求 §2）。
            OverlayWindowSpec.menuWindowType(Build.VERSION.SDK_INT),
            OverlayWindowSpec.windowFlags(touchThrough),
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = menuRect.left
            y = menuRect.top
            alpha = 1f
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            menuAddViewAttempted = true
            windowManager.addView(created, lp)
            menuAddViewSucceeded = true
            lastMenuOpenError = null
        } catch (t: Throwable) {
            // 真机回归要求：**异常绝不能被静默吞掉**（完整类型 + message 都要留证据）。
            menuAddViewSucceeded = false
            lastMenuOpenError = "${t.javaClass.name}: ${t.message}"
            OverlayLog.error(
                "轮盘窗口 addView 失败（菜单不显示，桌宠不受影响）" +
                    " type=${lp.type} flags=${lp.flags} rect=${lp.x},${lp.y} ${lp.width}x${lp.height} " +
                    "exception=${t.javaClass.name}: ${t.message}",
                t,
            )
            return false
        }
        menuView = created
        menuParams = lp
        OverlayLog.log(
            "menu.window.open rect=(${menuRect.left},${menuRect.top} " +
                "${menuRect.width}x${menuRect.height}) items=${layout.itemCount} " +
                "type=${lp.type} petType=${OverlayWindowSpec.petWindowType(Build.VERSION.SDK_INT)} " +
                "petWindow=(${petWindowRect.left},${petWindowRect.top} " +
                "${petWindowRect.width}x${petWindowRect.height})",
        )
        // 下一帧核对"真的挂上去了" —— addView 返回不代表一定生效（可能被系统拒绝或被压在下面）。
        created.postOnAnimation {
            if (disposed || menuView !== created) return@postOnAnimation
            val attached = created.isAttachedToWindow
            if (!attached) {
                lastMenuOpenError = "addView-ok-but-not-attached"
                OverlayLog.error(
                    "轮盘窗口 addView 返回成功，但下一帧仍未附着（多半被系统拒绝）" +
                        " ${menuOpenDiagnostics()}",
                )
            } else {
                OverlayLog.log("menu.window.attached ${menuOpenDiagnostics()}")
            }
        }
        return true
    }

    /** 移除菜单窗口（幂等）。桌宠窗口不受影响。 */
    private fun removeMenuWindow(reason: String) {
        // 【A2 第二次回归】视觉规则已固定为"桌宠窗口自绘"，因此这里只需清零保证。
        val currentView = menuView ?: return
        enforcePetAlwaysVisible("remove-menu-window:$reason")
        menuView = null
        menuParams = null
        OverlayLog.log("removeView reason=wheel-window:$reason ${currentView.dump()}")
        try {
            windowManager.removeView(currentView)
        } catch (t: Throwable) {
            OverlayLog.warn("轮盘窗口 removeView 失败（通常表示已被系统移除）", t)
        }
    }

    /** 窗口是否可安全操作（未销毁 + 已附着）。 */
    private fun canTouchWindow(): Boolean = canUpdateMenuWindow(disposed, isAttachedToWindow)

    // -----------------------------------------------------------------------
    // 几何
    // -----------------------------------------------------------------------

    /**
     * 计算窗口尺寸：**按素材宽高比**分配，不拉伸变形。
     *
     * 诊断模式固定正方形（4C-2 的排障入口，必须保持"完全不依赖素材"）。
     */
    private fun computeSize(store: PetOverlayStore, density: Float): OverlaySize {
        if (store.debugOverlayMode) {
            val square = OverlayGeometry.debugSizePx(density, screenSize()[0], screenSize()[1])
            return OverlaySize(square, square)
        }
        return OverlayPetSize.resolve(
            scale = store.scale,
            density = density,
            aspectRatio = view?.drawableAspectRatio ?: 1f,
            bounds = bounds,
        )
    }

    /**
     * 计算左上角坐标。
     *
     * 优先级：
     * 1. 诊断模式 → 固定位置（不恢复历史坐标）；
     * 2. 已吸附到左/右边 → **按边对齐**（这样"贴在右侧时改大小不会向屏幕外扩张"）；
     * 3. 否则 → 用持久化的相对比例换算；
     * 4. 最后统一做边界修正。
     */
    private fun computeTopLeft(store: PetOverlayStore, size: OverlaySize): IntArray {
        val density = context.resources.displayMetrics.density
        if (store.debugOverlayMode) {
            return OverlayGeometry.debugTopLeftPx(density, bounds, size.width)
        }
        val edge = if (store.snapEnabled) store.snapEdge else OverlaySnapEdge.none
        val fromRatio = OverlayPositionCalculator.topLeftFromRatio(
            xRatio = store.xRatio,
            yRatio = store.yRatio,
            bounds = bounds,
            petWidth = size.width,
            petHeight = size.height,
        )
        if (edge == OverlaySnapEdge.none) return fromRatio
        val x = OverlayPositionCalculator.snapTargetX(edge, bounds, size.width)
        return OverlayPositionCalculator.clampTopLeft(x, fromRatio[1], bounds, size.width, size.height)
    }

    /**
     * 解析可用区域（状态栏 / 导航栏 / 刘海 / 分屏）。
     *
     * API 30+ 直接用 `WindowMetrics.windowInsets`（含 `displayCutout`），这是唯一
     * 能同时覆盖"状态栏 + 导航栏 + 挖孔 + 分屏"的可靠来源；
     * API 24~29 没有这套 API，退化为"屏幕尺寸 - 系统栏资源高度"（best effort，见文档"已知限制"）。
     */
    private fun resolveBounds(): OverlayBounds {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val metrics = windowManager.currentWindowMetrics
            val b = metrics.bounds
            val insets = metrics.windowInsets.getInsets(
                WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout(),
            )
            val resolved = OverlayBounds(
                left = b.left + insets.left,
                top = b.top + insets.top,
                right = b.right - insets.right,
                bottom = b.bottom - insets.bottom,
            )
            if (resolved.isUsable) return resolved
            return OverlayBounds.ofScreen(b.width(), b.height())
        }
        val screen = screenSize()
        if (screen[0] <= 0 || screen[1] <= 0) return OverlayBounds.unknown
        val landscape =
            context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val statusBar = systemBarPx("status_bar_height")
        val navBar = systemBarPx(
            if (landscape) "navigation_bar_height_landscape" else "navigation_bar_height",
        )
        val resolved = if (landscape) {
            OverlayBounds(0, statusBar, screen[0] - navBar, screen[1])
        } else {
            OverlayBounds(0, statusBar, screen[0], screen[1] - navBar)
        }
        return if (resolved.isUsable) resolved else OverlayBounds.ofScreen(screen[0], screen[1])
    }

    private fun systemBarPx(resourceName: String): Int {
        val id = context.resources.getIdentifier(resourceName, "dimen", "android")
        if (id <= 0) return 0
        return context.resources.getDimensionPixelSize(id).coerceAtLeast(0)
    }

    /** 屏幕可用区域（API 30+ 用真实窗口指标，低版本用 displayMetrics）。 */
    fun screenSize(): IntArray {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            return intArrayOf(bounds.width(), bounds.height())
        }
        @Suppress("DEPRECATION")
        val metrics = context.resources.displayMetrics
        return intArrayOf(metrics.widthPixels, metrics.heightPixels)
    }

    /** 当前方向名（持久化"保存时屏幕方向"用）。 */
    fun orientationName(): String =
        when (context.resources.configuration.orientation) {
            Configuration.ORIENTATION_LANDSCAPE -> PetOverlayStore.ORIENTATION_LANDSCAPE
            Configuration.ORIENTATION_PORTRAIT -> PetOverlayStore.ORIENTATION_PORTRAIT
            else -> PetOverlayStore.ORIENTATION_UNKNOWN
        }

    private fun requireMainThread(op: String) {
        if (Looper.myLooper() == Looper.getMainLooper()) return
        // 串行化前提：所有 WindowManager 操作都必须在主线程。
        OverlayLog.warn("$op 不在主线程（thread=${Thread.currentThread().name}）—— WindowManager 操作必须串行")
    }
}
