package asia.akechi.petlife.overlay

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Phase 4C-6B-1：轮盘交互状态机与动作分发 —— 覆盖需求 §18.2 与 §17。
 */
class WheelMenuStateTest {

    // --- 菜单栈与层级 -------------------------------------------------------

    @Test
    fun `打开菜单进入根菜单，关闭后栈被清空`() {
        val machine = WheelMenuStateMachine()
        assertTrue(machine.open(WheelExpandDirection.right))
        assertEquals(WheelMenuPhase.opening, machine.phase)
        assertEquals(WheelMenuCatalog.ROOT_ID, machine.levelId)
        assertEquals(0, machine.selectedIndex)
        assertFalse("根菜单不能返回", machine.canGoBack)

        machine.markOpened()
        assertEquals(WheelMenuPhase.open, machine.phase)

        assertTrue(machine.close())
        assertEquals(WheelMenuPhase.closed, machine.phase)
        assertNull(machine.levelId)
    }

    @Test
    fun `重复打开是幂等的（不会产生第二套菜单）`() {
        val machine = WheelMenuStateMachine()
        assertTrue(machine.open(WheelExpandDirection.right))
        assertFalse("已打开时再次 open 必须被拒绝", machine.open(WheelExpandDirection.left))
        assertEquals(WheelExpandDirection.right, machine.direction)
    }

    @Test
    fun `进入子菜单与返回：栈深度正确，返回键只退一级`() {
        val machine = WheelMenuStateMachine()
        machine.open(WheelExpandDirection.right)
        machine.markOpened()

        assertTrue(machine.enterLayer(WheelMenuCatalog.LEVEL_PET))
        assertEquals(WheelMenuCatalog.LEVEL_PET, machine.levelId)
        assertEquals(2, machine.depth)
        assertTrue(machine.canGoBack)
        machine.finishLayerTransition()
        assertEquals(WheelMenuPhase.open, machine.phase)

        assertTrue(machine.exitLayer())
        assertEquals(WheelMenuCatalog.ROOT_ID, machine.levelId)
        assertEquals(1, machine.depth)
        machine.finishLayerTransition()

        assertFalse("根菜单再返回必须失败（不能顺手关掉菜单）", machine.exitLayer())
        assertEquals(WheelMenuCatalog.ROOT_ID, machine.levelId)
        assertEquals(WheelMenuPhase.open, machine.phase)
    }

    @Test
    fun `非法层级路径被拒绝，不产生非法状态`() {
        val machine = WheelMenuStateMachine()
        machine.open(WheelExpandDirection.right)
        machine.markOpened()
        assertFalse("不存在的层级必须被拒绝", machine.enterLayer("no-such-level"))
        assertFalse("根菜单不能作为子菜单进入", machine.enterLayer(WheelMenuCatalog.ROOT_ID))
        assertFalse("重复进入同一层级必须被拒绝", run {
            machine.enterLayer(WheelMenuCatalog.LEVEL_PET) &&
                machine.enterLayer(WheelMenuCatalog.LEVEL_PET)
        })
        assertEquals(WheelMenuCatalog.LEVEL_PET, machine.levelId)
        assertEquals(2, machine.depth)
    }

    @Test
    fun `菜单关闭时不能进入子菜单`() {
        val machine = WheelMenuStateMachine()
        assertFalse(machine.enterLayer(WheelMenuCatalog.LEVEL_PET))
        assertFalse(machine.exitLayer())
        assertNull(machine.levelId)
    }

    @Test
    fun `换层后选中项回到第一项`() {
        val machine = WheelMenuStateMachine()
        machine.open(WheelExpandDirection.right)
        machine.markOpened()
        machine.setPreview(4)
        machine.confirmSelection()
        assertEquals(4, machine.selectedIndex)

        machine.enterLayer(WheelMenuCatalog.LEVEL_SETTINGS)
        assertEquals(0, machine.selectedIndex)
        assertNull(machine.previewIndex)
    }

    // --- 选中与取消 ---------------------------------------------------------

    @Test
    fun `滑选中的临时高亮优先于已确认项，且越界会被夹回`() {
        val machine = WheelMenuStateMachine()
        machine.open(WheelExpandDirection.right)
        machine.markOpened()
        assertEquals(0, machine.activeIndex)

        machine.setPreview(3)
        assertEquals(3, machine.activeIndex)
        assertEquals("确认项还没变", 0, machine.selectedIndex)

        machine.setPreview(null)
        assertEquals("取消后回到已确认项", 0, machine.activeIndex)

        machine.setPreview(999)
        assertEquals("越界必须夹回合法范围", machine.currentLevel!!.itemCount - 1, machine.activeIndex)
    }

    @Test
    fun `松手确认把临时高亮变成已确认项并返回被选中的条目`() {
        val machine = WheelMenuStateMachine()
        machine.open(WheelExpandDirection.right)
        machine.markOpened()
        machine.setPreview(2)
        val entry = machine.confirmSelection()
        assertEquals(WheelMenuCatalog.ROOT.entries[2].id, entry?.id)
        assertEquals(2, machine.selectedIndex)
        assertNull(machine.previewIndex)
    }

    @Test
    fun `动画被打断后收敛到确定状态，绝不卡在中间态`() {
        for (phase in WheelMenuPhase.entries) {
            val machine = WheelMenuStateMachine()
            machine.open(WheelExpandDirection.right)
            machine.markOpened()
            when (phase) {
                WheelMenuPhase.switching -> machine.beginSwitch(1)
                WheelMenuPhase.enteringLayer -> machine.enterLayer(WheelMenuCatalog.LEVEL_PET)
                WheelMenuPhase.exitingLayer -> {
                    machine.enterLayer(WheelMenuCatalog.LEVEL_PET)
                    machine.finishLayerTransition()
                    machine.exitLayer()
                }
                WheelMenuPhase.closing -> machine.beginClosing()
                WheelMenuPhase.opening -> {
                    // 重新构造一个"正在展开"的实例
                    val fresh = WheelMenuStateMachine()
                    fresh.open(WheelExpandDirection.right)
                    fresh.settleAfterInterruption()
                    assertEquals(WheelMenuPhase.open, fresh.phase)
                    continue
                }
                WheelMenuPhase.closed, WheelMenuPhase.open -> continue
            }
            machine.settleAfterInterruption()
            assertTrue(
                "phase=$phase 打断后必须落在确定状态，实际 ${machine.phase}",
                machine.phase == WheelMenuPhase.open || machine.phase == WheelMenuPhase.closed,
            )
        }
    }

    @Test
    fun `长按返回可以一路回到根菜单`() {
        val stack = WheelMenuStack()
        stack.open()
        stack.push(WheelMenuCatalog.LEVEL_PET)
        stack.push(WheelMenuCatalog.LEVEL_SETTINGS)
        assertTrue(stack.popToRoot())
        assertEquals(WheelMenuCatalog.ROOT_ID, stack.currentId)
        assertFalse(stack.popToRoot())
    }

    // --- 动作分发（需求 §17）---------------------------------------------

    private class RecordingHost : WheelMenuActionHost {
        val navigated = ArrayList<WheelMenuAction>()
        val business = ArrayList<WheelMenuAction>()
        val info = ArrayList<String>()

        override fun onNavigateAction(action: WheelMenuAction, entryId: String): Boolean {
            navigated.add(action)
            return true
        }

        override fun onBusinessAction(action: WheelMenuAction, entryId: String) {
            business.add(action)
        }

        override fun onInfoAction(entryId: String, entry: WheelMenuEntry) {
            info.add(entryId)
        }
    }

    @Test
    fun `导航类动作为 navigation，业务类为 business，只读项为 info`() {
        val dispatcher = WheelMenuActionDispatcher(RecordingHost())
        assertEquals(WheelActionRoute.navigation, dispatcher.routeOf(WheelMenuAction.openPetMenu))
        assertEquals(WheelActionRoute.navigation, dispatcher.routeOf(WheelMenuAction.back))
        assertEquals(WheelActionRoute.navigation, dispatcher.routeOf(WheelMenuAction.closeMenu))
        assertEquals(WheelActionRoute.info, dispatcher.routeOf(WheelMenuAction.showInfo))
        // 4C-6B-1 明确只做占位：这些一律走 business（不接真实业务）
        for (action in listOf(
            WheelMenuAction.hideOverlay,
            WheelMenuAction.toggleAutomaticState,
            WheelMenuAction.nextAsset,
            WheelMenuAction.syncNow,
            WheelMenuAction.selectTheme,
            WheelMenuAction.stopOverlayService,
        )) {
            assertEquals("$action 在本阶段必须是占位", WheelActionRoute.business, dispatcher.routeOf(action))
        }
    }

    @Test
    fun `分发只调用对应的一条通道`() {
        val host = RecordingHost()
        val dispatcher = WheelMenuActionDispatcher(host)

        dispatcher.dispatch(WheelMenuAction.openSettingsMenu, "root_settings", null)
        assertEquals(listOf(WheelMenuAction.openSettingsMenu), host.navigated)
        assertTrue(host.business.isEmpty())

        dispatcher.dispatch(WheelMenuAction.syncNow, "records_sync", null)
        assertEquals(listOf(WheelMenuAction.syncNow), host.business)

        dispatcher.dispatch(
            WheelMenuAction.showInfo,
            "records_app",
            WheelMenuCatalog.RECORDS.entries.first { it.id == "records_app" },
        )
        assertEquals(listOf("records_app"), host.info)
    }

    @Test
    fun `根条目到子菜单的映射只有一份，且来回一致`() {
        val dispatcher = WheelMenuActionDispatcher(RecordingHost())
        val expected = mapOf(
            WheelMenuAction.openPetMenu to WheelMenuCatalog.LEVEL_PET,
            WheelMenuAction.openAppearanceMenu to WheelMenuCatalog.LEVEL_APPEARANCE,
            WheelMenuAction.openRecordsMenu to WheelMenuCatalog.LEVEL_RECORDS,
            WheelMenuAction.openToolsMenu to WheelMenuCatalog.LEVEL_TOOLS,
            WheelMenuAction.openSettingsMenu to WheelMenuCatalog.LEVEL_SETTINGS,
        )
        // 根菜单里每个"打开子菜单"的动作都能映射到真实存在的层级
        WheelMenuCatalog.ROOT.entries.forEach { entry ->
            val target = dispatcher.targetLevelOf(entry.action)
            if (target != null) {
                assertEquals(expected[entry.action], target)
                assertTrue("映射到的层级必须真实存在", WheelMenuCatalog.level(target) != null)
            }
        }
        assertNull(dispatcher.targetLevelOf(WheelMenuAction.hideOverlay))
        assertNull(dispatcher.targetLevelOf(WheelMenuAction.back))
    }

    @Test
    fun `每个条目的动作都在统一命令表里（没有第二套命名）`() {
        val all = WheelMenuCatalog.ROOT.entries +
            WheelMenuCatalog.PET.entries +
            WheelMenuCatalog.APPEARANCE.entries +
            WheelMenuCatalog.RECORDS.entries +
            WheelMenuCatalog.TOOLS.entries +
            WheelMenuCatalog.SETTINGS.entries
        assertTrue(all.isNotEmpty())
        all.forEach { entry ->
            assertTrue("条目 ${entry.id} 的 id 不能为空", entry.id.isNotEmpty())
            assertTrue("条目 ${entry.id} 的中文名不能为空", entry.labelZh.isNotEmpty())
            assertTrue(
                "条目 ${entry.id} 的动作必须在命令表里",
                WheelMenuAction.entries.contains(entry.action),
            )
        }
        // id 在同一层级内唯一（返回键在所有子菜单里共用同一个 id，这是刻意的）
        listOf(
            WheelMenuCatalog.ROOT,
            WheelMenuCatalog.PET,
            WheelMenuCatalog.APPEARANCE,
            WheelMenuCatalog.RECORDS,
            WheelMenuCatalog.TOOLS,
            WheelMenuCatalog.SETTINGS,
        ).forEach { level ->
            assertEquals(
                "${level.id} 内 id 必须唯一",
                level.entries.size,
                level.entries.map { it.id }.distinct().size,
            )
        }
    }
}
