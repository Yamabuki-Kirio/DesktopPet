package asia.akechi.petlife.overlay

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Phase 4C-3A：手势状态机的**纯逻辑**测试。
 *
 * 覆盖需求"五、Phase 4C-3A 测试"的第 9~12 条：
 * touchSlop 以内是点击、超过是拖动、拖动后松手不触发点击、窗口未附着时不拖动；
 * 另外覆盖 `ACTION_CANCEL` 与多指介入的清理（需求"三、第 4~6 条"）。
 *
 * 这里用**注入的 touchSlop**（而不是真机 `getScaledTouchSlop()`），
 * 正好证明"阈值没有写死"。
 */
class OverlayGestureTest {

    private val slop = 24
    private fun machine() = OverlayGestureMachine(touchSlopPx = slop, tapTimeoutMs = 300)

    // --- 9：touchSlop 以内判定为点击 -----------------------------------------

    @Test
    fun `移动未超过 touchSlop 且时间够短 → 判定为单击`() {
        val m = machine()
        assertEquals(OverlayGestureEffect.press, m.onDown(100f, 100f, 0L))
        assertEquals(OverlayGestureState.PRESSING, m.state)

        // 14.1px < 24px
        assertEquals(OverlayGestureEffect.none, m.onMove(110f, 110f, 10L))
        assertEquals(OverlayGestureState.PRESSING, m.state)

        assertEquals(OverlayGestureEffect.click, m.onUp(110f, 110f, 50L))
        assertEquals(OverlayGestureState.IDLE, m.state)
    }

    @Test
    fun `原地按下再抬起也是单击`() {
        val m = machine()
        m.onDown(500f, 900f, 0L)
        assertEquals(OverlayGestureEffect.click, m.onUp(500f, 900f, 120L))
    }

    @Test
    fun `按下时间过长不算单击（长按本阶段不定义功能）`() {
        val m = machine()
        m.onDown(100f, 100f, 0L)
        assertEquals(OverlayGestureEffect.cancel, m.onUp(100f, 100f, 5_000L))
    }

    // --- 10：超过 touchSlop 判定为拖动 ---------------------------------------

    @Test
    fun `移动超过 touchSlop 进入拖动，并持续给出 drag 事件`() {
        val m = machine()
        assertEquals(OverlayGestureEffect.press, m.onDown(100f, 100f, 0L))

        // 位移 141px > 24px
        assertEquals(OverlayGestureEffect.dragStart, m.onMove(200f, 200f, 20L))
        assertEquals(OverlayGestureState.DRAGGING, m.state)
        assertTrue(m.isDragging())

        assertEquals(OverlayGestureEffect.drag, m.onMove(210f, 210f, 30L))
        assertEquals(OverlayGestureEffect.drag, m.onMove(220f, 220f, 40L))
    }

    @Test
    fun `touchSlop 边界：正好等于阈值不算拖动，超过才拖动`() {
        val m = machine()
        m.onDown(0f, 0f, 0L)
        // 正好 24px：不算超过
        assertEquals(OverlayGestureEffect.none, m.onMove(slop.toFloat(), 0f, 10L))
        assertEquals(OverlayGestureState.PRESSING, m.state)
        // 25px：超过
        assertEquals(OverlayGestureEffect.dragStart, m.onMove(slop + 1f, 0f, 20L))
        assertEquals(OverlayGestureState.DRAGGING, m.state)
    }

    // --- 11：拖动后松手不触发点击 --------------------------------------------

    @Test
    fun `拖动之后松开只结束拖动，绝不触发单击`() {
        val m = machine()
        m.onDown(100f, 100f, 0L)
        m.onMove(300f, 300f, 20L)
        // 松手位置又回到按下点附近，但**曾经**拖过 → 依然不能算单击
        val effect = m.onUp(105f, 105f, 60L)
        assertEquals(OverlayGestureEffect.dragEnd, effect)
        assertEquals(OverlayGestureState.IDLE, m.state)
        assertFalse(m.isDragging())
    }

    // --- 12：窗口未附着时不拖动 ----------------------------------------------

    @Test
    fun `窗口未附着时不允许进入拖动（也就不会去调 updateViewLayout）`() {
        val m = machine()
        m.windowUpdatable = false
        assertEquals(OverlayGestureEffect.press, m.onDown(100f, 100f, 0L))
        assertEquals(OverlayGestureEffect.none, m.onMove(500f, 500f, 20L))
        assertEquals("必须停在 PRESSING，不得进入 DRAGGING", OverlayGestureState.PRESSING, m.state)
        assertFalse(m.isDragging())
        // 松手时因为已经"移动超过 slop"，既不是拖动也不是单击 → 取消
        assertEquals(OverlayGestureEffect.cancel, m.onUp(500f, 500f, 40L))
    }

    // --- ACTION_CANCEL ------------------------------------------------------

    @Test
    fun `ACTION_CANCEL 从按下态和拖动态都能干净回到 IDLE`() {
        val pressed = machine()
        pressed.onDown(10f, 10f, 0L)
        assertEquals(OverlayGestureEffect.cancel, pressed.onCancel())
        assertEquals(OverlayGestureState.IDLE, pressed.state)

        val dragged = machine()
        dragged.onDown(10f, 10f, 0L)
        dragged.onMove(200f, 200f, 10L)
        assertEquals(OverlayGestureEffect.cancel, dragged.onCancel())
        assertEquals(OverlayGestureState.IDLE, dragged.state)
        assertFalse(dragged.isDragging())

        // 已经空闲时再取消：什么也不做
        assertEquals(OverlayGestureEffect.none, dragged.onCancel())
    }

    // --- 多指介入 -----------------------------------------------------------

    @Test
    fun `第二根手指落下会取消拖动，且不产生点击`() {
        val m = machine()
        m.onDown(100f, 100f, 0L)
        m.onMove(300f, 300f, 10L)
        assertEquals(OverlayGestureEffect.cancel, m.onDown(300f, 300f, 20L, pointerCount = 2))
        assertEquals(OverlayGestureState.SCALING, m.state)
        // 缩放态下移动不拖动
        assertEquals(OverlayGestureEffect.none, m.onMove(320f, 320f, 30L, pointerCount = 2))
    }

    @Test
    fun `缩放态下抬起不会触发单击`() {
        val m = machine()
        m.onDown(100f, 100f, 0L)
        m.onDown(120f, 120f, 10L, pointerCount = 2)
        assertEquals(OverlayGestureState.SCALING, m.state)
        assertEquals(
            OverlayGestureEffect.none,
            m.onUp(120f, 120f, 20L, pointerCount = 2),
        )
    }

    // --- 生命周期：隐藏 / 停止 ----------------------------------------------

    @Test
    fun `窗口隐藏或服务停止后不再接受任何手势`() {
        val hidden = machine()
        hidden.onDown(10f, 10f, 0L)
        hidden.suspend(OverlayGestureState.HIDDEN)
        assertEquals(OverlayGestureState.HIDDEN, hidden.state)
        assertEquals(OverlayGestureEffect.none, hidden.onDown(10f, 10f, 20L))
        assertEquals(OverlayGestureState.HIDDEN, hidden.state)

        val stopped = machine()
        stopped.suspend(OverlayGestureState.STOPPED)
        assertEquals(OverlayGestureState.STOPPED, stopped.state)
        assertEquals(OverlayGestureEffect.none, stopped.onMove(500f, 500f, 10L))
        assertEquals(OverlayGestureState.STOPPED, stopped.state)
    }

    @Test
    fun `suspend 只接受 HIDDEN 或 STOPPED`() {
        val m = machine()
        var threw = false
        try {
            m.suspend(OverlayGestureState.IDLE)
        } catch (e: IllegalArgumentException) {
            threw = true
        }
        assertTrue("suspend(IDLE) 必须被拒绝，避免误用", threw)
    }

    @Test
    fun `touchSlop 非法（0 或负数）时退化为 1，任何移动都算拖动而不是崩溃`() {
        val m = OverlayGestureMachine(touchSlopPx = 0, tapTimeoutMs = 300)
        m.onDown(100f, 100f, 0L)
        // 位移 2px > 1px（退化后的阈值）
        assertEquals(OverlayGestureEffect.dragStart, m.onMove(102f, 100f, 10L))
        assertEquals(OverlayGestureState.DRAGGING, m.state)
    }
}
